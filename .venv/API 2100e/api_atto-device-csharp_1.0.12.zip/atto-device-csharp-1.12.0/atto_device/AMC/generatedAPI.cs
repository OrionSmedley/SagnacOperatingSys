using System;

using Attocube.API;
using Attocube.API.Error;

namespace Attocube.AMC_1_0_0 {

public class AttocubeAMC : Attocube.API.AttocubeAPI {
    /// <summary>
    /// Get Chassis and Slot Number, only works when AMC is within a Rack
    /// </summary>
    /// <returns>
    ///   [0] slotNbr: slotNbr
    ///   [1] chassisNbr: chassisNbr
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Description_CheckChassisNbr() {
        object _parameterCommand = "com.attocube.amc.description.checkChassisNbr";

        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Select and override a positioner out of the Current default list only override given parameters set others default
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="json_dict">dict with override params</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetActorParametersJson(int axis, string json_dict) {
        object _parameterCommand = "com.attocube.amc.control.setActorParametersJson";

        object parameteraxis = axis;
        object parameterjson_dict = json_dict;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterjson_dict);

        
        
    }

    /// <summary>
    /// This function reads the actor names that can be connected to the device.
    /// </summary>
    /// <returns>
    ///   [0] PositionersList: PositionersList
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Description_GetPositionersList() {
        object _parameterCommand = "com.attocube.amc.description.getPositionersList";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// This function gets the device type based on its EEPROM configuration.
    /// </summary>
    /// <returns>
    ///   [0] value_devicetype: devicetype Device name (AMC100, AMC150, AMC300) with attached feature ( AMC100/NUM, AMC100/NUM/PRO)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Description_GetDeviceType() {
        object _parameterCommand = "com.attocube.amc.description.getDeviceType";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the activated features and return as a string
    /// </summary>
    /// <returns>
    ///   [0] value_features: features activated on device concatenated by comma e.g. Closed loop Operation, Pro, Wireless Controller, IO
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Description_GetFeaturesActivated() {
        object _parameterCommand = "com.attocube.amc.description.getFeaturesActivated";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// This function triggers one step on the selected axis in desired direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="backward">Selects the desired direction. False triggers a forward step, true a backward step</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetSingleStep(int axis, bool backward) {
        object _parameterCommand = "com.attocube.amc.move.setSingleStep";

        object parameteraxis = axis;
        object parameterbackward = backward;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterbackward);

        
        
    }

    /// <summary>
    /// This function triggers n steps on the selected axis in desired direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="backward">Selects the desired direction. False triggers a forward step, true a backward step</param>
    /// <param name="step">number of step</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetNSteps(int axis, bool backward, int step) {
        object _parameterCommand = "com.attocube.amc.move.setNSteps";

        object parameteraxis = axis;
        object parameterbackward = backward;
        object parameterstep = step;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterbackward, parameterstep);

        
        
    }

    /// <summary>
    /// Sets the number of steps to perform on stepwise movement.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="step">number of step</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_WriteNSteps(int axis, int step) {
        object _parameterCommand = "com.attocube.amc.move.writeNSteps";

        object parameteraxis = axis;
        object parameterstep = step;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterstep);

        
        
    }

    /// <summary>
    /// Perform the OL command for N steps
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="backward">Selects the desired direction. False triggers a forward step, true a backward step</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_PerformNSteps(int axis, bool backward) {
        object _parameterCommand = "com.attocube.amc.move.performNSteps";

        object parameteraxis = axis;
        object parameterbackward = backward;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterbackward);

        
        
    }

    /// <summary>
    /// This function gets the number of Steps in desired direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] nbrstep: nbrstep
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Move_GetNSteps(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getNSteps";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets a continuous movement on the selected axis in positive direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">If enabled a present movement in the opposite direction is stopped. The parameter "false" stops all movement of the axis regardless its direction.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetControlContinuousFwd(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.move.setControlContinuousFwd";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets the axisâ€™ movement status in positive direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled true if movement Fwd is active, false otherwise
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Move_GetControlContinuousFwd(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getControlContinuousFwd";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets a continuous movement on the selected axis in backward direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">If enabled a present movement in the opposite direction is stopped. The parameter "false" stops all movement of the axis regardless its direction</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetControlContinuousBkwd(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.move.setControlContinuousBkwd";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets the axisâ€™ movement status in backward direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled true if movement backward is active , false otherwise
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Move_GetControlContinuousBkwd(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getControlContinuousBkwd";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the target position for the movement on the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_position: position defined in nm for goniometer an rotator type actors it is ÂµÂ°.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Move_GetControlTargetPosition(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getControlTargetPosition";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the target position for the movement on the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="target">absolute position : For linear type actors the position is defined in nm for goniometer an rotator type actors it is ÂµÂ°.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetControlTargetPosition(int axis, double target) {
        object _parameterCommand = "com.attocube.amc.move.setControlTargetPosition";

        object parameteraxis = axis;
        object parametertarget = target;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametertarget);

        
        
    }

    /// <summary>
    /// This function starts an approach to the reference position.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_MoveReference(int axis) {
        object _parameterCommand = "com.attocube.amc.move.moveReference";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// This function gets the current position of the positioner on the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_position: position defined in nm for goniometer an rotator type actors it is ÂµÂ°.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Move_GetPosition(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getPosition";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the output applied to the selected axis on the end of travel.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled If true, the output of the axis will be deactivated on positive EOT detection.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Move_GetControlEotOutputDeactive(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getControlEotOutputDeactive";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the output applied to the selected axis on the end of travel.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">if enabled, the output of the axis will be deactivated on positive EOT detection.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetControlEotOutputDeactive(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.move.setControlEotOutputDeactive";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets information about the connection status of the selected axisâ€™ positioner.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_connected: connected If true, the actor is connected
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusConnected(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusConnected";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets information about the status of the reference position.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_valid: valid true = valid, false = not valid
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusReference(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusReference";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets information about the status of the stage output.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_status: status 0: Idle, i.e. within the noise range of the sensor, 1: Moving, i.e the actor is actively driven by the output stage either for closed-loop approach or continous/single stepping and the output is active.  2 : Pending means the output stage is driving but the output is deactivated
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Status_GetStatusMoving(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusMoving";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the status of the end of travel detection on the selected axis in forward direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_detected: detected true when EoT was detected
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusEotFwd(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusEotFwd";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the status of the end of travel detection on the selected axis in backward direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_detected: detected true when EoT was detected
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusEotBkwd(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusEotBkwd";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Retrieves the status of the end of travel (EOT) detection in backward direction or in forward direction.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_detected: detected true when EoT in either direction was detected
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusEot(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusEot";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets information about whether the selected axisâ€™ positioner is in target range or not.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_in_range: in_range true within the target range, false not within the target range
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Status_GetStatusTargetRange(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getStatusTargetRange";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Get the Feedback status of the positioner
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_sensorstatus: sensorstatus as integer 0: NUM Positioner connected 1: OL positioner connected  2: No positioner connected , 3: RES positione connected
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Status_GetOlStatus(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getOlStatus";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Get the full combined status of a positioner axis and return the status as a string (to be used in the Webapplication)
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_string: string can be "moving","in target range", "backward limit reached", "forward limit reached", "positioner not connected", "grounded" (only AMC300), "output not enabled"
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Status_GetFullCombinedStatus(int axis) {
        object _parameterCommand = "com.attocube.amc.status.getFullCombinedStatus";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the threshold range within the closed-loop controlled movement stops to regulate.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_threshold: threshold in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetMotionControlThreshold(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getMotionControlThreshold";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the threshold range within the closed-loop controlled movement stops to regulate.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="threshold">in pm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetMotionControlThreshold(int axis, int threshold) {
        object _parameterCommand = "com.attocube.amc.control.setMotionControlThreshold";

        object parameteraxis = axis;
        object parameterthreshold = threshold;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterthreshold);

        
        
    }

    /// <summary>
    /// This function gets the threshold range and slip phase time which is used while moving another axis
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_range: range in pm
    ///   [1] value_time: time after slip phase which is waited until the controller is acting again in microseconds
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Control_GetCrosstalkThreshold(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getCrosstalkThreshold";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the threshold range and slip phase time which is used while moving another axis
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="threshold">in pm</param>
    /// <param name="slipphasetime">time after slip phase which is waited until the controller is acting again in microseconds</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetCrosstalkThreshold(int axis, int threshold, int slipphasetime) {
        object _parameterCommand = "com.attocube.amc.control.setCrosstalkThreshold";

        object parameteraxis = axis;
        object parameterthreshold = threshold;
        object parameterslipphasetime = slipphasetime;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterthreshold, parameterslipphasetime);

        
        
    }

    /// <summary>
    /// This function gets whether the IDS sensor source of closed loop is inverted It is only available when the feature AMC/IDS closed loop has been activated
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_inverted: inverted boolen
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetSensorDirection(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getSensorDirection";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the IDS sensor source of closed loop to inverted when true.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="inverted"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetSensorDirection(int axis, bool inverted) {
        object _parameterCommand = "com.attocube.amc.control.setSensorDirection";

        object parameteraxis = axis;
        object parameterinverted = inverted;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterinverted);

        
        
    }

    /// <summary>
    /// This function gets whether the sensor source of closed loop is IDS It is only available when the feature AMC/IDS closed loop has been activated
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] enabled: enabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetExternalSensor(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getExternalSensor";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the sensor source of closed loop to the IDS when enabled.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enabled"></param>
    /// <returns>
    ///   [0] value_warningNo: warningNo Warning code, can be converted into a string using the errorNumberToString function
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_SetExternalSensor(int axis, bool enabled) {
        object _parameterCommand = "com.attocube.amc.control.setExternalSensor";

        object parameteraxis = axis;
        object parameterenabled = enabled;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis, parameterenabled);

        
        return ret;
    }

    /// <summary>
    /// This function gets the status of the output relays of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled power status (true = enabled,false = disabled)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetControlOutput(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlOutput";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the status of the output relays of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">true: enable drives, false: disable drives</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlOutput(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.control.setControlOutput";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function enables/disables the automatic C/R measurement on axis enable
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">true: enable automeasurement, false: disable automeasurement</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetAutoMeasure(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.control.setAutoMeasure";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function returns if the automeasurement on axis enable is enabled
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enable: enable true: enable automeasurement, false: disable automeasurement
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetAutoMeasure(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getAutoMeasure";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Control the actor parameter closed loop sensitivity
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="sensitivity"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetActorSensitivity(int axis, int sensitivity) {
        object _parameterCommand = "com.attocube.amc.control.setActorSensitivity";

        object parameteraxis = axis;
        object parametersensitivity = sensitivity;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametersensitivity);

        
        
    }

    /// <summary>
    /// Get the setting for the actor parameter sensitivity
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] sensitivity: sensitivity
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetActorSensitivity(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getActorSensitivity";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Control the actors parameter: actor name
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] actorname: actorname
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Control_GetActorParametersActorName(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getActorParametersActorName";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the name for the positioner on the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="actorname">name of the actor</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetActorParametersByName(int axis, string actorname) {
        object _parameterCommand = "com.attocube.amc.control.setActorParametersByName";

        object parameteraxis = axis;
        object parameteractorname = actorname;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameteractorname);

        
        
    }

    /// <summary>
    /// This function gets the current Voltage which is applied to the Piezo
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_amplitude: amplitude in mV
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetCurrentOutputVoltage(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getCurrentOutputVoltage";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the amplitude of the actuator signal of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_amplitude: amplitude in mV
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetControlAmplitude(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlAmplitude";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the amplitude of the actuator signal of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="amplitude">in mV</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlAmplitude(int axis, int amplitude) {
        object _parameterCommand = "com.attocube.amc.control.setControlAmplitude";

        object parameteraxis = axis;
        object parameteramplitude = amplitude;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameteramplitude);

        
        
    }

    /// <summary>
    /// This function sets the frequency of the actuator signal of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="frequency">in  mHz</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlFrequency(int axis, int frequency) {
        object _parameterCommand = "com.attocube.amc.control.setControlFrequency";

        object parameteraxis = axis;
        object parameterfrequency = frequency;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterfrequency);

        
        
    }

    /// <summary>
    /// This function gets the frequency of the actuator signal of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_frequency: frequency in mHz
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetControlFrequency(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlFrequency";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the type of the positioner of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_actor_type: actor_type  0: linear, 1: rotator, 2: goniometer
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetActorType(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getActorType";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the name of the positioner of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] actor_name: actor_name
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Control_GetActorName(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getActorName";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function resets the actual position of the selected axis given by the NUM sensor to zero and marks the reference position as invalid.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetReset(int axis) {
        object _parameterCommand = "com.attocube.amc.control.setReset";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// This function sets the approach of the selected axisâ€™ positioner to the target position.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">boolean true: eanble the approach , false: disable the approach</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlMove(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.control.setControlMove";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets the approach of the selected axisâ€™ positioner to the target position.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enable: enable boolean true: closed loop control enabled, false: closed loop control disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetControlMove(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlMove";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function searches for the reference position of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SearchReferencePosition(int axis) {
        object _parameterCommand = "com.attocube.amc.control.searchReferencePosition";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// This function gets the reference position of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_position: position: For linear type actors the position is defined in nm for goniometer an rotator type actors it is ÂµÂ°.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetReferencePosition(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getReferencePosition";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the status of whether the reference position is updated when the reference mark is hit.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled boolen
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetControlReferenceAutoUpdate(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlReferenceAutoUpdate";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the status of whether the reference position is updated when the reference mark is hit.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">boolean</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlReferenceAutoUpdate(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.control.setControlReferenceAutoUpdate";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function resets the position every time the reference position is detected.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled boolean
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetControlAutoReset(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlAutoReset";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function resets the position every time the reference position is detected.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">boolean</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlAutoReset(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.control.setControlAutoReset";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets the range around the target position in which the flag "In Target Range" becomes active.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_targetrange: targetrange in nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetControlTargetRange(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlTargetRange";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the range around the target position in which the flag "In Target Range" (see VIII.7.a) becomes active.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="range">in nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlTargetRange(int axis, int range) {
        object _parameterCommand = "com.attocube.amc.control.setControlTargetRange";

        object parameteraxis = axis;
        object parameterrange = range;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterrange);

        
        
    }

    /// <summary>
    /// Simultaneously set 3 axes positions and get positions to minimize network latency
    /// </summary>
    /// <param name="set1">axis1 otherwise pos1 target is ignored</param>
    /// <param name="set2">axis2 otherwise pos2 target is ignored</param>
    /// <param name="set3">axis3 otherwise pos3 target is ignored</param>
    /// <param name="target1">target position of axis 1</param>
    /// <param name="target2">target position of axis 2</param>
    /// <param name="target3">target position of axis 3</param>
    /// <returns>
    ///   [0] value_ref1: ref1 Status of axis 1
    ///   [1] value_ref2: ref2 Status of axis 2
    ///   [2] value_ref3: ref3 Status of axis 3
    ///   [3] value_refpos1: refpos1 reference Position of axis 1
    ///   [4] value_refpos2: refpos2 reference Position of axis 2
    ///   [5] value_refpos3: refpos3 reference Position of axis 3
    ///   [6] value_pos1: pos1 position of axis 1
    ///   [7] value_pos2: pos2 position of axis 2
    ///   [8] value_pos3: pos3 position of axis 3
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool, bool, int, int, int, Tuple<int, int, int>> Control_MultiAxisPositioning(bool set1, bool set2, bool set3, int target1, int target2, int target3) {
        object _parameterCommand = "com.attocube.amc.control.MultiAxisPositioning";

        object parameterset1 = set1;
        object parameterset2 = set2;
        object parameterset3 = set3;
        object parametertarget1 = target1;
        object parametertarget2 = target2;
        object parametertarget3 = target3;
        
        var ret = API_CallNineReturnValues<bool, bool, bool, int, int, int, int, int, int>(false, _parameterCommand, parameterset1, parameterset2, parameterset3, parametertarget1, parametertarget2, parametertarget3);

        
        return ret;
    }

    /// <summary>
    /// Simultaneously get 3 axes positions as well as the DC offset to maximize sampling rate over network
    /// </summary>
    /// <returns>
    ///   [0] value_pos1: pos1 position of axis 1
    ///   [1] value_pos2: pos2 position of axis 2
    ///   [2] value_pos3: pos3 position of axis 3
    ///   [3] value_val1: val1 dc voltage of of axis 1 in mV
    ///   [4] value_val2: val2 dc voltage of of axis 2 in mV
    ///   [5] value_val3: val3 dc voltage of of axis 3 in mV
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int, int, int, int, int> Control_GetPositionsAndVoltages() {
        object _parameterCommand = "com.attocube.amc.control.getPositionsAndVoltages";

        
        var ret = API_CallSixReturnValues<int, int, int, int, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Status of all axes, see getStatusMoving for coding of the values
    /// </summary>
    /// <returns>
    ///   [0] value_moving1: moving1 status of axis 1
    ///   [1] value_moving2: moving2 status of axis 2
    ///   [2] value_moving3: moving3 status of axis 3
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int, int> Control_GetStatusMovingAllAxes() {
        object _parameterCommand = "com.attocube.amc.control.getStatusMovingAllAxes";

        
        var ret = API_CallThreeReturnValues<int, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// This function sets the DC level output of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="amplitude_mv">in mV</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetControlFixOutputVoltage(int axis, int amplitude_mv) {
        object _parameterCommand = "com.attocube.amc.control.setControlFixOutputVoltage";

        object parameteraxis = axis;
        object parameteramplitude_mv = amplitude_mv;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameteramplitude_mv);

        
        
    }

    /// <summary>
    /// This function gets the DC level output of the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_amplitude_mv: amplitude_mv in mV
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetControlFixOutputVoltage(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getControlFixOutputVoltage";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Pull axis piezo drive to GND actively only in AMC300 this is used in MIC-Mode
    /// </summary>
    /// <param name="axis">motion controler axis [0|1|2]</param>
    /// <param name="enabled">true or false</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetGroundAxis(int axis, bool enabled) {
        object _parameterCommand = "com.attocube.amc.move.setGroundAxis";

        object parameteraxis = axis;
        object parameterenabled = enabled;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenabled);

        
        
    }

    /// <summary>
    /// Checks if the axis piezo drive is actively grounded only in AMC300
    /// </summary>
    /// <param name="axis">montion controler axis [0|1|2]</param>
    /// <returns>
    ///   [0] value_grounded: grounded true or false
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Move_GetGroundAxis(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getGroundAxis";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Pull axis piezo drive to GND actively if positioner is in ground target range only in AMC300 this is used in MIC-Mode
    /// </summary>
    /// <param name="axis">montion controler axis [0|1|2]</param>
    /// <param name="enabled">true or false</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetGroundAxisAutoOnTarget(int axis, bool enabled) {
        object _parameterCommand = "com.attocube.amc.move.setGroundAxisAutoOnTarget";

        object parameteraxis = axis;
        object parameterenabled = enabled;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenabled);

        
        
    }

    /// <summary>
    /// Pull axis piezo drive to GND if positioner is in ground target range only in AMC300
    /// </summary>
    /// <param name="axis">montion controler axis [0|1|2]</param>
    /// <returns>
    ///   [0] value_value: value true or false
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Move_GetGroundAxisAutoOnTarget(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getGroundAxisAutoOnTarget";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Retrieves the range around the target position in which the auto grounding becomes active.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_targetrange: targetrange in nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Move_GetGroundTargetRange(int axis) {
        object _parameterCommand = "com.attocube.amc.move.getGroundTargetRange";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Set  the range around the target position in which the auto grounding becomes active.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="range">in nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Move_SetGroundTargetRange(int axis, int range) {
        object _parameterCommand = "com.attocube.amc.move.setGroundTargetRange";

        object parameteraxis = axis;
        object parameterrange = range;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterrange);

        
        
    }

    /// <summary>
    /// Set sensor power supply status, can be switched off to save heat generated by sensor [NUM or RES] Positions retrieved will be invalid when activating this, so closed-loop control should be switched off beforehand
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="value">true if enabled, false otherwise</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetSensorEnabled(int axis, bool value) {
        object _parameterCommand = "com.attocube.amc.control.setSensorEnabled";

        object parameteraxis = axis;
        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametervalue);

        
        
    }

    /// <summary>
    /// Get sensot power supply status
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_value: value true if enabled, false otherwise
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Control_GetSensorEnabled(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getSensorEnabled";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the fine positioning DC-range
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_range: range in nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetFinePositioningRange(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getFinePositioningRange";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the fine positioning DC-range
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="range">in nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetFinePositioningRange(int axis, int range) {
        object _parameterCommand = "com.attocube.amc.control.setFinePositioningRange";

        object parameteraxis = axis;
        object parameterrange = range;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterrange);

        
        
    }

    /// <summary>
    /// This function gets the fine positioning slew rate
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_slewrate: slewrate [0|1|2|3]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Control_GetFinePositioningSlewRate(int axis) {
        object _parameterCommand = "com.attocube.amc.control.getFinePositioningSlewRate";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the fine positioning slew rate
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="slewrate">[0|1|2|3]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Control_SetFinePositioningSlewRate(int axis, int slewrate) {
        object _parameterCommand = "com.attocube.amc.control.setFinePositioningSlewRate";

        object parameteraxis = axis;
        object parameterslewrate = slewrate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterslewrate);

        
        
    }

    /// <summary>
    /// Start the diagnosis procedure for the given axis
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Diagnostic_StartDiagnostic(int axis) {
        object _parameterCommand = "com.attocube.amc.diagnostic.startDiagnostic";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Returns the results of the last diagnostic run and an error, if there was no run, it is currently running or the run failed
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_capacity: capacity in nF
    ///   [1] value_resistance: resistance in Ohm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Diagnostic_GetDiagnosticResults(int axis) {
        object _parameterCommand = "com.attocube.amc.diagnostic.getDiagnosticResults";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns the current power consumption
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] power: power
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Diagnostic_GetDiagnosticPower(int axis) {
        object _parameterCommand = "com.attocube.amc.diagnostic.getDiagnosticPower";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns the current axis temperature
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] temperature: temperature
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Diagnostic_GetDiagnosticTemperature(int axis) {
        object _parameterCommand = "com.attocube.amc.diagnostic.getDiagnosticTemperature";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Performs 10 steps in forward and backward and calculates the average step size in both directions on a specific axis
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] stepsize_fwd: stepsize_fwd
    ///   [1] stepsize_bwd: stepsize_bwd
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Diagnostic_GetDiagnosticStepSize(int axis) {
        object _parameterCommand = "com.attocube.amc.diagnostic.getDiagnosticStepSize";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Sets the mode of the RES position measurement This selects which frequency/ies are used for the lock-in measurement of the RES position, currently there are two possibilities: 1: Individual per axis: each axis is measured on a different frequency; this mode reduces noise coupling between axes, while requiring more wiring 2: Shared line/MIC-Mode: each axis is measured on the same frequency, which reduces the number of required wires while more coupling noise is excpected 3: Same as 1, but with overall lower frequencies.
    /// </summary>
    /// <param name="mode">1: Individual per axis, 2: Shared line mode, 3: Individual per axis (low frequency), 4: Shared line mode (low frequency)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Res_SetMode(int mode) {
        object _parameterCommand = "com.attocube.amc.res.setMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Get mode of RES application, see setMode for the description of possible parameters
    /// </summary>
    /// <returns>
    ///   [0] mode: mode
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Res_GetMode() {
        object _parameterCommand = "com.attocube.amc.res.getMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set signal chain gain to control overall power
    /// </summary>
    /// <param name="axis">number of axis</param>
    /// <param name="gainconfig">0: 0dB ( power 600mVpkpk^2/R), 1 : -10 dB , 2 : -15 dB , 3 : -20 dB</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Res_SetChainGain(int axis, int gainconfig) {
        object _parameterCommand = "com.attocube.amc.res.setChainGain";

        object parameteraxis = axis;
        object parametergainconfig = gainconfig;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametergainconfig);

        
        
    }

    /// <summary>
    /// Get chain gain, see setChainGain for parameter description
    /// </summary>
    /// <param name="axis">number of axis</param>
    /// <returns>
    ///   [0] gaincoeff: gaincoeff
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Res_GetChainGain(int axis) {
        object _parameterCommand = "com.attocube.amc.res.getChainGain";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// get the identifier of the loaded lookuptable (will be empty if disabled)
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_string: string : identifier
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Res_GetLutSn(int axis) {
        object _parameterCommand = "com.attocube.amc.res.getLutSn";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Load configuration file which either contains a JSON dict with parameters for the positioner on the axis or the LUT file itself (as legacy support for ANC350 .aps files)
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="content">JSON Dictionary or .aps File. The JSON Dictonary can/must contain the following keys: 'type': mandatory This field has to be one of the positioner list (see getPositionersList) 'lut': optional, contains an array of 1024 LUT values that are a mapping between ratio of the RES element travelled (0 to 1) and the corresponding absolute value at this ratio given in [nm]. Note: when generating these tables with position data in absolute units, the scaling of the travel ratio with the current sensor range has to be reversed. 'lut_sn': optional, a string to uniquely identify the loaded LUT</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Res_SetConfigurationFile(int axis, string content) {
        object _parameterCommand = "com.attocube.amc.res.setConfigurationFile";

        object parameteraxis = axis;
        object parametercontent = content;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametercontent);

        
        
    }

    /// <summary>
    /// Gets wether linearization is enabled or not
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled true when enabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Res_GetLinearization(int axis) {
        object _parameterCommand = "com.attocube.amc.res.getLinearization";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Control if linearization is enabled or not
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">boolean ( true: enable linearization)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Res_SetLinearization(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.res.setLinearization";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// Gets wether a valid RES position signal is present (always true for a disabled sensor and for rotators)
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_present: present true when present
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Res_GetSensorStatus(int axis) {
        object _parameterCommand = "com.attocube.amc.res.getSensorStatus";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// get the GPIO mode for Mic Mode feature
    /// </summary>
    /// <returns>
    ///   [0] value_gpio_mode: gpio_mode: 0: Standard GPIO 1: NSL-/Mic-Mode
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetGpioMode() {
        object _parameterCommand = "com.attocube.amc.rtin.getGpioMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// get the axis the NSL multiplexer is set to
    /// </summary>
    /// <returns>
    ///   [0] value_mux_mode: mux_mode  0: Off 1: Axis 1 2: Axis 2 3: Axis 3
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetNslMux() {
        object _parameterCommand = "com.attocube.amc.rtin.getNslMux";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// set the axis the NSL multiplexer is set to
    /// </summary>
    /// <param name="mux_mode">[0|1|2|3]  0: Off  1: Axis 1  2: Axis 2  3: Axis 3</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetNslMux(int mux_mode) {
        object _parameterCommand = "com.attocube.amc.rtin.setNslMux";

        object parametermux_mode = mux_mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermux_mode);

        
        
    }

    /// <summary>
    /// set the GPIO mode for Mic Mode feature
    /// </summary>
    /// <param name="gpio_mode">[0|1]  0: Standard GPIO  1: NSL-/Mic-Mode</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetGpioMode(int gpio_mode) {
        object _parameterCommand = "com.attocube.amc.rtin.setGpioMode";

        object parametergpio_mode = gpio_mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergpio_mode);

        
        
    }

    /// <summary>
    /// This function gets the AQuadB input resolution for setpoint parameter.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_resolution: resolution ion nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetControlAQuadBInResolution(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getControlAQuadBInResolution";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the AQuadB input resolution for setpoint parameter.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="resolution">ion nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetControlAQuadBInResolution(int axis, int resolution) {
        object _parameterCommand = "com.attocube.amc.rtin.setControlAQuadBInResolution";

        object parameteraxis = axis;
        object parameterresolution = resolution;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterresolution);

        
        
    }

    /// <summary>
    /// This function sets the real time input mode for the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="mode">see `RT_IN_MODES` @see realtime</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetRealTimeInMode(int axis, int mode) {
        object _parameterCommand = "com.attocube.amc.rtin.setRealTimeInMode";

        object parameteraxis = axis;
        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametermode);

        
        
    }

    /// <summary>
    /// This function sets or gets the real time input mode for the selected axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_mode: mode see `RT_IN_MODES`
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetRealTimeInMode(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getRealTimeInMode";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the change per pulse for the selected axis under real time input in the closed-loop mode.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="delta">to be added to current position in nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetRealTimeInChangePerPulse(int axis, int delta) {
        object _parameterCommand = "com.attocube.amc.rtin.setRealTimeInChangePerPulse";

        object parameteraxis = axis;
        object parameterdelta = delta;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterdelta);

        
        
    }

    /// <summary>
    /// This function gets the change per pulse for the selected axis under real time input in the closed-loop mode.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_resolution: resolution to be added in current pos in nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetRealTimeInChangePerPulse(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getRealTimeInChangePerPulse";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Set the change in step per pulse  of the realtime input when trigger and stepper mode is used only used in open loop operation
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="steps">number of steps to applied</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetRealTimeInStepsPerPulse(int axis, int steps) {
        object _parameterCommand = "com.attocube.amc.rtin.setRealTimeInStepsPerPulse";

        object parameteraxis = axis;
        object parametersteps = steps;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametersteps);

        
        
    }

    /// <summary>
    /// Get the change in step per pulse  of the realtime input when trigger and stepper mode is used
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_steps: steps number of steps to applied
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetRealTimeInStepsPerPulse(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getRealTimeInStepsPerPulse";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Set if the realtime function must operate in close loop operation or open loop operation
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="mode">0: open loop, 1 : close-loop</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetRealTimeInFeedbackLoopMode(int axis, int mode) {
        object _parameterCommand = "com.attocube.amc.rtin.setRealTimeInFeedbackLoopMode";

        object parameteraxis = axis;
        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametermode);

        
        
    }

    /// <summary>
    /// Get if the realtime function must operate in close loop operation or open loop operation
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_mode: mode 0: open loop, 1 : close-loop
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtin_GetRealTimeInFeedbackLoopMode(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getRealTimeInFeedbackLoopMode";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the status for real time input on the selected axis in closed-loop mode.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="enable">boolean true: eanble the approach , false: disable the approach</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_SetControlMoveGPIO(int axis, bool enable) {
        object _parameterCommand = "com.attocube.amc.rtin.setControlMoveGPIO";

        object parameteraxis = axis;
        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenable);

        
        
    }

    /// <summary>
    /// This function gets the status for real time input on the selected axis in closed-loop mode.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enable: enable boolean true: approach enabled , false: approach disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Rtin_GetControlMoveGPIO(int axis) {
        object _parameterCommand = "com.attocube.amc.rtin.getControlMoveGPIO";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Apply all realtime input function
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_Apply() {
        object _parameterCommand = "com.attocube.amc.rtin.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard all values beting set and not yet applieds
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtin_Discard() {
        object _parameterCommand = "com.attocube.amc.rtin.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set the real time output signal mode
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="mode">0: Off, 1: AquadB, 2: Trigger</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_SetMode(int axis, int mode) {
        object _parameterCommand = "com.attocube.amc.rtout.setMode";

        object parameteraxis = axis;
        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametermode);

        try {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Get Mode
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_mode: mode 0: Off, 1: AquadB, 2: Trigger
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtout_GetMode(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.getMode";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the real time output mode for the selected axis.
    /// </summary>
    /// <param name="mode">0: TTL, 1: LVDS</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_SetSignalMode(int mode) {
        object _parameterCommand = "com.attocube.amc.rtout.setSignalMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// This function gets the real time output mode for the selected axis.
    /// </summary>
    /// <param name="tempvalue"></param>
    /// <returns>
    ///   [0] value_mode: mode 0: TTL, 1: LVDS
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtout_GetSignalMode(int tempvalue) {
        object _parameterCommand = "com.attocube.amc.rtout.getSignalMode";

        object parametertempvalue = tempvalue;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempvalue);

        
        return ret;
    }

    /// <summary>
    /// Control the real time output trigger config
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="higher">upper limit in nm / Âµdeg</param>
    /// <param name="lower">lower limit in nm / Âµdeg</param>
    /// <param name="epsilon">hysteresis in nm / Âµdeg</param>
    /// <param name="polarity">0: active high, 1: active low</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_SetTriggerConfig(int axis, int higher, int lower, int epsilon, int polarity) {
        object _parameterCommand = "com.attocube.amc.rtout.setTriggerConfig";

        object parameteraxis = axis;
        object parameterhigher = higher;
        object parameterlower = lower;
        object parameterepsilon = epsilon;
        object parameterpolarity = polarity;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterhigher, parameterlower, parameterepsilon, parameterpolarity);

        
        
    }

    /// <summary>
    /// Get the real time output trigger config
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_higher: higher upper limit in nm / Âµdeg
    ///   [1] value_lower: lower lower limit in nm / Âµdeg
    ///   [2] value_epsilon: epsilon hysteresis in nm / Âµdeg
    ///   [3] value_polarity: polarity 0: active high, 1: active low
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int, int, int> Rtout_GetTriggerConfig(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.getTriggerConfig";

        object parameteraxis = axis;
        
        var ret = API_CallFourReturnValues<int, int, int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets if of AQuadB output for position indication is enabled
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_enabled: enabled boolean
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Rtout_GetControlAQuadBOut(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.getControlAQuadBOut";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function gets the AQuadB output resolution for position indication.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_resolution: resolution in nm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtout_GetControlAQuadBOutResolution(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.getControlAQuadBOutResolution";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the AQuadB output resolution for position indication.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="resolution">in nm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_SetControlAQuadBOutResolution(int axis, int resolution) {
        object _parameterCommand = "com.attocube.amc.rtout.setControlAQuadBOutResolution";

        object parameteraxis = axis;
        object parameterresolution = resolution;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterresolution);

        try {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// This function gets the clock for AQuadB output.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_clock_in_ns: clock_in_ns Clock in multiples of 20ns. Minimum 2 (40ns), maximum 65535 (1,310700ms)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Rtout_GetControlAQuadBOutClock(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.getControlAQuadBOutClock";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function sets the clock for AQuadB output.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="clock">Clock in multiples of 20ns. Minimum 2 (40ns), maximum 65535 (1,310700ms)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_SetControlAQuadBOutClock(int axis, int clock) {
        object _parameterCommand = "com.attocube.amc.rtout.setControlAQuadBOutClock";

        object parameteraxis = axis;
        object parameterclock = clock;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterclock);

        try {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.amc.rtout.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Apply for rtout function of specific axis
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_ApplyAxis(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.applyAxis";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Apply for all rtout function
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_Apply() {
        object _parameterCommand = "com.attocube.amc.rtout.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard rtout value of specific axis set by the set function(not applied yet)
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_DiscardAxis(int axis) {
        object _parameterCommand = "com.attocube.amc.rtout.discardAxis";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Discard value set by setSignalMode
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_DiscardSignalMode() {
        object _parameterCommand = "com.attocube.amc.rtout.discardSignalMode";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard all rtout value set by the set function(not applied yet)
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rtout_Discard() {
        object _parameterCommand = "com.attocube.amc.rtout.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the lower boundary of the soft limit protection.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC to get the soft limit status from</param>
    /// <returns>
    ///   [0] limit: Lower boundary in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Amcids_GetLowerSoftLimit(int axis) {
        object _parameterCommand = "com.attocube.amc.amcids.getLowerSoftLimit";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets whether the soft limit protection is enabled.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC to get the soft limit status from</param>
    /// <returns>
    ///   [0] enabled: True, if the soft limit should be enabled on this axis
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Amcids_GetSoftLimitEnabled(int axis) {
        object _parameterCommand = "com.attocube.amc.amcids.getSoftLimitEnabled";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets whether the current position is out of the soft limit boundaries.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC to get the soft limit status from</param>
    /// <returns>
    ///   [0] enabled: True, if the position is not within the boundaries
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Amcids_GetSoftLimitReached(int axis) {
        object _parameterCommand = "com.attocube.amc.amcids.getSoftLimitReached";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets the upper lower boundary of the soft limit protection.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC to get the soft limit status from</param>
    /// <returns>
    ///   [0] limit: Upper boundary in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Amcids_GetUpperSoftLimit(int axis) {
        object _parameterCommand = "com.attocube.amc.amcids.getUpperSoftLimit";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Resets the position value to zero of a specific measurement axis.    Use this for positioners with an IDS as sensor.    This method does not work for NUM and RES sensors. Use com.attocube.amc.control.resetAxis instead.
    /// </summary>
    /// <param name="axis">Axis of the IDS to reset the position</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Amcids_ResetIdsAxis(int axis) {
        object _parameterCommand = "com.attocube.amc.amcids.resetIdsAxis";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Sets the lower boundary of the soft limit protection in pm.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC where the soft limit should be changed</param>
    /// <param name="limit">Lower boundary in pm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Amcids_SetLowerSoftLimit(int axis, double limit) {
        object _parameterCommand = "com.attocube.amc.amcids.setLowerSoftLimit";

        object parameteraxis = axis;
        object parameterlimit = limit;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterlimit);

        
        
    }

    /// <summary>
    /// Enables/disables the soft limit protection.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC where the soft limit should be changed</param>
    /// <param name="enabled">True, if the soft limit should be enabled on this axis</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Amcids_SetSoftLimitEnabled(int axis, bool enabled) {
        object _parameterCommand = "com.attocube.amc.amcids.setSoftLimitEnabled";

        object parameteraxis = axis;
        object parameterenabled = enabled;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterenabled);

        
        
    }

    /// <summary>
    /// Sets the upper boundary of the soft limit protection in pm.    This protection is needed if the IDS working range is smaller than the positioners travel range.    It is no hard limit, so, it is possible to overshoot it!
    /// </summary>
    /// <param name="axis">Axis of the AMC where the soft limit should be changed</param>
    /// <param name="limit">Upper boundary in pm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Amcids_SetUpperSoftLimit(int axis, double limit) {
        object _parameterCommand = "com.attocube.amc.amcids.setUpperSoftLimit";

        object parameteraxis = axis;
        object parameterlimit = limit;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterlimit);

        
        
    }

    /// <summary>
    /// Checks if all three axis are in target range.
    /// </summary>
    /// <returns>
    ///   [0] in_target_range: true all three axes are in target range, false at least one axis is not in target range
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Rotcomp_GetControlTargetRanges() {
        object _parameterCommand = "com.attocube.amc.rotcomp.getControlTargetRanges";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the enabled status of the rotation compensation
    /// </summary>
    /// <returns>
    ///   [0] enabled: true Rotation compensation is enabled, false Rotation compensation is disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Rotcomp_GetEnabled() {
        object _parameterCommand = "com.attocube.amc.rotcomp.getEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the LUT file as JSON string
    /// </summary>
    /// <returns>
    ///   [0] lut: JSON string of the LUT file for the rotation compensation
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Rotcomp_GetLUT() {
        object _parameterCommand = "com.attocube.amc.rotcomp.getLUT";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enables and disables the rotation compensation
    /// </summary>
    /// <param name="enabled">true Rotation compensation is enabled, false Rotation compensation is disabled</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rotcomp_SetEnabled(bool enabled) {
        object _parameterCommand = "com.attocube.amc.rotcomp.setEnabled";

        object parameterenabled = enabled;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenabled);

        
        
    }

    /// <summary>
    /// Sets the LUT file from a JSON string
    /// </summary>
    /// <param name="lut_string">JSON string of the LUT file for the rotation compensation</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rotcomp_SetLUT(string lut_string) {
        object _parameterCommand = "com.attocube.amc.rotcomp.setLUT";

        object parameterlut_string = lut_string;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterlut_string);

        
        
    }

    /// <summary>
    /// Updates the start offsets of the axes
    /// </summary>
    /// <param name="offset_axis0">Offset of axis 1 in [nm]</param>
    /// <param name="offset_axis1">Offset of axis 2 in [nm]</param>
    /// <param name="offset_axis2">Offset of axis 3 in [nm]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Rotcomp_UpdateOffsets(int offset_axis0, int offset_axis1, int offset_axis2) {
        object _parameterCommand = "com.attocube.amc.rotcomp.updateOffsets";

        object parameteroffset_axis0 = offset_axis0;
        object parameteroffset_axis1 = offset_axis1;
        object parameteroffset_axis2 = offset_axis2;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset_axis0, parameteroffset_axis1, parameteroffset_axis2);

        
        
    }

    /// <summary>
    /// Resets the log    For debugging only.
    /// </summary>
    /// <param name="axis">Axis of the AMC</param>
    /// <param name="testname">Name of the test</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Test_ClearLog(int axis, string testname) {
        object _parameterCommand = "com.attocube.amc.test.clearLog";

        object parameteraxis = axis;
        object parametertestname = testname;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametertestname);

        
        
    }

    /// <summary>
    /// Starts a test run            For debugging only.                Error codes:                ERR_OK = 0                ERR_TEST_DOES_NOT_EXIST = -1                ERR_TEST_RUNNING = -2
    /// </summary>
    /// <param name="name">Name of the test, see getAllTest()</param>
    /// <param name="parameters">Parameters object as stringified JSON object, where "default" is the applied valueExample        "{            "axis": {                "friendlyName": "Axis",                "default": "0"            },            "mode": {                "friendlyName": "Mode",                "default": 0            },            "amplitude": {                "friendlyName": "Amplitude (V)",                "default": "45"            },            "frequency": {                "friendlyName": "Frequency (Hz)",                "default": "2000"            },            "cycles": {                "friendlyName": "Cycles",                "default": "3"            },            "random_range": {                "friendlyName": "Random range",                "default": 500000            },            "buffer": {                "friendlyName": "Buffer",                 "default": 2000            },            "sample_period": {                "friendlyName": "Sample period (ms)",                "default": "100"            }        }"</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Test_Execute(string name, string parameters) {
        object _parameterCommand = "com.attocube.amc.test.execute";

        object parametername = name;
        object parameterparameters = parameters;
        
        API_CallNoReturnValues(false, _parameterCommand, parametername, parameterparameters);

        
        
    }

    /// <summary>
    /// Request all names of the registered tests            For debugging only.
    /// </summary>
    /// <param name="axis"></param>
    /// <returns>
    ///   [0] tests: Jsonified list with all automatic testsExample"[    {        "name": "Velocity Test",        "parameters": {            "axis": {                "friendlyName": "Axis",                "default": "0"            },            "mode": {                "friendlyName": "Mode",                "default": 0            },            "amplitude": {                "friendlyName": "Amplitude (V)",                "default": "45"            },            "frequency": {                "friendlyName": "Frequency (Hz)",                "default": "2000"            },            "cycles": {                "friendlyName": "Cycles",                "default": "3"            },            "random_range": {                "friendlyName": "Random range",                "default": 500000            },            "buffer": {                "friendlyName": "Buffer",                 "default": 2000            },            "sample_period": {                "friendlyName": "Sample period (ms)",                "default": "100"            }        },         "version": "1.0.0",         "stoppable": true    }]", "version": "1.0.0", "stoppable": true}]""stoppable" tells the user if this test can be aborted while running
    ///   [1] manualTests: Jsonified list with all manual testsExample"[{"name": "Capacity Test", "parameters": {"capacity": "Capacity (nF)"}, "version": "1.0.0"}]"
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<string, string> Test_GetAllTests(int axis) {
        object _parameterCommand = "com.attocube.amc.test.getAllTests";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<string, string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets the complete log    For debugging only.
    /// </summary>
    /// <param name="axis">Axis of the AMC</param>
    /// <returns>
    ///   [0] logs: Log string json-encoded ({testname: log-str})
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Test_GetLog(int axis) {
        object _parameterCommand = "com.attocube.amc.test.getLog";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets the serial number of the positioner connected to a given axis.    For debugging only.
    /// </summary>
    /// <param name="axis"></param>
    /// <returns>
    ///   [0] sn: Serial number of positioner
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Test_GetPositionerSN(int axis) {
        object _parameterCommand = "com.attocube.amc.test.getPositionerSN";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Get test report of last test run of specific test    name == "all": the test reports of all tests from last test run will be returned    For debugging only.
    /// </summary>
    /// <param name="axis"></param>
    /// <param name="name">Name of the test or "all"</param>
    /// <returns>
    ///   [0] report: Test report json-serialized
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Test_GetReport(int axis, string name) {
        object _parameterCommand = "com.attocube.amc.test.getReport";

        object parameteraxis = axis;
        object parametername = name;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis, parametername);

        
        return ret;
    }

    /// <summary>
    /// Get the current execution status of the test sequencer    For debugging only.        Status:        IDLE = 0        RUNNING = 1        FINISHED = 2        FINISHED_CYCLE = 3
    /// </summary>
    /// <param name="axis"></param>
    /// <returns>
    ///   [0] status: Status
    ///   [1] test: Name of test which ran last
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, string> Test_GetStatus(int axis) {
        object _parameterCommand = "com.attocube.amc.test.getStatus";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Get test parameters the current test on the given axis is executed with            For debugging only.
    /// </summary>
    /// <param name="axis"></param>
    /// <returns>
    ///   [0] parameters: Parameters object as stringified JSON object where "default" is the applied parameterExample"{"axis":{"friendlyName":"Axis","default":0},"min_amplitude":{"friendlyName":"Min. amplitude (V)","default":"45"},"max_amplitude":{"friendlyName":"Max. amplitude (V)","default":"60"},"start_position":{"friendlyName":"Start position","default":0}}"
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Test_GetTestParameters(int axis) {
        object _parameterCommand = "com.attocube.amc.test.getTestParameters";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Gets the number of the Testplatz where the AMC belongs to    For debugging only.
    /// </summary>
    /// <returns>
    ///   [0] testplatz: Number of Testplatz
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Test_GetTestplatz() {
        object _parameterCommand = "com.attocube.amc.test.getTestplatz";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Sets the serial number of the positioner connected to a given axis.    For debugging only.
    /// </summary>
    /// <param name="axis">Axis the positioner is connected to</param>
    /// <param name="sn">Serial number of the positioner</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Test_SetPositionerSN(int axis, string sn) {
        object _parameterCommand = "com.attocube.amc.test.setPositionerSN";

        object parameteraxis = axis;
        object parametersn = sn;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametersn);

        
        
    }

    /// <summary>
    /// Sets the number of the Testplatz where the AMC belongs to    For debugging only.
    /// </summary>
    /// <param name="testplatz">Number of Testplatz</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Test_SetTestplatz(int testplatz) {
        object _parameterCommand = "com.attocube.amc.test.setTestplatz";

        object parametertestplatz = testplatz;
        
        API_CallNoReturnValues(false, _parameterCommand, parametertestplatz);

        
        
    }

    /// <summary>
    /// Stops the current test if it is stoppable    For debugging only.
    /// </summary>
    /// <param name="axis"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Test_StopCurrentTest(int axis) {
        object _parameterCommand = "com.attocube.amc.test.stopCurrentTest";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Grants access to a locked device for the requesting IP by checking against the password
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void GrantAccess(string password) {
        object _parameterCommand = "grantAccess";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function locks the device with a password, so the calling of functions is only possible with this password. The locking IP is automatically added to the devices which can access functions
    /// </summary>
    /// <param name="password">string the password to be set</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Lock(string password) {
        object _parameterCommand = "lock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function unlocks the device, so it will not be necessary to execute the grantAccess function to run any function
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Unlock(string password) {
        object _parameterCommand = "unlock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function returns if the device is locked and if the current client is authorized to use the device.
    /// </summary>
    /// <returns>
    ///   [0] value_locked: locked Is the device locked?
    ///   [1] value_authorized: authorized Is the client authorized?
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool> GetLockStatus() {
        object _parameterCommand = "getLockStatus";

        
        var ret = API_CallTwoReturnValues<bool, bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get list of packages installed on the device
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Comma separated list of packages
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetInstalledPackages() {
        object _parameterCommand = "com.attocube.system.about.getInstalledPackages";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the license for a specific package
    /// </summary>
    /// <param name="pckg">string: Package name</param>
    /// <returns>
    ///   [0] value_string: string: License for this package
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetPackageLicense(string pckg) {
        object _parameterCommand = "com.attocube.system.about.getPackageLicense";

        object parameterpckg = pckg;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpckg);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetSwUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getSwUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running license update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetLicenseUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getLicenseUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Execute the update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_SoftwareUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.softwareUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Upload new firmware image in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadSoftwareImageBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadSoftwareImageBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Upload new license file in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadLicenseBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadLicenseBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Execute the license update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_LicenseUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.licenseUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// If AMC is on Rack position 0, use it as DHCP server, else use it as DHCP client
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Functions_CheckAMCinRack() {
        object _parameterCommand = "com.attocube.system.functions.checkAMCinRack";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get the real IP address of the device set to the network interface (br0, eth1 or eth0)
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetRealIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getRealIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the IP address of the device
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the IP address of the device
    /// </summary>
    /// <param name="address">IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetIpAddress(string address) {
        object _parameterCommand = "com.attocube.system.network.setIpAddress";

        object parameteraddress = address;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraddress);

        
        
    }

    /// <summary>
    /// Get the subnet mask of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Subnet: Subnet mask as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetSubnetMask() {
        object _parameterCommand = "com.attocube.system.network.getSubnetMask";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the subnet mask of the device
    /// </summary>
    /// <param name="netmask">Subnet mask as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetSubnetMask(string netmask) {
        object _parameterCommand = "com.attocube.system.network.setSubnetMask";

        object parameternetmask = netmask;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternetmask);

        
        
    }

    /// <summary>
    /// Get the default gateway of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Default: Default gateway
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDefaultGateway() {
        object _parameterCommand = "com.attocube.system.network.getDefaultGateway";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the default gateway of the device
    /// </summary>
    /// <param name="gateway">Default gateway as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDefaultGateway(string gateway) {
        object _parameterCommand = "com.attocube.system.network.setDefaultGateway";

        object parametergateway = gateway;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergateway);

        
        
    }

    /// <summary>
    /// Get the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <returns>
    ///   [0] value_IP: IP address of DNS resolver
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDnsResolver(int priority) {
        object _parameterCommand = "com.attocube.system.network.getDnsResolver";

        object parameterpriority = priority;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpriority);

        
        return ret;
    }

    /// <summary>
    /// Set the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <param name="resolver">The resolver's IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDnsResolver(int priority, string resolver) {
        object _parameterCommand = "com.attocube.system.network.setDnsResolver";

        object parameterpriority = priority;
        object parameterresolver = resolver;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpriority, parameterresolver);

        
        
    }

    /// <summary>
    /// Get the proxy settings of the devide
    /// </summary>
    /// <returns>
    ///   [0] value_Proxy: Proxy Server String, empty for no proxy
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetProxyServer() {
        object _parameterCommand = "com.attocube.system.network.getProxyServer";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the proxy server of the device
    /// </summary>
    /// <param name="proxyServer">Proxy Server Setting as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetProxyServer(string proxyServer) {
        object _parameterCommand = "com.attocube.system.network.setProxyServer";

        object parameterproxyServer = proxyServer;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproxyServer);

        
        
    }

    /// <summary>
    /// Get the state of DHCP server
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP server enable, false = DHCP server disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpServer() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpServer";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP server
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP server, false = disable DHCP server</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpServer(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpServer";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Get the state of DHCP client
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP client enable, false = DHCP client disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpClient() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpClient";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP client
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP client, false = disable DHCP client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpClient(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpClient";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Apply temporary IP configuration and load it
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Apply() {
        object _parameterCommand = "com.attocube.system.network.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Verify that temporary IP configuration is correct
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Verify() {
        object _parameterCommand = "com.attocube.system.network.verify";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard temporary IP configuration
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Discard() {
        object _parameterCommand = "com.attocube.system.network.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Returns is a Wifi interface is present
    /// </summary>
    /// <returns>
    ///   [0] value_True: True, if interface is present
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetWifiPresent() {
        object _parameterCommand = "com.attocube.system.network.getWifiPresent";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the operation mode of the wifi adapter
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiMode(int mode) {
        object _parameterCommand = "com.attocube.system.network.setWifiMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Get the operation mode of the wifi adapter
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode 0: Access point, 1: Wifi client
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Network_GetWifiMode() {
        object _parameterCommand = "com.attocube.system.network.getWifiMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="ssid"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiSSID(string ssid) {
        object _parameterCommand = "com.attocube.system.network.setWifiSSID";

        object parameterssid = ssid;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterssid);

        
        
    }

    /// <summary>
    /// Get the the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] SSID: SSID
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiSSID() {
        object _parameterCommand = "com.attocube.system.network.getWifiSSID";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiPassphrase(string psk) {
        object _parameterCommand = "com.attocube.system.network.setWifiPassphrase";

        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpsk);

        
        
    }

    /// <summary>
    /// Get the the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] value_psk: psk Pre-shared key
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiPassphrase() {
        object _parameterCommand = "com.attocube.system.network.getWifiPassphrase";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the wifi configuration and applies it
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <param name="ssid"></param>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_ConfigureWifi(int mode, string ssid, string psk) {
        object _parameterCommand = "com.attocube.system.network.configureWifi";

        object parametermode = mode;
        object parameterssid = ssid;
        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode, parameterssid, parameterpsk);

        
        
    }

    /// <summary>
    /// Apply temporary system configuration
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Apply(int key) {
        object _parameterCommand = "com.attocube.system.apply";

        object parameterkey = key;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterkey);

        
        
    }

    /// <summary>
    /// Set custom name for the device
    /// </summary>
    /// <param name="name">string: device name</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetDeviceName(string name) {
        object _parameterCommand = "com.attocube.system.setDeviceName";

        object parametername = name;
        
        API_CallNoReturnValues(false, _parameterCommand, parametername);

        
        
    }

    /// <summary>
    /// Get the actual device name
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: actual device name
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetDeviceName() {
        object _parameterCommand = "com.attocube.system.getDeviceName";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reboot the system
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void RebootSystem() {
        object _parameterCommand = "com.attocube.system.rebootSystem";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Turns on the factory reset flag.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void FactoryReset() {
        object _parameterCommand = "com.attocube.system.factoryReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Performs a soft reset (Reset without deleting the network settings).
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SoftReset() {
        object _parameterCommand = "com.attocube.system.softReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get a description of an error code
    /// </summary>
    /// <param name="language">integer: Language code 0 for the error name, 1 for a more user friendly error message</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error description
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToString(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToString";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get a recommendation for the error code
    /// </summary>
    /// <param name="language">integer: Language code</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error recommendation (currently returning an int = 0 until we have recommendations)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToRecommendation(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToRecommendation";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get the firmware version of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: The firmware version
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFirmwareVersion() {
        object _parameterCommand = "com.attocube.system.getFirmwareVersion";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Return device hostname
    /// </summary>
    /// <returns>
    ///   [0] available: available
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetHostname() {
        object _parameterCommand = "com.attocube.system.getHostname";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the mac address of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Mac address of the system
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetMacAddress() {
        object _parameterCommand = "com.attocube.system.getMacAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the serial number of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Serial number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetSerialNumber() {
        object _parameterCommand = "com.attocube.system.getSerialNumber";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the flux code of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: flux code
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFluxCode() {
        object _parameterCommand = "com.attocube.system.getFluxCode";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Update system time by querying attocube.com
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void UpdateTimeFromInternet() {
        object _parameterCommand = "com.attocube.system.updateTimeFromInternet";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set system time manually
    /// </summary>
    /// <param name="day">integer: Day (1-31)</param>
    /// <param name="month">integer: Day (1-12)</param>
    /// <param name="year">integer: Day (eg. 2021)</param>
    /// <param name="hour">integer: Day (0-23)</param>
    /// <param name="minute">integer: Day (0-59)</param>
    /// <param name="second">integer: Day (0-59)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetTime(int day, int month, int year, int hour, int minute, int second) {
        object _parameterCommand = "com.attocube.system.setTime";

        object parameterday = day;
        object parametermonth = month;
        object parameteryear = year;
        object parameterhour = hour;
        object parameterminute = minute;
        object parametersecond = second;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterday, parametermonth, parameteryear, parameterhour, parameterminute, parametersecond);

        
        
    }

}
}