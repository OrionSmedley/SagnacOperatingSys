using System;

using Attocube.API;
using Attocube.API.Error;

namespace Attocube.IDS_1_0_0 {

public class AttocubeIDS : Attocube.API.AttocubeAPI {
    /// <summary>
    /// This function can be used to monitor the alignment contrast (peak-to-peak of the /nbasic interference signal amplitude) and the basline (its offset) during alignment /nmode.
    /// </summary>
    /// <param name="axis">Axis to get the value from [0..2]</param>
    /// <returns>
    ///   [0] value_contast: contast Contrast of the base band signal in permille
    ///   [1] value_baseline: baseline Offset of the contrast measurement in permille
    ///   [2] value_mixcontrast: mixcontrast lower contrast measurment when measuring a mix contrast (indicated by error code)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int, int> Adjustment_GetContrastInPermille(int axis) {
        object _parameterCommand = "com.attocube.ids.adjustment.getContrastInPermille";

        object parameteraxis = axis;
        
        var ret = API_CallThreeReturnValues<int, int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function can be used to see if the adjustment is running
    /// </summary>
    /// <returns>
    ///   [0] value_enable: enable true = enabled; false = disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Adjustment_GetAdjustmentEnabled() {
        object _parameterCommand = "com.attocube.ids.adjustment.getAdjustmentEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the current pass mode.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_mode: mode 0 = single; pass 1 = dual pass
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Axis_GetPassMode(int tempVal) {
        object _parameterCommand = "com.attocube.ids.axis.getPassMode";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the desired pass mode.
    /// </summary>
    /// <param name="mode">0 = single pass; 1 = dual pass</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Axis_SetPassMode(int mode) {
        object _parameterCommand = "com.attocube.ids.axis.setPassMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.axis.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.axis.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Returns the master axis (for more information please refer to the IDS User Manual).
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_masteraxis: masteraxis Axis which is operating as masteraxis [0..2]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Axis_GetMasterAxis(int tempVal) {
        object _parameterCommand = "com.attocube.ids.axis.getMasterAxis";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the master axis (for more information please refer to the IDS User Manual).
    /// </summary>
    /// <param name="axis">Axis which is operating as masteraxis [0..2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Axis_SetMasterAxis(int axis) {
        object _parameterCommand = "com.attocube.ids.axis.setMasterAxis";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.axis.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.axis.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Applies new axis settings.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Axis_Apply() {
        object _parameterCommand = "com.attocube.ids.axis.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discards new axis settings.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Axis_Discard() {
        object _parameterCommand = "com.attocube.ids.axis.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// This function can be used to see if the measurement is running
    /// </summary>
    /// <returns>
    ///   [0] value_enable: enable true = enabled; false = disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Displacement_GetMeasurementEnabled() {
        object _parameterCommand = "com.attocube.ids.displacement.getMeasurementEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads-out the averaging (lowpass) parameter N.
    /// </summary>
    /// <returns>
    ///   [0] value_averageN: averageN A value from 0 to 24
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Displacement_GetAverageN() {
        object _parameterCommand = "com.attocube.ids.displacement.getAverageN";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Sets the averaging (lowpass) parameter N.
    /// </summary>
    /// <param name="value">AverageN value from 0 to 24</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Displacement_SetAverageN(int value) {
        object _parameterCommand = "com.attocube.ids.displacement.setAverageN";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Important note: This function is not actively supported anymore.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <param name="fringesnbr">Number of fringes to be acquired</param>
    /// <param name="samplesperfringe">Number of samples per fringe</param>
    /// <param name="set">0 = evaluate current nonlinear amplitude /n1 = perform linearization and upload look up table /n2 = Clear look up table /n3 = Perform only calculation of Phi file</param>
    /// <returns>
    ///   [0] value_lintable: lintable String, which contains all 512 phase related correction values
    ///   [1] value_nonlinearamp: nonlinearamp String which contains the residual positive and negative maximal nonlinear amplitude
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Displacement_LinProc(int axis, int fringesnbr, int samplesperfringe, int set) {
        object _parameterCommand = "com.attocube.ids.displacement.linProc";

        object parameteraxis = axis;
        object parameterfringesnbr = fringesnbr;
        object parametersamplesperfringe = samplesperfringe;
        object parameterset = set;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis, parameterfringesnbr, parametersamplesperfringe, parameterset);

        
        return ret;
    }

    /// <summary>
    /// This function can be used to monitor the alignment contrast (peak-to-peak of the basic /ninterference signal amplitude) and the basline (its offset) during a running /nmeasurement.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_contrast: contrast Contrast of the base band signal in â€°
    ///   [1] value_baseline: baseline Offset of the contrast measurement in â€°
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Displacement_GetSignalQuality(int axis) {
        object _parameterCommand = "com.attocube.ids.displacement.getSignalQuality";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// This function can be used to monitor the alignment contrast (peak-to-peak of the basic /ninterference signal amplitude) and the basline (its offset) during a running /nmeasurement.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_contrast: contrast Contrast of the base band signal in â€°
    ///   [1] value_baseline: baseline Offset of the contrast measurement in â€°
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Displacement_GetAxisSignalQuality(int axis) {
        object _parameterCommand = "com.attocube.ids.displacement.getAxisSignalQuality";

        object parameteraxis = axis;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// The reference position information is estimated at the measurement initialization procedure or on reset.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_position: position reference position of the axis in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Displacement_GetReferencePosition(int axis) {
        object _parameterCommand = "com.attocube.ids.displacement.getReferencePosition";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// The reference position information is estimated at the measurement initialization procedure or on reset.
    /// </summary>
    /// <returns>
    ///   [0] value_position1: position0 position of the axis 0 in pm
    ///   [1] value_position2: position1 position of the axis 1 in pm
    ///   [2] value_position3: position2 position of the axis 2 in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Displacement_GetReferencePositions() {
        object _parameterCommand = "com.attocube.ids.displacement.getReferencePositions";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// The absolute position information is estimated at the measurement initialization procedure.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_position: position position of the axis in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Displacement_GetAbsolutePosition(int axis) {
        object _parameterCommand = "com.attocube.ids.displacement.getAbsolutePosition";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// The absolute position information is estimated at the measurement initialization /nprocedure.
    /// </summary>
    /// <returns>
    ///   [0] value_position1: position0 position of the axis 0 in pm
    ///   [1] value_position2: position1 position of the axis 1 in pm
    ///   [2] value_position3: position2 position of the axis 2 in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Displacement_GetAbsolutePositions() {
        object _parameterCommand = "com.attocube.ids.displacement.getAbsolutePositions";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the displacement value of a specific measurement axis.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <returns>
    ///   [0] value_displacement: displacement Displacement of the axis in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Displacement_GetAxisDisplacement(int axis) {
        object _parameterCommand = "com.attocube.ids.displacement.getAxisDisplacement";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the displacement values of all three measurement axes.
    /// </summary>
    /// <returns>
    ///   [0] value_displacement1: displacement0 displacement of the axis 0 in pm
    ///   [1] value_displacement2: displacement1 displacement of the axis 1 in pm
    ///   [2] value_displacement3: displacement2 displacement of the axis 2 in pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Displacement_GetAxesDisplacement() {
        object _parameterCommand = "com.attocube.ids.displacement.getAxesDisplacement";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enables the pilot laser.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Pilotlaser_Enable() {
        object _parameterCommand = "com.attocube.ids.pilotlaser.enable";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Disables the pilot laser.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Pilotlaser_Disable() {
        object _parameterCommand = "com.attocube.ids.pilotlaser.disable";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Reads out whether the pilot laser is enabled or not.
    /// </summary>
    /// <returns>
    ///   [0] value_enable: enable true = enabled; false = disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Pilotlaser_GetEnabled() {
        object _parameterCommand = "com.attocube.ids.pilotlaser.getEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the current realtime output mode.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_rtOutMode: rtOutMode 0 = HSSL (TTL), 1 = HSSL (LVDS), 2 = AquadB (TTL), /n3 = AquadB (LVDS), 4 = SinCos (TTL Error Signal), /n5 = SinCos (LVDS Error Signal), 6 = Linear (TTL), 7 = Linear (LVDS), /n8 = BiSS-C, 9 = Deactivated
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetRtOutMode(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getRtOutMode";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the real time output mode.
    /// </summary>
    /// <param name="value">rtOutMode 0 = HSSL (TTL), 1 = HSSL (LVDS), 2 = AquadB (TTL), /n3 = AquadB (LVDS), 4 = SinCos (TTL Error Signal), /n5 = SinCos (LVDS Error Signal), 6 = Linear (TTL), 7 = Linear (LVDS), /n8 = BiSS-C, 9 = Deactivated</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetRtOutMode(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setRtOutMode";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the distance mode.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_linearmode: linearmode 1 = Displacement (Available in HSSL mode and Linear Mode) /n2 = Absolute Distance (Available in HSSL mode only) /n3 = Vibrometry (Available in Linear mode)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetRtDistanceMode(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getRtDistanceMode";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the distance mode.
    /// </summary>
    /// <param name="value">1 = Displacement (HSSL mode and Linear Mode) /n2 = Absolute Distance (HSSL mode only) /n3 = Vibrometry (Linear mode)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetRtDistanceMode(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setRtDistanceMode";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the BissC resolution.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_resolution: resolution 1pm to 65535pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetResolutionBissC(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getResolutionBissC";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the BissC resolution.
    /// </summary>
    /// <param name="value">resolution 1pm to 65535pm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetResolutionBissC(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setResolutionBissC";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the HSSL resolution low bit.#
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_resolution: resolution Resolution in the range of [0..46]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetResolutionHsslLow(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getResolutionHsslLow";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the HSSL resolution low bit.
    /// </summary>
    /// <param name="value">Resolution in the Range of [0..46]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetResolutionHsslLow(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setResolutionHsslLow";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the HSSL resolution high bit.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_resolution: resolution Resolution in the Range of [0..46]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetResolutionHsslHigh(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getResolutionHsslHigh";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the HSSL resolution high bit.
    /// </summary>
    /// <param name="value">Resolution in the Range of [0..46]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetResolutionHsslHigh(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setResolutionHsslHigh";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the range number of Linear/Analog output mode.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_rangenumber: rangenumber N, Linear Analog Range is +-2^(N+11) pm, with N /in [0, 34]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetLinearRange(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getLinearRange";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the range number of Linear/Analog output mode.
    /// </summary>
    /// <param name="rangenumber">N, Linear Analog Range is +-2^(N+11) pm, with N /in [0, 34]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetLinearRange(int rangenumber) {
        object _parameterCommand = "com.attocube.ids.realtime.setLinearRange";

        object parameterrangenumber = rangenumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrangenumber);

        
        
    }

    /// <summary>
    /// Reads out the HSSL period clock.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_period: period Period in the Range of [40ns..10200ns]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetPeriodHsslClk(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getPeriodHsslClk";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Set the HSSL period clock.
    /// </summary>
    /// <param name="period">Period in the Range of [40ns..10200ns]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetPeriodHsslClk(int period) {
        object _parameterCommand = "com.attocube.ids.realtime.setPeriodHsslClk";

        object parameterperiod = period;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterperiod);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the HSSL period gap.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_gap: gap Number of clocks
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetPeriodHsslGap(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getPeriodHsslGap";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Set the HSSL gap.
    /// </summary>
    /// <param name="value">Number of clocks</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetPeriodHsslGap(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setPeriodHsslGap";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the Sine-Cosine and AquadB period clock.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_period: period 40ns to 10200ns
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetPeriodSinCosClk(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getPeriodSinCosClk";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the Sine-Cosine and AquadB period clock.
    /// </summary>
    /// <param name="value">period 40ns to 10200ns</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetPeriodSinCosClk(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setPeriodSinCosClk";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the Sine-Cosine and AquadB resolution.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_resolution: resolution 1pm to 65535pm
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetResolutionSinCos(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getResolutionSinCos";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the Sine-Cosine and AquadB resolution.
    /// </summary>
    /// <param name="value">resolution 1pm to 65535pm</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetResolutionSinCos(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setResolutionSinCos";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        try {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.apply");
        } catch (AttocubeAPIException e) {
            API_CallNoReturnValues(false, "com.attocube.ids.realtime.discard");
            throw e;
        }
        
        
    }

    /// <summary>
    /// Reads out the high pass filter number of Linear/Analog output mode.
    /// </summary>
    /// <param name="tempVal"></param>
    /// <returns>
    ///   [0] value_value: value N, Linear Analog High Pass Cut-Off freqency is 1600/2^N kHz, with N /in [1,24]
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetHighPassCutOffFreq(int tempVal) {
        object _parameterCommand = "com.attocube.ids.realtime.getHighPassCutOffFreq";

        object parametertempVal = tempVal;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parametertempVal);

        
        return ret;
    }

    /// <summary>
    /// Sets the high pass filter number of Linear/Analog output mode.
    /// </summary>
    /// <param name="value">N, Linear Analog High Pass Cut-Off freqency is 1600/2^N kHz, with N /in [1,24]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetHighPassCutOffFreq(int value) {
        object _parameterCommand = "com.attocube.ids.realtime.setHighPassCutOffFreq";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the anti-aliasing filter with assigned filter window.
    /// </summary>
    /// <param name="enabled">0 - disables the Anti-Aliasing Filter /n 1 - enables the Anti-Aliasing Filter</param>
    /// <param name="attenuation">[3-30] dB m f_nyquist</param>
    /// <param name="window">0 = Rectangular,/n 1 = Cosine,/n 2 = Cosine^2,/n 3 = Hamming,/n 4 = Raised Cosine,/n 5 = Automatic</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_SetAaf(int enabled, int attenuation, int window) {
        object _parameterCommand = "com.attocube.ids.realtime.setAaf";

        object parameterenabled = enabled;
        object parameterattenuation = attenuation;
        object parameterwindow = window;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenabled, parameterattenuation, parameterwindow);

        
        
    }

    /// <summary>
    /// Returns the current attenuation at f_nyquist of the anti-aliasing filter.
    /// </summary>
    /// <returns>
    ///   [0] value_attenuation: attenuation [3-30] dB m f_nyquist
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetAafAttenuation() {
        object _parameterCommand = "com.attocube.ids.realtime.getAafAttenuation";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Returns the current filter window of the anti-aliasing filter.
    /// </summary>
    /// <returns>
    ///   [0] value_window: window 0 = Rectangular,/n 1 = Cosine,/n 2 = Cosine^2,/n 3 = Hamming,/n 4 = Raised Cosine,/n 5 = Automatic
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Realtime_GetAafWindow() {
        object _parameterCommand = "com.attocube.ids.realtime.getAafWindow";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Checks if the anti-aliasing filter is enabled.
    /// </summary>
    /// <returns>
    ///   [0] value_enabled: enabled false: Anti-Aliasing Filter is disabled /ntrue: Anti-Aliasing Filter is enabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Realtime_AafIsEnabled() {
        object _parameterCommand = "com.attocube.ids.realtime.AafIsEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Checks if the anti-aliasing filter is enabled.
    /// </summary>
    /// <returns>
    ///   [0] value_enabled: enabled false - the Anti-Aliasing Filter is disabled /n true - the Anti-Aliasing Filter is enabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Realtime_GetAafEnabled() {
        object _parameterCommand = "com.attocube.ids.realtime.getAafEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Applies new real time settings.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_Apply() {
        object _parameterCommand = "com.attocube.ids.realtime.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discards new real time settings.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_Discard() {
        object _parameterCommand = "com.attocube.ids.realtime.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Enables the Test Channel, which can be used for estimating the maximum signal range.
    /// </summary>
    /// <param name="axis">Test Channel Master Axis</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_EnableTestChannel(int axis) {
        object _parameterCommand = "com.attocube.ids.realtime.enableTestChannel";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Disables the test channel.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Realtime_DisableTestChannel() {
        object _parameterCommand = "com.attocube.ids.realtime.disableTestChannel";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Checks if the test channel is enabled
    /// </summary>
    /// <returns>
    ///   [0] value_enabled: enabled true = enabled, false = disabled
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Realtime_GetTestChannelEnabled() {
        object _parameterCommand = "com.attocube.ids.realtime.getTestChannelEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Stops the displacement measurement system state.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_StopMeasurement() {
        object _parameterCommand = "com.attocube.ids.system.stopMeasurement";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the displacement measurement system state.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_StartMeasurement() {
        object _parameterCommand = "com.attocube.ids.system.startMeasurement";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the optical alignment system state.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_StartOpticsAlignment() {
        object _parameterCommand = "com.attocube.ids.system.startOpticsAlignment";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the optical alignment system state.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_StopOpticsAlignment() {
        object _parameterCommand = "com.attocube.ids.system.stopOpticsAlignment";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Resets the position value of all measurement axes to zero.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ResetAxes() {
        object _parameterCommand = "com.attocube.ids.system.resetAxes";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Resets the position value of a specific measurement axis to zero.
    /// </summary>
    /// <param name="axis">[0|1|2]</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ResetAxis(int axis) {
        object _parameterCommand = "com.attocube.ids.system.resetAxis";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Resets a measurement error that can have occurred with the aim to continue the interrupted measurement.
    /// </summary>
    /// <param name="perform">renormalization</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ResetError(bool perform) {
        object _parameterCommand = "com.attocube.ids.system.resetError";

        object parameterperform = perform;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterperform);

        
        
    }

    /// <summary>
    /// Reads out the current IDS system state.
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode Values: "system idle", "measurement starting", "measurement running", "optics alignment starting", "optics alignment running", "test channels enabled"
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetCurrentMode() {
        object _parameterCommand = "com.attocube.ids.system.getCurrentMode";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the IDS FPGA version.
    /// </summary>
    /// <returns>
    ///   [0] value_version: version Version in the form X.Y.Z
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFpgaVersion() {
        object _parameterCommand = "com.attocube.ids.system.getFpgaVersion";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the IDS device type.
    /// </summary>
    /// <returns>
    ///   [0] value_type: type Type of IDS (e.g. "IDS3010")
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDeviceType() {
        object _parameterCommand = "com.attocube.ids.system.getDeviceType";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Cheks for a system error.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_GetSystemError() {
        object _parameterCommand = "com.attocube.ids.system.getSystemError";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Reads out the amount of activated features activated on the IDS.
    /// </summary>
    /// <returns>
    ///   [0] value_nbr: nbr Gives the number of activated features.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetNbrFeaturesActivated() {
        object _parameterCommand = "com.attocube.ids.system.getNbrFeaturesActivated";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Converts the IDS feature number to its corresponding name.
    /// </summary>
    /// <param name="featurenumber">Number of feature</param>
    /// <returns>
    ///   [0] value_names: names The name of the corresponding feature
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFeaturesName(int featurenumber) {
        object _parameterCommand = "com.attocube.ids.system.getFeaturesName";

        object parameterfeaturenumber = featurenumber;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterfeaturenumber);

        
        return ret;
    }

    /// <summary>
    /// Returns the Initialization mode.
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode 0 = High Accuracy Initialization; 1 = Quick Initialization
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetInitMode() {
        object _parameterCommand = "com.attocube.ids.system.getInitMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Sets the mode for the initialization procedure that is performed when starting a measurement.
    /// </summary>
    /// <param name="mode">0 = High Accuracy Initialization; 1 = Quick Initialization</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_SetInitMode(int mode) {
        object _parameterCommand = "com.attocube.ids.system.setInitMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Reads out the manually configured humidity (compensation mode 1).
    /// </summary>
    /// <param name="axis">Axis to get the humidity for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] humidity: humidity in hPa
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Manual_GetHumidityInPercent(int axis) {
        object _parameterCommand = "com.attocube.ids.manual.getHumidityInPercent";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the manually configured Pressure (compensation mode 1).
    /// </summary>
    /// <param name="axis">Axis to get the pressure for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] pressure: pressure in hPa
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Manual_GetPressureInHPa(int axis) {
        object _parameterCommand = "com.attocube.ids.manual.getPressureInHPa";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the manually configured value for the refractive index (compensation mode 2).
    /// </summary>
    /// <param name="axis">Axis to get the mode for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] rindex: refractive index
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Manual_GetRefractiveIndex(int axis) {
        object _parameterCommand = "com.attocube.ids.manual.getRefractiveIndex";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the manually configured Temperature (compensation mode 1).
    /// </summary>
    /// <param name="axis">Axis to set the temperature for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] temperature: temperature in degree celsius
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Manual_GetTemperatureInDegrees(int axis) {
        object _parameterCommand = "com.attocube.ids.manual.getTemperatureInDegrees";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Sets the manually configured Humidity (compensation mode 1). The input range is defined to 0 to 100 % (valid range for the Ciddor Equation).
    /// </summary>
    /// <param name="axis">Axis to set the humidity for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <param name="humidity">humidity in Percent</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Manual_SetHumidityInPercent(int axis, double humidity) {
        object _parameterCommand = "com.attocube.ids.manual.setHumidityInPercent";

        object parameteraxis = axis;
        object parameterhumidity = humidity;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterhumidity);

        
        
    }

    /// <summary>
    /// Sets the manually configured Pressure (compensation mode 1). The input range is defined to 800 to 1200 hPa (valid range for the Ciddor Equation).
    /// </summary>
    /// <param name="axis">Axis to set the pressure for-Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <param name="pressure">pressure in hPa</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Manual_SetPressureInHPa(int axis, double pressure) {
        object _parameterCommand = "com.attocube.ids.manual.setPressureInHPa";

        object parameteraxis = axis;
        object parameterpressure = pressure;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterpressure);

        
        
    }

    /// <summary>
    /// Sets the refractive index for the direct mode (compensation mode 2). The input range is defined to be greater than 1.
    /// </summary>
    /// <param name="axis">Axis to set the mode for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <param name="rindex">refractive index</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Manual_SetRefractiveIndex(int axis, double rindex) {
        object _parameterCommand = "com.attocube.ids.manual.setRefractiveIndex";

        object parameteraxis = axis;
        object parameterrindex = rindex;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterrindex);

        
        
    }

    /// <summary>
    /// Sets the manually configured Temperature (compensation mode 1). The input range is defined to -40 to +100 °C (valid range for the Ciddor Equation).
    /// </summary>
    /// <param name="axis">Axis to set the temperature for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <param name="temperature">temperature in degree celcius</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Manual_SetTemperatureInDegrees(int axis, double temperature) {
        object _parameterCommand = "com.attocube.ids.manual.setTemperatureInDegrees";

        object parameteraxis = axis;
        object parametertemperature = temperature;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametertemperature);

        
        
    }

    /// <summary>
    /// Disables the ECU interface.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Ecu_Disable() {
        object _parameterCommand = "com.attocube.ids.ecu.disable";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Enables the ECU interface.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Ecu_Enable() {
        object _parameterCommand = "com.attocube.ids.ecu.enable";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Reads out whether the ECU interface is physically connected or not. Checking if the ECU is connected can only be done on an enabled ECU interface.
    /// </summary>
    /// <returns>
    ///   [0] connected: true if connected, false if not
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Ecu_GetConnected() {
        object _parameterCommand = "com.attocube.ids.ecu.getConnected";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out whether the ECU interface is enabled or not. Enabling the ECU interface is crucial for working with the ECU.
    /// </summary>
    /// <returns>
    ///   [0] enabled: true if enabled, false if not
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Ecu_GetEnabled() {
        object _parameterCommand = "com.attocube.ids.ecu.getEnabled";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the ECU measured air humidity in percent.
    /// </summary>
    /// <returns>
    ///   [0] humidity: humidity in %
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Ecu_GetHumidityInPercent() {
        object _parameterCommand = "com.attocube.ids.ecu.getHumidityInPercent";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the ECU measured air pressure in hPa.
    /// </summary>
    /// <returns>
    ///   [0] pressure: pressure in hPa
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Ecu_GetPressureInHPa() {
        object _parameterCommand = "com.attocube.ids.ecu.getPressureInHPa";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the ECU estimated refractive index for the current    ECU readings. To get the refractive index for other modes, please see    getRefractiveIndexForCompensation.
    /// </summary>
    /// <returns>
    ///   [0] rIndex: refractive index
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Ecu_GetRefractiveIndex() {
        object _parameterCommand = "com.attocube.ids.ecu.getRefractiveIndex";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reads out the compensation mode (see below) which is currently used for the environmental compensation.
    /// </summary>
    /// <param name="axis">Axis to get the mode for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] mode: mode see defintion in set function
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Ecu_GetRefractiveIndexCompensationMode(int axis) {
        object _parameterCommand = "com.attocube.ids.ecu.getRefractiveIndexCompensationMode";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the refractive index used according to the current environmental compensation mode for this axis.
    /// </summary>
    /// <param name="axis">Axis to get the refractive index for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <returns>
    ///   [0] rIndex: refractive index
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Ecu_GetRefractiveIndexForCompensation(int axis) {
        object _parameterCommand = "com.attocube.ids.ecu.getRefractiveIndexForCompensation";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Reads out the ECU measured air temperature in degrees Celsius.
    /// </summary>
    /// <returns>
    ///   [0] temperature: temperature in degrees C
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Ecu_GetTemperatureInDegrees() {
        object _parameterCommand = "com.attocube.ids.ecu.getTemperatureInDegrees";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Sets the refractive index mode.
    /// </summary>
    /// <param name="axis">Axis to set the mode for.Parameter has to be -1 for the moment,individual axes will be supported in the next firmware release</param>
    /// <param name="mode">mode can be 0 for direct ECU mode, 1 to take the manual values and calculate the refractive index from this or 2 to directly take the set refrative index</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Ecu_SetRefractiveIndexCompensationMode(int axis, int mode) {
        object _parameterCommand = "com.attocube.ids.ecu.setRefractiveIndexCompensationMode";

        object parameteraxis = axis;
        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametermode);

        
        
    }

    /// <summary>
    /// Deactivates the LUT and removes it from the device
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_ClearLut(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.clearLut";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Creates a new LUT for the given axis.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS where the LUT should be generated</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_CreateLut(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.createLut";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Estimates the nonlinearity error for the current device settings without changing or updating any settings.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the nonlinearity error is to be estimated</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_EstimateNonlinearities(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.estimateNonlinearities";

        object parameteraxis = axis;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis);

        
        
    }

    /// <summary>
    /// Returns the normalization mode of a specific axis.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the normalization mode is queried</param>
    /// <returns>
    ///   [0] mode: Normalization Mode    0    Dynamic normalization    1    Normalization frozen    2    Normalization mode determined by target velocity
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Nlc_GetDynamicNormalization(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getDynamicNormalization";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns a histogram of the measured nonlinearity errors obtained from the last call of createLut or estimateNonlinearites.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS</param>
    /// <returns>
    ///   [0] histogram: Json dumped histogram array
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Nlc_GetHistogram(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getHistogram";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns the LUT determined by createLut (which can be applied by setLutApplied).
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS</param>
    /// <returns>
    ///   [0] lut: Json dumped LUT array with 512 integers
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Nlc_GetLut(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getLut";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns whether a LUT is applied or not for a given axis.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the LUT apply rule is queried</param>
    /// <returns>
    ///   [0] apply: True, if LUT is applied on this axis else False
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Nlc_GetLutApplied(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getLutApplied";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns if a LUT is available and if warnings or errors occurred during creation.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the status of the LUT should be returned</param>
    /// <returns>
    ///   [0] status: True, if a LUT exists else False
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Nlc_GetLutStatus(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getLutStatus";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns the LUT created by estimateNonlinearities (read-only mode) to compensate the nonlinearity error of the device for the current device settings. If no estimation was created an array of zeros is returned.
    /// </summary>
    /// <returns>
    ///   [0] lut: Json dumped LUT array with 512 integers
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Nlc_GetNonlinearityEstimation() {
        object _parameterCommand = "com.attocube.ids.nlc.getNonlinearityEstimation";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Returns the raw lut created by createLut or estimateNonlinearites.    For debugging only.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS</param>
    /// <returns>
    ///   [0] raw_lut: Json dumped lut array
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Nlc_GetRawLut(int axis) {
        object _parameterCommand = "com.attocube.ids.nlc.getRawLut";

        object parameteraxis = axis;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameteraxis);

        
        return ret;
    }

    /// <summary>
    /// Returns the threshold velocity (in µm/s) for mode 2 of setDynamicNormalization.
    /// </summary>
    /// <returns>
    ///   [0] velocityOn: Velocity of the target in µm/s when to switch the normalization on (default: 10 µm/s)
    ///   [1] velocityOff: Velocity of the target in µm/s when to switch the normalization off (default: 5 µm/s)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> Nlc_GetVelocityThresholds() {
        object _parameterCommand = "com.attocube.ids.nlc.getVelocityThresholds";

        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Sets the normalization mode of a specific axis.
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the normalization mode should be set</param>
    /// <param name="mode">Normalization Mode    0    Dynamic normalization (default)    1    Normalization frozen (for slow target drifts)    2    Automatic alternation between mode 0 and 1 depending on the target velocity</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_SetDynamicNormalization(int axis, int mode) {
        object _parameterCommand = "com.attocube.ids.nlc.setDynamicNormalization";

        object parameteraxis = axis;
        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parametermode);

        
        
    }

    /// <summary>
    /// Uploads a LUT for a specific axis (which can be applied by setLutApplied)
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS</param>
    /// <param name="lut">Json dumped LUT array with 512 integers</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_SetLut(int axis, string lut) {
        object _parameterCommand = "com.attocube.ids.nlc.setLut";

        object parameteraxis = axis;
        object parameterlut = lut;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterlut);

        
        
    }

    /// <summary>
    /// Sets the apply rule for the given axis
    /// </summary>
    /// <param name="axis">Axis [0|1|2] of the IDS of which the apply rule should be set</param>
    /// <param name="apply">True for applying a LUT, False for disabling a LUT</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_SetLutApplied(int axis, bool apply) {
        object _parameterCommand = "com.attocube.ids.nlc.setLutApplied";

        object parameteraxis = axis;
        object parameterapply = apply;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraxis, parameterapply);

        
        
    }

    /// <summary>
    /// Sets the threshold velocity (in µm/s) for mode 2 of setDynamicNormalization. By default, the normalization in mode 2 is frozen for velocities below 5 µm/s and switched to dynamic mode for velocities above 10 µm/s.
    /// </summary>
    /// <param name="velocityOn">Velocity of the target in µm/s when to switch the normalization on (default: 10 µm/s)</param>
    /// <param name="velocityOff">Velocity of the target in µm/s when to switch the normalization off (default: 5 µm/s)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Nlc_SetVelocityThresholds(int velocityOn, int velocityOff) {
        object _parameterCommand = "com.attocube.ids.nlc.setVelocityThresholds";

        object parametervelocityOn = velocityOn;
        object parametervelocityOff = velocityOff;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervelocityOn, parametervelocityOff);

        
        
    }

    /// <summary>
    /// Grants access to a locked device for the requesting IP by checking against the password
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void GrantAccess(string password) {
        object _parameterCommand = "grantAccess";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function locks the device with a password, so the calling of functions is only possible with this password. The locking IP is automatically added to the devices which can access functions
    /// </summary>
    /// <param name="password">string the password to be set</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Lock(string password) {
        object _parameterCommand = "lock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function unlocks the device, so it will not be necessary to execute the grantAccess function to run any function
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Unlock(string password) {
        object _parameterCommand = "unlock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function returns if the device is locked and if the current client is authorized to use the device.
    /// </summary>
    /// <returns>
    ///   [0] value_locked: locked Is the device locked?
    ///   [1] value_authorized: authorized Is the client authorized?
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool> GetLockStatus() {
        object _parameterCommand = "getLockStatus";

        
        var ret = API_CallTwoReturnValues<bool, bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get list of packages installed on the device
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Comma separated list of packages
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetInstalledPackages() {
        object _parameterCommand = "com.attocube.system.about.getInstalledPackages";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the license for a specific package
    /// </summary>
    /// <param name="pckg">string: Package name</param>
    /// <returns>
    ///   [0] value_string: string: License for this package
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetPackageLicense(string pckg) {
        object _parameterCommand = "com.attocube.system.about.getPackageLicense";

        object parameterpckg = pckg;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpckg);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetSwUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getSwUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running license update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetLicenseUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getLicenseUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Execute the update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_SoftwareUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.softwareUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Upload new firmware image in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadSoftwareImageBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadSoftwareImageBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Upload new license file in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadLicenseBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadLicenseBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Execute the license update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_LicenseUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.licenseUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// If AMC is on Rack position 0, use it as DHCP server, else use it as DHCP client
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Functions_CheckAMCinRack() {
        object _parameterCommand = "com.attocube.system.functions.checkAMCinRack";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get the real IP address of the device set to the network interface (br0, eth1 or eth0)
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetRealIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getRealIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the IP address of the device
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the IP address of the device
    /// </summary>
    /// <param name="address">IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetIpAddress(string address) {
        object _parameterCommand = "com.attocube.system.network.setIpAddress";

        object parameteraddress = address;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraddress);

        
        
    }

    /// <summary>
    /// Get the subnet mask of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Subnet: Subnet mask as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetSubnetMask() {
        object _parameterCommand = "com.attocube.system.network.getSubnetMask";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the subnet mask of the device
    /// </summary>
    /// <param name="netmask">Subnet mask as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetSubnetMask(string netmask) {
        object _parameterCommand = "com.attocube.system.network.setSubnetMask";

        object parameternetmask = netmask;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternetmask);

        
        
    }

    /// <summary>
    /// Get the default gateway of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Default: Default gateway
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDefaultGateway() {
        object _parameterCommand = "com.attocube.system.network.getDefaultGateway";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the default gateway of the device
    /// </summary>
    /// <param name="gateway">Default gateway as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDefaultGateway(string gateway) {
        object _parameterCommand = "com.attocube.system.network.setDefaultGateway";

        object parametergateway = gateway;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergateway);

        
        
    }

    /// <summary>
    /// Get the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <returns>
    ///   [0] value_IP: IP address of DNS resolver
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDnsResolver(int priority) {
        object _parameterCommand = "com.attocube.system.network.getDnsResolver";

        object parameterpriority = priority;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpriority);

        
        return ret;
    }

    /// <summary>
    /// Set the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <param name="resolver">The resolver's IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDnsResolver(int priority, string resolver) {
        object _parameterCommand = "com.attocube.system.network.setDnsResolver";

        object parameterpriority = priority;
        object parameterresolver = resolver;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpriority, parameterresolver);

        
        
    }

    /// <summary>
    /// Get the proxy settings of the devide
    /// </summary>
    /// <returns>
    ///   [0] value_Proxy: Proxy Server String, empty for no proxy
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetProxyServer() {
        object _parameterCommand = "com.attocube.system.network.getProxyServer";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the proxy server of the device
    /// </summary>
    /// <param name="proxyServer">Proxy Server Setting as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetProxyServer(string proxyServer) {
        object _parameterCommand = "com.attocube.system.network.setProxyServer";

        object parameterproxyServer = proxyServer;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproxyServer);

        
        
    }

    /// <summary>
    /// Get the state of DHCP server
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP server enable, false = DHCP server disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpServer() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpServer";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP server
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP server, false = disable DHCP server</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpServer(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpServer";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Get the state of DHCP client
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP client enable, false = DHCP client disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpClient() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpClient";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP client
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP client, false = disable DHCP client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpClient(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpClient";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Apply temporary IP configuration and load it
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Apply() {
        object _parameterCommand = "com.attocube.system.network.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Verify that temporary IP configuration is correct
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Verify() {
        object _parameterCommand = "com.attocube.system.network.verify";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard temporary IP configuration
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Discard() {
        object _parameterCommand = "com.attocube.system.network.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Returns is a Wifi interface is present
    /// </summary>
    /// <returns>
    ///   [0] value_True: True, if interface is present
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetWifiPresent() {
        object _parameterCommand = "com.attocube.system.network.getWifiPresent";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the operation mode of the wifi adapter
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiMode(int mode) {
        object _parameterCommand = "com.attocube.system.network.setWifiMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Get the operation mode of the wifi adapter
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode 0: Access point, 1: Wifi client
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Network_GetWifiMode() {
        object _parameterCommand = "com.attocube.system.network.getWifiMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="ssid"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiSSID(string ssid) {
        object _parameterCommand = "com.attocube.system.network.setWifiSSID";

        object parameterssid = ssid;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterssid);

        
        
    }

    /// <summary>
    /// Get the the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] SSID: SSID
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiSSID() {
        object _parameterCommand = "com.attocube.system.network.getWifiSSID";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiPassphrase(string psk) {
        object _parameterCommand = "com.attocube.system.network.setWifiPassphrase";

        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpsk);

        
        
    }

    /// <summary>
    /// Get the the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] value_psk: psk Pre-shared key
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiPassphrase() {
        object _parameterCommand = "com.attocube.system.network.getWifiPassphrase";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the wifi configuration and applies it
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <param name="ssid"></param>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_ConfigureWifi(int mode, string ssid, string psk) {
        object _parameterCommand = "com.attocube.system.network.configureWifi";

        object parametermode = mode;
        object parameterssid = ssid;
        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode, parameterssid, parameterpsk);

        
        
    }

    /// <summary>
    /// Apply temporary system configuration
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Apply(int key) {
        object _parameterCommand = "com.attocube.system.apply";

        object parameterkey = key;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterkey);

        
        
    }

    /// <summary>
    /// Set custom name for the device
    /// </summary>
    /// <param name="name">string: device name</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetDeviceName(string name) {
        object _parameterCommand = "com.attocube.system.setDeviceName";

        object parametername = name;
        
        API_CallNoReturnValues(false, _parameterCommand, parametername);

        
        
    }

    /// <summary>
    /// Get the actual device name
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: actual device name
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetDeviceName() {
        object _parameterCommand = "com.attocube.system.getDeviceName";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reboot the system
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void RebootSystem() {
        object _parameterCommand = "com.attocube.system.rebootSystem";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Turns on the factory reset flag.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void FactoryReset() {
        object _parameterCommand = "com.attocube.system.factoryReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Performs a soft reset (Reset without deleting the network settings).
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SoftReset() {
        object _parameterCommand = "com.attocube.system.softReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get a description of an error code
    /// </summary>
    /// <param name="language">integer: Language code 0 for the error name, 1 for a more user friendly error message</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error description
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToString(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToString";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get a recommendation for the error code
    /// </summary>
    /// <param name="language">integer: Language code</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error recommendation (currently returning an int = 0 until we have recommendations)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToRecommendation(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToRecommendation";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get the firmware version of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: The firmware version
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFirmwareVersion() {
        object _parameterCommand = "com.attocube.system.getFirmwareVersion";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Return device hostname
    /// </summary>
    /// <returns>
    ///   [0] available: available
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetHostname() {
        object _parameterCommand = "com.attocube.system.getHostname";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the mac address of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Mac address of the system
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetMacAddress() {
        object _parameterCommand = "com.attocube.system.getMacAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the serial number of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Serial number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetSerialNumber() {
        object _parameterCommand = "com.attocube.system.getSerialNumber";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the flux code of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: flux code
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFluxCode() {
        object _parameterCommand = "com.attocube.system.getFluxCode";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Update system time by querying attocube.com
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void UpdateTimeFromInternet() {
        object _parameterCommand = "com.attocube.system.updateTimeFromInternet";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set system time manually
    /// </summary>
    /// <param name="day">integer: Day (1-31)</param>
    /// <param name="month">integer: Day (1-12)</param>
    /// <param name="year">integer: Day (eg. 2021)</param>
    /// <param name="hour">integer: Day (0-23)</param>
    /// <param name="minute">integer: Day (0-59)</param>
    /// <param name="second">integer: Day (0-59)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetTime(int day, int month, int year, int hour, int minute, int second) {
        object _parameterCommand = "com.attocube.system.setTime";

        object parameterday = day;
        object parametermonth = month;
        object parameteryear = year;
        object parameterhour = hour;
        object parameterminute = minute;
        object parametersecond = second;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterday, parametermonth, parameteryear, parameterhour, parameterminute, parametersecond);

        
        
    }

}
}