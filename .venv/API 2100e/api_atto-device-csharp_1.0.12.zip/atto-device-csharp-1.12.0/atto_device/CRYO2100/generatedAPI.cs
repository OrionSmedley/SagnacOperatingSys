using System;

using Attocube.API;
using Attocube.API.Error;

namespace Attocube.attoDry_1_0_0 {

public class AttocubeattoDry : Attocube.API.AttocubeAPI {
    /// <summary>
    /// Autotune heater PID
    /// </summary>
    /// <param name="channel">Channel number</param>
    /// <param name="tuningType">0 tune P, 1 tune PI, 2 tune PID</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_AutotunePID(int channel, int tuningType) {
        object _parameterCommand = "com.attocube.cryostat.interface.action.autotunePID";

        object parameterchannel = channel;
        object parametertuningType = tuningType;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametertuningType);

        
        
    }

    /// <summary>
    /// Cancels the current command
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_CancelCurrentCommand() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.cancelCurrentCommand";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get current command name
    /// </summary>
    /// <returns>
    ///   [0] current_command: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Action_GetCurrentCommand() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.getCurrentCommand";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get current command status
    /// </summary>
    /// <returns>
    ///   [0] current_command: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Action_GetCurrentCommandStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.getCurrentCommandStatus";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Action_GetGoToBaseRampRateSetting() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.getGoToBaseRampRateSetting";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Action_GetSampleExchangeRampRateSetting() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.getSampleExchangeRampRateSetting";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the event the cryostat waits for currently
    /// </summary>
    /// <returns>
    ///   [0] event: event the cryostat waits for
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Action_GetWaitForEvent() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.getWaitForEvent";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Cool down to base temperature
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_GoToBase() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.goToBase";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Cool down to base temperature with fixed ramp rate
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_GoToBaseSoft() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.goToBaseSoft";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Posts the event. See: getWaitForEvent()
    /// </summary>
    /// <param name="eventName"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_PostEvent(string eventName) {
        object _parameterCommand = "com.attocube.cryostat.interface.action.postEvent";

        object parametereventName = eventName;
        
        API_CallNoReturnValues(false, _parameterCommand, parametereventName);

        
        
    }

    /// <summary>
    /// Start sample exchange
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_SampleExchange() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.sampleExchange";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Start sample exchange with fixed ramp rate
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_SampleExchangeSoft() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.sampleExchangeSoft";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set sample ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_SetGoToBaseRampRateSetting(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.action.setGoToBaseRampRateSetting";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Set sample ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_SetSampleExchangeRampRateSetting(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.action.setSampleExchangeRampRateSetting";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Start shutdown
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_Shutdown() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.shutdown";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Switches magnets off
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Action_SwitchMagnetsOff() {
        object _parameterCommand = "com.attocube.cryostat.interface.action.switchMagnetsOff";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the condenser sensor calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Condenser_DownloadCalibrationCurve() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.downloadCalibrationCurve";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser sensor .340 calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Condenser_DownloadCalibrationCurve340() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.downloadCalibrationCurve340";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser heater all zones ramp rate
    /// </summary>
    /// <returns>
    ///   [0] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetHeaterAllZoneRampRates() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterAllZoneRampRates";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser heater default zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: 
    ///   [2] I: 
    ///   [3] D: 
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Condenser_GetHeaterDefaultZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterDefaultZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater heating mode
    /// </summary>
    /// <returns>
    ///   [0] mode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Condenser_GetHeaterHeatingMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterHeatingMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the condenser heater default zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Condenser_GetHeaterNumberOfDefaultZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterNumberOfDefaultZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the condenser heater zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Condenser_GetHeaterNumberOfZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterNumberOfZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater power
    /// </summary>
    /// <returns>
    ///   [0] power: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetHeaterPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser heater ramp data
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    ///   [1] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, double> Condenser_GetHeaterRampData() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterRampData";

        
        var ret = API_CallTwoReturnValues<bool, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater resistance
    /// </summary>
    /// <returns>
    ///   [0] resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetHeaterRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater status
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_GetHeaterStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterStatus";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the condenser heater wire resistance
    /// </summary>
    /// <returns>
    ///   [0] wire_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetHeaterWireRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterWireRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: 
    ///   [2] I: 
    ///   [3] D: 
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Condenser_GetHeaterZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getHeaterZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser input filter settings
    /// </summary>
    /// <returns>
    ///   [0] off_or_on: 
    ///   [1] point: 
    ///   [2] window: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, int, int> Condenser_GetInputFilterSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getInputFilterSettings";

        
        var ret = API_CallThreeReturnValues<bool, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater maximum power
    /// </summary>
    /// <returns>
    ///   [0] maxPower: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetMaxPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getMaxPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater PID values
    /// </summary>
    /// <returns>
    ///   [0] proportional: 
    ///   [1] integral: 
    ///   [2] derivative: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Condenser_GetPID() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getPID";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser heater ramp control status
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Condenser_GetRampControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getRampControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get condenser ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetRampRate() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getRampRate";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser temperature resistance
    /// </summary>
    /// <returns>
    ///   [0] condenser_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetResistance() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getResistance";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser set point
    /// </summary>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetSetPoint() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getSetPoint";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser heater status
    /// </summary>
    /// <returns>
    ///   [0] Status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Condenser_GetTempControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getTempControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the condenser temperature
    /// </summary>
    /// <returns>
    ///   [0] condenser_temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Condenser_GetTemperature() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.getTemperature";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set condenser heater ramp off
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_HeaterRampOff() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.heaterRampOff";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set condenser heater ramp on
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute 0.1 - 100</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_HeaterRampOn(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.heaterRampOn";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the condenser heater D value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetD(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setD";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set condenser heater all zones ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate for this zone 0.1 100 K/min</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetHeaterAllZoneRampRates(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setHeaterAllZoneRampRates";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Sets the condenser heater power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetHeaterPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setHeaterPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the condenser heater resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetHeaterRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setHeaterRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the condenser heater wire resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetHeaterWireRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setHeaterWireRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set condenser heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <param name="upperbound">Upper set point boundary of this zone in kelvin</param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <param name="manualOutput">Manual output for this zone 0 to 100%</param>
    /// <param name="heatingRange">Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetHeaterZoneSettings(int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setHeaterZoneSettings";

        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange);

        
        
    }

    /// <summary>
    /// Sets the condenser heater I value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetI(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setI";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the condenser input filter settings
    /// </summary>
    /// <param name="filterOn"></param>
    /// <param name="numberOfPoints"></param>
    /// <param name="windowSize"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetInputFilterSettings(bool filterOn, int numberOfPoints, int windowSize) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setInputFilterSettings";

        object parameterfilterOn = filterOn;
        object parameternumberOfPoints = numberOfPoints;
        object parameterwindowSize = windowSize;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterfilterOn, parameternumberOfPoints, parameterwindowSize);

        
        
    }

    /// <summary>
    /// Sets the condenser heater maximum power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetMaxPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setMaxPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the condenser heater P value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetP(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setP";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the condenser heater PID values
    /// </summary>
    /// <param name="proportional"></param>
    /// <param name="integral"></param>
    /// <param name="derivative"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetPID(double proportional, double integral, double derivative) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setPID";

        object parameterproportional = proportional;
        object parameterintegral = integral;
        object parameterderivative = derivative;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproportional, parameterintegral, parameterderivative);

        
        
    }

    /// <summary>
    /// Set condenser ramp rate
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetRampRate(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setRampRate";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the condenser set point
    /// </summary>
    /// <param name="setPoint"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_SetSetPoint(double setPoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.setSetPoint";

        object parametersetPoint = setPoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersetPoint);

        
        
    }

    /// <summary>
    /// Starts the condenser heater in open loop mode with the previously set power
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StartHeaterOpenLoopPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.startHeaterOpenLoopPower";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the condenser heater in zone mode
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StartHeaterZoneMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.startHeaterZoneMode";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set condenser heater ramp on
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StartRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.startRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the condenser heater control
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StartTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.startTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set condenser heater ramp off (same as heaterRampOff())
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StopRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.stopRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the condenser heater control
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_StopTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.stopTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the condenser sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_UploadCalibrationCurve(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.uploadCalibrationCurve";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Sets the condenser sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Condenser_UploadCalibrationCurve340(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.condenser.uploadCalibrationCurve340";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Closes the cryostat in valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Cryoinvalve_Close() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoInValve.close";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the cryostat in valve status
    /// </summary>
    /// <returns>
    ///   [0] cryostat_in_valve_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Cryoinvalve_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoInValve.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Opens the cryostat in valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Cryoinvalve_Open() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoInValve.open";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Closes the cryostat out valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Cryooutvalve_Close() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoOutValve.close";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the cryostat out valve status
    /// </summary>
    /// <returns>
    ///   [0] pump_valve_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Cryooutvalve_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoOutValve.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Opens the cryostat out valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Cryooutvalve_Open() {
        object _parameterCommand = "com.attocube.cryostat.interface.cryoOutValve.open";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Closes the dump in valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Dumpinvalve_Close() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpInValve.close";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the dump in valve status
    /// </summary>
    /// <returns>
    ///   [0] dump_in_valve_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Dumpinvalve_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpInValve.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Opens the dump in valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Dumpinvalve_Open() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpInValve.open";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Closes the dump out valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Dumpoutvalve_Close() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpOutValve.close";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the dump out valve status
    /// </summary>
    /// <returns>
    ///   [0] dump_out_valve_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Dumpoutvalve_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpOutValve.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// opens the dump out valve
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Dumpoutvalve_Open() {
        object _parameterCommand = "com.attocube.cryostat.interface.dumpOutValve.open";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the magnet sensor calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Magnet_DownloadCalibrationCurve() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.downloadCalibrationCurve";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnet sensor .340 calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Magnet_DownloadCalibrationCurve340() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.downloadCalibrationCurve340";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the factory defaults for the Ramp Rates
    /// </summary>
    /// <param name="index"></param>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] range: 
    ///   [1] rate: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double> Magnet_GetDefaultRampRate(int index, int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getDefaultRampRate";

        object parameterindex = index;
        object parameterchannel = channel;
        
        var ret = API_CallTwoReturnValues<double, double>(false, _parameterCommand, parameterindex, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Checks if Magnet is in driven Mode (equivalent to NOT getPersistentMode)
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] drivenMode_on_or_off: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetDrivenMode(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getDrivenMode";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Get whether the magnetic field is being controlled
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] field_control_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetFieldControl(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getFieldControl";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the current in the Leads but in Field units
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] field: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetFieldsInLeads(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getFieldsInLeads";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnetic field
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] field: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetH(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getH";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnetic field set point
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] setPoint: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetHSetPoint(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getHSetPoint";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnetic field set points
    /// </summary>
    /// <returns>
    ///   [0] setPointZ: 
    ///   [1] setPointY: 
    ///   [2] setPointX: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Magnet_GetHSetPoint3D() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getHSetPoint3D";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnetic field state for a channel
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] state: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Magnet_GetHState(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getHState";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnet input filter settings
    /// </summary>
    /// <returns>
    ///   [0] off_or_on: 
    ///   [1] point: 
    ///   [2] window: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, int, int> Magnet_GetInputFilterSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getInputFilterSettings";

        
        var ret = API_CallThreeReturnValues<bool, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Whether the cryo is currently in quench state
    /// </summary>
    /// <returns>
    ///   [0] state: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetIsInQuenchState() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getIsInQuenchState";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Checks if current is running in the PS Leads
    /// </summary>
    /// <returns>
    ///   [0] onOrOff: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetLeadsHot() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getLeadsHot";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Name of magnets
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] name: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Magnet_GetMagnetChannelName(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getMagnetChannelName";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the number of default RampRates
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] NumberOfRates: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Magnet_GetNumDefaultRampRates(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getNumDefaultRampRates";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Return the number of RampRates
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] num: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Magnet_GetNumRampRates(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getNumRampRates";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the number of magnets
    /// </summary>
    /// <returns>
    ///   [0] channels: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Magnet_GetNumberOfMagnetChannels() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getNumberOfMagnetChannels";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Checks if at least one of the power supply channels is paused
    /// </summary>
    /// <returns>
    ///   [0] paused: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetPause3D() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getPause3D";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Checks if Magnet is in persistent mode (equivalent to NOT getDrivenMode)
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] drivenMode_on_or_off: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetPersistentMode(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getPersistentMode";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets combined persistent mode
    /// </summary>
    /// <returns>
    ///   [0] present: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetPersistentMode3D() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getPersistentMode3D";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the state of the Persistent Heater
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] state: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetPersistentSwitchHeaterStatus(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getPersistentSwitchHeaterStatus";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets whether the persistent switch option is present for a channel
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] present: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Magnet_GetPersistentSwitchPresent(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getPersistentSwitchPresent";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Get ramp rate at index for channel
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="index"></param>
    /// <returns>
    ///   [0] range: 
    ///   [1] rate: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double> Magnet_GetRampRate(int channel, int index) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getRampRate";

        object parameterchannel = channel;
        object parameterindex = index;
        
        var ret = API_CallTwoReturnValues<double, double>(false, _parameterCommand, parameterchannel, parameterindex);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnet temperature resistance. There is only one for all magnets
    /// </summary>
    /// <returns>
    ///   [0] resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetResistance() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getResistance";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnet temperature. There is only one for all magnets
    /// </summary>
    /// <returns>
    ///   [0] temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetTemperature() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getTemperature";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the magnetic field voltage
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] field: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Magnet_GetVolt(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.getVolt";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Let's reset the quench event
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_ResetQuenchState() {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.resetQuenchState";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set driven mode for a specific channel
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="onOrOff">drivenMode on or off</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetDrivenMode(int channel, bool onOrOff) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setDrivenMode";

        object parameterchannel = channel;
        object parameteronOrOff = onOrOff;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parameteronOrOff);

        
        
    }

    /// <summary>
    /// Sets the magnetic field set point
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="setPoint"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetHSetPoint(int channel, double setPoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setHSetPoint";

        object parameterchannel = channel;
        object parametersetPoint = setPoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametersetPoint);

        
        
    }

    /// <summary>
    /// Sets the magnetic field set points
    /// </summary>
    /// <param name="setPointZ"></param>
    /// <param name="setPointY"></param>
    /// <param name="setPointX"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetHSetPoint3D(double setPointZ, double setPointY, double setPointX) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setHSetPoint3D";

        object parametersetPointZ = setPointZ;
        object parametersetPointY = setPointY;
        object parametersetPointX = setPointX;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersetPointZ, parametersetPointY, parametersetPointX);

        
        
    }

    /// <summary>
    /// Sets the magnet input filter settings
    /// </summary>
    /// <param name="filterOn"></param>
    /// <param name="numberOfPoints"></param>
    /// <param name="windowSize"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetInputFilterSettings(bool filterOn, int numberOfPoints, int windowSize) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setInputFilterSettings";

        object parameterfilterOn = filterOn;
        object parameternumberOfPoints = numberOfPoints;
        object parameterwindowSize = windowSize;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterfilterOn, parameternumberOfPoints, parameterwindowSize);

        
        
    }

    /// <summary>
    /// Sets the pause state of the power supply channels
    /// </summary>
    /// <param name="onOff"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetPause3D(bool onOff) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setPause3D";

        object parameteronOff = onOff;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteronOff);

        
        
    }

    /// <summary>
    /// Sets the combined persistent mode
    /// </summary>
    /// <param name="onOff"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetPersistentMode3D(bool onOff) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setPersistentMode3D";

        object parameteronOff = onOff;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteronOff);

        
        
    }

    /// <summary>
    /// Change the ramp rates
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="index"></param>
    /// <param name="range_this"></param>
    /// <param name="rate"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_SetRampRate(int channel, int index, double range_this, double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.setRampRate";

        object parameterchannel = channel;
        object parameterindex = index;
        object parameterrange_this = range_this;
        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parameterindex, parameterrange_this, parameterrate);

        
        
    }

    /// <summary>
    /// Starts the magnetic field control
    /// </summary>
    /// <param name="channel"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_StartFieldControl(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.startFieldControl";

        object parameterchannel = channel;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel);

        
        
    }

    /// <summary>
    /// Stops the magnetic field control
    /// </summary>
    /// <param name="channel"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_StopFieldControl(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.stopFieldControl";

        object parameterchannel = channel;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel);

        
        
    }

    /// <summary>
    /// Sets the magnet sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_UploadCalibrationCurve(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.uploadCalibrationCurve";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Sets the magnet sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Magnet_UploadCalibrationCurve340(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.magnet.uploadCalibrationCurve340";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Change the cryostat type
    /// </summary>
    /// <param name="newType"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Main_ChangeCryostatType(string newType) {
        object _parameterCommand = "com.attocube.cryostat.interface.main.changeCryostatType";

        object parameternewType = newType;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternewType);

        
        
    }

    /// <summary>
    /// Get all available cryostat types
    /// </summary>
    /// <returns>
    ///   [0] types: CSV string of types
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Main_GetAvailableCryostatTypes() {
        object _parameterCommand = "com.attocube.cryostat.interface.main.getAvailableCryostatTypes";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the cryostat in pressure
    /// </summary>
    /// <returns>
    ///   [0] cryostat_in_pressure: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Pressures_GetCryoInPressure() {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getCryoInPressure";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the cryostat out pressure
    /// </summary>
    /// <returns>
    ///   [0] cryostat_out_pressure: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Pressures_GetCryoOutPressure() {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getCryoOutPressure";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the dump pressure
    /// </summary>
    /// <returns>
    ///   [0] dump_pressure: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Pressures_GetDumpPressure() {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getDumpPressure";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample sensor calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Sample_DownloadCalibrationCurve() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.downloadCalibrationCurve";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample sensor .340 calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Sample_DownloadCalibrationCurve340() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.downloadCalibrationCurve340";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample heater all zones ramp rate
    /// </summary>
    /// <returns>
    ///   [0] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetHeaterAllZoneRampRates() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterAllZoneRampRates";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: P
    ///   [2] I: I
    ///   [3] D: D
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Sample_GetHeaterDefaultZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterDefaultZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater heating mode
    /// </summary>
    /// <returns>
    ///   [0] mode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Sample_GetHeaterHeatingMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterHeatingMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of sample heater default zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Sample_GetHeaterNumberOfDefaultZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterNumberOfDefaultZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the sample heater zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Sample_GetHeaterNumberOfZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterNumberOfZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater power
    /// </summary>
    /// <returns>
    ///   [0] power: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetHeaterPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample heater ramp data
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    ///   [1] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, double> Sample_GetHeaterRampData() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterRampData";

        
        var ret = API_CallTwoReturnValues<bool, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater resistance
    /// </summary>
    /// <returns>
    ///   [0] resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetHeaterRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater status
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_GetHeaterStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterStatus";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the sample heater wire resistance
    /// </summary>
    /// <returns>
    ///   [0] wire_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetHeaterWireRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterWireRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: P
    ///   [2] I: I
    ///   [3] D: D
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Sample_GetHeaterZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getHeaterZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample input filter settings
    /// </summary>
    /// <returns>
    ///   [0] off_or_on: 
    ///   [1] point: 
    ///   [2] window: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, int, int> Sample_GetInputFilterSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getInputFilterSettings";

        
        var ret = API_CallThreeReturnValues<bool, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater maximum power
    /// </summary>
    /// <returns>
    ///   [0] maxPower: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetMaxPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getMaxPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater PID values
    /// </summary>
    /// <returns>
    ///   [0] proportional: 
    ///   [1] integral: 
    ///   [2] derivative: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Sample_GetPID() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getPID";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the ramp control status
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Sample_GetRampControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getRampControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get sample ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetRampRate() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getRampRate";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample resistance
    /// </summary>
    /// <returns>
    ///   [0] sample_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetResistance() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getResistance";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample set point
    /// </summary>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetSetPoint() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getSetPoint";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample heater status
    /// </summary>
    /// <returns>
    ///   [0] status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Sample_GetTempControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getTempControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sample temperature
    /// </summary>
    /// <returns>
    ///   [0] sample_temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Sample_GetTemperature() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.getTemperature";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set sample heater ramp off
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_HeaterRampOff() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.heaterRampOff";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set sample heater ramp on
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute 0.1 - 100</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_HeaterRampOn(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.heaterRampOn";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the sample heater D value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetD(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setD";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set sample heater all zones ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate for this zone 0.1 100 K/min</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetHeaterAllZoneRampRates(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setHeaterAllZoneRampRates";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Sets the sample heater power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetHeaterPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setHeaterPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the sample heater resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetHeaterRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setHeaterRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the sample heater wire resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetHeaterWireRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setHeaterWireRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set sample heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <param name="upperbound">Upper set point boundary of this zone in kelvin</param>
    /// <param name="p_input">P</param>
    /// <param name="i_input">I</param>
    /// <param name="d_input">D</param>
    /// <param name="manualOutput">Manual output for this zone 0 to 100%</param>
    /// <param name="heatingRange">Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetHeaterZoneSettings(int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setHeaterZoneSettings";

        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange);

        
        
    }

    /// <summary>
    /// Sets the sample heater I value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetI(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setI";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the sample input filter settings
    /// </summary>
    /// <param name="filterOn"></param>
    /// <param name="numberOfPoints"></param>
    /// <param name="windowSize"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetInputFilterSettings(bool filterOn, int numberOfPoints, int windowSize) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setInputFilterSettings";

        object parameterfilterOn = filterOn;
        object parameternumberOfPoints = numberOfPoints;
        object parameterwindowSize = windowSize;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterfilterOn, parameternumberOfPoints, parameterwindowSize);

        
        
    }

    /// <summary>
    /// Sets the sample heater maximum power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetMaxPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setMaxPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the sample heater P value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetP(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setP";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the sample heater PID values
    /// </summary>
    /// <param name="proportional"></param>
    /// <param name="integral"></param>
    /// <param name="derivative"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetPID(double proportional, double integral, double derivative) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setPID";

        object parameterproportional = proportional;
        object parameterintegral = integral;
        object parameterderivative = derivative;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproportional, parameterintegral, parameterderivative);

        
        
    }

    /// <summary>
    /// Set sample ramp rate
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetRampRate(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setRampRate";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the sample set point
    /// </summary>
    /// <param name="setPoint"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_SetSetPoint(double setPoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.setSetPoint";

        object parametersetPoint = setPoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersetPoint);

        
        
    }

    /// <summary>
    /// Starts the sample heater in open loop mode with the previously set power
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StartHeaterOpenLoopPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.startHeaterOpenLoopPower";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the sample heater in zone mode
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StartHeaterZoneMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.startHeaterZoneMode";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Start controlling the ramping
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StartRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.startRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the sample heater
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StartTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.startTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stop controlling the ramping
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StopRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.stopRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the sample heater
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_StopTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.stopTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the sample sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_UploadCalibrationCurve(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.uploadCalibrationCurve";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Sets the sample sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Sample_UploadCalibrationCurve340(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.sample.uploadCalibrationCurve340";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Gets the scroll pump frequency
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_frequency: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Scrollpump_GetFrequency() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getFrequency";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the scroll pump status
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Scrollpump_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the scroll pump status as string
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_status_string: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Scrollpump_GetStatusString() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getStatusString";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Starts the scroll pump at full speed
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_StartFullSpeed() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.startFullSpeed";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the scroll pump at standby speed
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_StartStandbySpeed() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.startStandbySpeed";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the scroll pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_Stop() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.stop";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the Stage40K sensor calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Stage40k_DownloadCalibrationCurve() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.downloadCalibrationCurve";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K sensor .340 calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Stage40k_DownloadCalibrationCurve340() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.downloadCalibrationCurve340";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K heater all zones ramp rate
    /// </summary>
    /// <returns>
    ///   [0] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetHeaterAllZoneRampRates() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterAllZoneRampRates";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: 
    ///   [2] I: 
    ///   [3] D: 
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Stage40k_GetHeaterDefaultZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterDefaultZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater heating mode
    /// </summary>
    /// <returns>
    ///   [0] mode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Stage40k_GetHeaterHeatingMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterHeatingMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the Stage40K heater default zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Stage40k_GetHeaterNumberOfDefaultZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterNumberOfDefaultZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the Stage40K heater zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Stage40k_GetHeaterNumberOfZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterNumberOfZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater power
    /// </summary>
    /// <returns>
    ///   [0] power: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetHeaterPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K heater ramp data
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    ///   [1] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, double> Stage40k_GetHeaterRampData() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterRampData";

        
        var ret = API_CallTwoReturnValues<bool, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater resistance
    /// </summary>
    /// <returns>
    ///   [0] resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetHeaterRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater status
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_GetHeaterStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterStatus";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the Stage40K heater wire resistance
    /// </summary>
    /// <returns>
    ///   [0] wire_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetHeaterWireRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterWireRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: P
    ///   [2] I: I
    ///   [3] D: D
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Stage40k_GetHeaterZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getHeaterZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K input filter settings
    /// </summary>
    /// <returns>
    ///   [0] off_or_on: 
    ///   [1] point: 
    ///   [2] window: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, int, int> Stage40k_GetInputFilterSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getInputFilterSettings";

        
        var ret = API_CallThreeReturnValues<bool, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater maximum power
    /// </summary>
    /// <returns>
    ///   [0] maxPower: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetMaxPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getMaxPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater PID values
    /// </summary>
    /// <returns>
    ///   [0] proportional: 
    ///   [1] integral: 
    ///   [2] derivative: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Stage40k_GetPID() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getPID";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K heater ramp control status
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Stage40k_GetRampControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getRampControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get Stage40K ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetRampRate() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getRampRate";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K resistance
    /// </summary>
    /// <returns>
    ///   [0] Stage40K_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetResistance() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getResistance";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K set point
    /// </summary>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetSetPoint() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getSetPoint";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K heater status
    /// </summary>
    /// <returns>
    ///   [0] Status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Stage40k_GetTempControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getTempControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the Stage40K temperature
    /// </summary>
    /// <returns>
    ///   [0] Stage40K_temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Stage40k_GetTemperature() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.getTemperature";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set Stage40K heater ramp off
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_HeaterRampOff() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.heaterRampOff";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set Stage40K heater ramp on
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute 0.1 - 100</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_HeaterRampOn(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.heaterRampOn";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater D value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetD(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setD";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set Stage40K heater all zones ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate for this zone 0.1 100 K/min</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetHeaterAllZoneRampRates(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setHeaterAllZoneRampRates";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetHeaterPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setHeaterPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetHeaterRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setHeaterRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater wire resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetHeaterWireRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setHeaterWireRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set Stage40K heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <param name="upperbound">Upper set point boundary of this zone in kelvin</param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <param name="manualOutput">Manual output for this zone 0 to 100%</param>
    /// <param name="heatingRange">Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetHeaterZoneSettings(int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setHeaterZoneSettings";

        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater I value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetI(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setI";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the Stage40K input filter settings
    /// </summary>
    /// <param name="filterOn"></param>
    /// <param name="numberOfPoints"></param>
    /// <param name="windowSize"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetInputFilterSettings(bool filterOn, int numberOfPoints, int windowSize) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setInputFilterSettings";

        object parameterfilterOn = filterOn;
        object parameternumberOfPoints = numberOfPoints;
        object parameterwindowSize = windowSize;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterfilterOn, parameternumberOfPoints, parameterwindowSize);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater maximum power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetMaxPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setMaxPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater P value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetP(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setP";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the Stage40K heater PID values
    /// </summary>
    /// <param name="proportional"></param>
    /// <param name="integral"></param>
    /// <param name="derivative"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetPID(double proportional, double integral, double derivative) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setPID";

        object parameterproportional = proportional;
        object parameterintegral = integral;
        object parameterderivative = derivative;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproportional, parameterintegral, parameterderivative);

        
        
    }

    /// <summary>
    /// Set Stage40K ramp rate
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetRampRate(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setRampRate";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the Stage40K set point
    /// </summary>
    /// <param name="setPoint"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_SetSetPoint(double setPoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.setSetPoint";

        object parametersetPoint = setPoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersetPoint);

        
        
    }

    /// <summary>
    /// Starts the Stage40K heater in open loop mode with the previously set power
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StartHeaterOpenLoopPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.startHeaterOpenLoopPower";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the Stage40K heater in zone mode
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StartHeaterZoneMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.startHeaterZoneMode";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set Stage40K heater ramp control on
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StartRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.startRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the Stage40K heater
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StartTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.startTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set Stage40K heater ramp control off (same as heaterRampOff())
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StopRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.stopRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the Stage40K heater
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_StopTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.stopTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the Stage40K sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_UploadCalibrationCurve(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.uploadCalibrationCurve";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Sets the Stage40K sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Stage40k_UploadCalibrationCurve340(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.stage40k.uploadCalibrationCurve340";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Empty database! This solved issues when the UI is hanging! Don't use it otherwise
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_EmptyExternalDatabaseToMaximumBytes() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.emptyExternalDatabaseToMaximumBytes";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// “Translate” the error code into an error text    Currently we only support the system language
    /// </summary>
    /// <param name="errorNumber">error code to translate</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ErrorNumberToString(int errorNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.errorNumberToString";

        object parametererrorNumber = errorNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parametererrorNumber);

        
        
    }

    /// <summary>
    /// Get the hardware autoprobe information
    /// </summary>
    /// <returns>
    ///   [0] infoJson: JSONd autoprobe information
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetAutoprobeInformationJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getAutoprobeInformationJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets all available configuration settings
    /// </summary>
    /// <returns>
    ///   [0] Configuration_settings: CSV of configuration settings
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetAvailableConfigurationSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getAvailableConfigurationSettings";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the EEPROM JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()    and getConfigurationSettingInformation()
    /// </summary>
    /// <returns>
    ///   [0] overrideFile: String containing the override file
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigOverrideFile";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the configuration
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_value: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetConfigurationConfiguration(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationConfiguration";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Get the value of the specified configuration setting
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_setting_value: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetConfigurationSetting(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationSetting";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Gets the configuration setting info string
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_settings_information: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetConfigurationSettingInformation(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationSettingInformation";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Get the current cryostat status
    /// </summary>
    /// <returns>
    ///   [0] status: Cryostat status
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetCurrentStatusJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getCurrentStatusJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the query result
    /// </summary>
    /// <param name="handle"></param>
    /// <returns>
    ///   [0] result: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDatabaseAsyncQueryResult(int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseAsyncQueryResult";

        object parameterhandle = handle;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterhandle);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat database columns
    /// </summary>
    /// <param name="minRow"></param>
    /// <param name="maxRow"></param>
    /// <param name="columnNames">Empty string means all available columns</param>
    /// <returns>
    ///   [0] result_rows: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDatabaseColumnsMinMaxIntervalRows(int minRow, int maxRow, string columnNames) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseColumnsMinMaxIntervalRows";

        object parameterminRow = minRow;
        object parametermaxRow = maxRow;
        object parametercolumnNames = columnNames;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterminRow, parametermaxRow, parametercolumnNames);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <returns>
    ///   [0] maximumSecondsInLog: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetDatabaseMaximumLogSeconds() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMaximumLogSeconds";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the min and max rows.
    /// </summary>
    /// <param name="handle"></param>
    /// <returns>
    ///   [0] min_row: 
    ///   [1] max_row: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> System_GetDatabaseMinMaxResult(int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMinMaxResult";

        object parameterhandle = handle;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameterhandle);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <returns>
    ///   [0] minimumSecondsInLog: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetDatabaseMinimumLogSeconds() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMinimumLogSeconds";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the device type.
    /// </summary>
    /// <returns>
    ///   [0] type: type of the device
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDeviceType() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDeviceType";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the features of the cryostat.
    /// </summary>
    /// <returns>
    ///   [0] Feature_names: 
    ///   [1] Feature_descriptrions: 
    ///   [2] Feature_short_descriptrions: 
    ///   [3] Feature_display_names: 
    ///   [4] Feature_picture: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<string, string, string, string, string> System_GetFeatures() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeatures";

        
        var ret = API_CallFiveReturnValues<string, string, string, string, string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the active features of the cryostat.
    /// </summary>
    /// <returns>
    ///   [0] Feature_names: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFeaturesActivated() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeaturesActivated";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the features of the cryostat as a JSON string.
    /// </summary>
    /// <returns>
    ///   [0] JSON: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFeaturesJSON() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeaturesJSON";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <param name="secondsOld"></param>
    /// <param name="secondsNew"></param>
    /// <returns>
    ///   [0] intervalJson: JSONd description of cryo status in time interval
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetIntervalLongTermEntriesJSONd(double secondsOld, double secondsNew) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getIntervalLongTermEntriesJSONd";

        object parametersecondsOld = secondsOld;
        object parametersecondsNew = secondsNew;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersecondsOld, parametersecondsNew);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat status of a time interval
    /// </summary>
    /// <param name="secondsOld"></param>
    /// <param name="secondsNew"></param>
    /// <returns>
    ///   [0] Short_term_log_entries: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetIntervalShortTermEntriesJSONd(double secondsOld, double secondsNew) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getIntervalShortTermEntriesJSONd";

        object parametersecondsOld = secondsOld;
        object parametersecondsNew = secondsNew;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersecondsOld, parametersecondsNew);

        
        return ret;
    }

    /// <summary>
    /// Gets all available information on the last error
    /// </summary>
    /// <returns>
    ///   [0] lastErrorNumber: Last error number
    ///   [1] recommendation: Recommendation
    ///   [2] component: Component that raised the error
    ///   [3] command: Command
    ///   [4] age: Age
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, string, string, string, int> System_GetLastError() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastError";

        
        var ret = API_CallFiveReturnValues<int, string, string, string, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the age of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] age: time in seconds since the last error happened
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetLastErrorAge() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorAge";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the command of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] command: command running when the last error happened
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorCommand() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorCommand";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the component of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] component: cryostat component of the error
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorComponent() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorComponent";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the error number of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] errorNumber: No error = 0
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetLastErrorNumber() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorNumber";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the recommendation of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] recommendation: error recommendation
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorRecommendation() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorRecommendation";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the last cryostat errors as a JSON string.
    /// </summary>
    /// <returns>
    ///   [0] JSON: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorsJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorsJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the last cryostat errors from the snapshot.    Use getLastErrorsAsJSON() and unJSON the data if this call doesn't work for you    (the cryostat data can't be unpickled)
    /// </summary>
    /// <param name="pythonVersion"></param>
    /// <returns>
    ///   [0] Pickled_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorsPickled(int pythonVersion) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorsPickled";

        object parameterpythonVersion = pythonVersion;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpythonVersion);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of the last seconds
    /// </summary>
    /// <param name="seconds"></param>
    /// <returns>
    ///   [0] version: firmware version number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastLongTermEntriesJSONd(double seconds) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastLongTermEntriesJSONd";

        object parameterseconds = seconds;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterseconds);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat status of the last seconds
    /// </summary>
    /// <param name="seconds"></param>
    /// <returns>
    ///   [0] version: firmware version number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastShortTermEntriesJSONd(double seconds) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastShortTermEntriesJSONd";

        object parameterseconds = seconds;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterseconds);

        
        return ret;
    }

    /// <summary>
    /// Get the last lines of the system logfile.
    /// </summary>
    /// <param name="maxBytes">maximum bytes to read</param>
    /// <returns>
    ///   [0] logLines: String containing the logfile lines
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLogLines(int maxBytes) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLogLines";

        object parametermaxBytes = maxBytes;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametermaxBytes);

        
        return ret;
    }

    /// <summary>
    /// Gets the seconds from start of cryostat installation
    /// </summary>
    /// <returns>
    ///   [0] seconds: Seconds from start of cryostat installation
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetSecondsFromStartCryostatInstallation() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getSecondsFromStartCryostatInstallation";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the user JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()     and getConfigurationSettingInformation()
    /// </summary>
    /// <returns>
    ///   [0] overrideFile: String containing the override file
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetUserConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getUserConfigOverrideFile";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Resets the last error
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_LowerError() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.lowerError";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Prepare the cryostat long term status of a time interval query
    /// </summary>
    /// <param name="minRow"></param>
    /// <param name="maxRow"></param>
    /// <param name="columnNames">Empty string means all available columns</param>
    /// <param name="handle"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_PrepareDatabaseColumnsIntervalAsync(int minRow, int maxRow, string columnNames, int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.prepareDatabaseColumnsIntervalAsync";

        object parameterminRow = minRow;
        object parametermaxRow = maxRow;
        object parametercolumnNames = columnNames;
        object parameterhandle = handle;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterminRow, parametermaxRow, parametercolumnNames, parameterhandle);

        
        
    }

    /// <summary>
    /// Prepare the cryostat long term status of a time interval query    Get the row numbers with getDatabaseMinMaxResult()    Get the data with getDatabaseColumnsMinMaxIntervalRows()    minTime and maxTime can be taken from getDatabaseMinimumLogSeconds()  and getDatabaseMaximumLogSeconds()
    /// </summary>
    /// <param name="minTime"></param>
    /// <param name="maxTime"></param>
    /// <returns>
    ///   [0] handle: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_PrepareDatabaseMinMaxInterval(double minTime, double maxTime) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.prepareDatabaseMinMaxInterval";

        object parameterminTime = minTime;
        object parametermaxTime = maxTime;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameterminTime, parametermaxTime);

        
        return ret;
    }

    /// <summary>
    /// Copy the EEPROM config factory defaults to the user config
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ResetUserConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.resetUserConfigOverrideFile";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the configuration setting
    /// </summary>
    /// <param name="settingName"></param>
    /// <param name="settingValue"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_SetConfigurationSetting(string settingName, double settingValue) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.setConfigurationSetting";

        object parametersettingName = settingName;
        object parametersettingValue = settingValue;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersettingName, parametersettingValue);

        
        
    }

    /// <summary>
    /// Set the user JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()     and getConfigurationSettingInformation()
    /// </summary>
    /// <param name="fileContent">Contents of the config override file</param>
    /// <returns>
    ///   [0] hint_string: Free text string to give the caller some hints if things don't work
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_SetUserConfigOverrideFile(string fileContent) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.setUserConfigOverrideFile";

        object parameterfileContent = fileContent;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterfileContent);

        
        return ret;
    }

    /// <summary>
    /// Gets last autotune error
    /// </summary>
    /// <returns>
    ///   [0] Autotune_errorcode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Tboard_AutotunePIDError() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDError";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Check whether PID autotune is currently running
    /// </summary>
    /// <returns>
    ///   [0] running: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Tboard_AutotunePIDRunning() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDRunning";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets last autotune stage
    /// </summary>
    /// <returns>
    ///   [0] Autotune_errorcode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Tboard_AutotunePIDStage() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDStage";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sensor calibration curve
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Tboard_DownloadCalibrationCurve(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.downloadCalibrationCurve";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the sensor .340 calibration curve
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Tboard_DownloadCalibrationCurve340(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.downloadCalibrationCurve340";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] p_output: 
    ///   [1] i_output: 
    ///   [2] d_output: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Tboard_GetHeaterPIDChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterPIDChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetHeaterSetpointChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterSetpointChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get heater zone settings channel
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] upperbound: Upper temperature bound of zone
    ///   [1] p_output: 
    ///   [2] i_output: 
    ///   [3] d_output: 
    ///   [4] manualOutput: 
    ///   [5] heatingRange: 0 -> off, 1 -> attocube OEM on, 1 -> 335, 336 Low, , 2 -> 335, 336 Medium, , 3 -> 335, 336 High
    ///   [6] rampRate: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Tboard_GetHeaterZoneSettingsChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterZoneSettingsChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get raw sensor input.
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] Raw_sensor_input: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetRawSensorInput(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getRawSensorInput";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get resistance.
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] Resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetResistance(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getResistance";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get temperature.
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] Temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetTemperature(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getTemperature";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] isHeating: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Tboard_IsHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.isHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterPIDChannel(int channelNumber, double p_input, double i_input, double d_input) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterPIDChannel";

        object parameterchannelNumber = channelNumber;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterp_input, parameteri_input, parameterd_input);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="setpoint">Temperature set point</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterSetpointChannel(int channelNumber, double setpoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterSetpointChannel";

        object parameterchannelNumber = channelNumber;
        object parametersetpoint = setpoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parametersetpoint);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="zone"></param>
    /// <param name="upperbound">Upper temperature bound of zone</param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <param name="manualOutput"></param>
    /// <param name="heatingRange">0 -> off, 1 -> attocube OEM on, 1 -> 335, 336 Low, , 2 -> 335, 336 Medium, , 3 -> 335, 336 High</param>
    /// <param name="rampRate"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterZoneSettingsChannel(int channelNumber, int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange, double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterZoneSettingsChannel";

        object parameterchannelNumber = channelNumber;
        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange, parameterrampRate);

        
        
    }

    /// <summary>
    /// Start heating
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="power"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingOpenLoopChannel(int channelNumber, double power) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingOpenLoopChannel";

        object parameterchannelNumber = channelNumber;
        object parameterpower = power;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterpower);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingZoneModeChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingZoneModeChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Stop heating
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StopHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.stopHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Sets the sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="curveData">calibration data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_UploadCalibrationCurve(int channel, string curveData) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.uploadCalibrationCurve";

        object parameterchannel = channel;
        object parametercurveData = curveData;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametercurveData);

        
        
    }

    /// <summary>
    /// Sets the sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="curveData">calibration data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_UploadCalibrationCurve340(int channel, string curveData) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.uploadCalibrationCurve340";

        object parameterchannel = channel;
        object parametercurveData = curveData;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametercurveData);

        
        
    }

    /// <summary>
    /// Gets the vti sensor calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Vti_DownloadCalibrationCurve() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.downloadCalibrationCurve";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti sensor .340 calibration curve
    /// </summary>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Vti_DownloadCalibrationCurve340() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.downloadCalibrationCurve340";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get vti heater all zones ramp rate
    /// </summary>
    /// <returns>
    ///   [0] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetHeaterAllZoneRampRates() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterAllZoneRampRates";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get VTI heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: P
    ///   [2] I: I
    ///   [3] D: D
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Vti_GetHeaterDefaultZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterDefaultZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater heating mode
    /// </summary>
    /// <returns>
    ///   [0] mode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Vti_GetHeaterHeatingMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterHeatingMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the VTI heater default zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Vti_GetHeaterNumberOfDefaultZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterNumberOfDefaultZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the number of the VTI heater zones
    /// </summary>
    /// <returns>
    ///   [0] number_of_zones: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Vti_GetHeaterNumberOfZones() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterNumberOfZones";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater power
    /// </summary>
    /// <returns>
    ///   [0] power: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetHeaterPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get VTI heater ramp data
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    ///   [1] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, double> Vti_GetHeaterRampData() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterRampData";

        
        var ret = API_CallTwoReturnValues<bool, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater resistance
    /// </summary>
    /// <returns>
    ///   [0] resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetHeaterRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater status
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_GetHeaterStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterStatus";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the vti heater wire resistance
    /// </summary>
    /// <returns>
    ///   [0] wire_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetHeaterWireRes() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterWireRes";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get VTI heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <returns>
    ///   [0] upperbound: Upper set point boundary of this zone in kelvin
    ///   [1] P: 
    ///   [2] I: 
    ///   [3] D: 
    ///   [4] manualOutput: Manual output for this zone 0 to 100%
    ///   [5] heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
    ///   [6] rampRate: Ramp rate for this zone 0.1 100 K/min
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Vti_GetHeaterZoneSettings(int zone) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getHeaterZoneSettings";

        object parameterzone = zone;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterzone);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti input filter settings
    /// </summary>
    /// <returns>
    ///   [0] off_or_on: 
    ///   [1] point: 
    ///   [2] window: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, int, int> Vti_GetInputFilterSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getInputFilterSettings";

        
        var ret = API_CallThreeReturnValues<bool, int, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater maximum power
    /// </summary>
    /// <returns>
    ///   [0] maxPower: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetMaxPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getMaxPower";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater PID values
    /// </summary>
    /// <returns>
    ///   [0] proportional: 
    ///   [1] integral: 
    ///   [2] derivative: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Vti_GetPID() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getPID";

        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get current ramp control status of VTI heater
    /// </summary>
    /// <returns>
    ///   [0] OnOff: Ramp is on or off
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Vti_GetRampControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getRampControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get VTI ramp rate
    /// </summary>
    /// <returns>
    ///   [0] Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetRampRate() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getRampRate";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti temperature resistance
    /// </summary>
    /// <returns>
    ///   [0] vti_resistance: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetResistance() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getResistance";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti set point
    /// </summary>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetSetPoint() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getSetPoint";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti heater status
    /// </summary>
    /// <returns>
    ///   [0] Status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Vti_GetTempControlStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getTempControlStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the vti temperature
    /// </summary>
    /// <returns>
    ///   [0] vti_temperature: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Vti_GetTemperature() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.getTemperature";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set VTI heater ramp off
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_HeaterRampOff() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.heaterRampOff";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set VTI heater ramp on
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute 0.1 - 100</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_HeaterRampOn(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.heaterRampOn";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the vti heater D value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetD(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setD";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set vti heater all zones ramp rate
    /// </summary>
    /// <param name="rampRate">Ramp rate for this zone 0.1 100 K/min</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetHeaterAllZoneRampRates(double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setHeaterAllZoneRampRates";

        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrampRate);

        
        
    }

    /// <summary>
    /// Sets the vti heater power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetHeaterPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setHeaterPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the vti heater resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetHeaterRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setHeaterRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the vti heater wire resistance
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetHeaterWireRes(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setHeaterWireRes";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Set VTI heater zone settings
    /// </summary>
    /// <param name="zone">Zone number</param>
    /// <param name="upperbound">Upper set point boundary of this zone in kelvin</param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <param name="manualOutput">Manual output for this zone 0 to 100%</param>
    /// <param name="heatingRange">Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetHeaterZoneSettings(int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setHeaterZoneSettings";

        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange);

        
        
    }

    /// <summary>
    /// Sets the vti heater I value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetI(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setI";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the vti input filter settings
    /// </summary>
    /// <param name="filterOn"></param>
    /// <param name="numberOfPoints"></param>
    /// <param name="windowSize"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetInputFilterSettings(bool filterOn, int numberOfPoints, int windowSize) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setInputFilterSettings";

        object parameterfilterOn = filterOn;
        object parameternumberOfPoints = numberOfPoints;
        object parameterwindowSize = windowSize;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterfilterOn, parameternumberOfPoints, parameterwindowSize);

        
        
    }

    /// <summary>
    /// Sets the vti heater maximum power
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetMaxPower(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setMaxPower";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the vti heater P value
    /// </summary>
    /// <param name="value"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetP(double value) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setP";

        object parametervalue = value;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalue);

        
        
    }

    /// <summary>
    /// Sets the vti heater PID values
    /// </summary>
    /// <param name="proportional"></param>
    /// <param name="integral"></param>
    /// <param name="derivative"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetPID(double proportional, double integral, double derivative) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setPID";

        object parameterproportional = proportional;
        object parameterintegral = integral;
        object parameterderivative = derivative;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproportional, parameterintegral, parameterderivative);

        
        
    }

    /// <summary>
    /// Set VTI ramp rate
    /// </summary>
    /// <param name="rate">Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetRampRate(double rate) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setRampRate";

        object parameterrate = rate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterrate);

        
        
    }

    /// <summary>
    /// Sets the vti set point
    /// </summary>
    /// <param name="temperature"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_SetSetPoint(double temperature) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.setSetPoint";

        object parametertemperature = temperature;
        
        API_CallNoReturnValues(false, _parameterCommand, parametertemperature);

        
        
    }

    /// <summary>
    /// Starts the vti heater in open loop mode with the previously set power
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StartHeaterOpenLoopPower() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.startHeaterOpenLoopPower";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the vti heater in zone mode
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StartHeaterZoneMode() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.startHeaterZoneMode";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set VTI heater ramp control on
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StartRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.startRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the vti heater control
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StartTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.startTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set VTI heater ramp off (same as heaterRampOff())
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StopRampControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.stopRampControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the vti heater control
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_StopTempControl() {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.stopTempControl";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the vti sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="curveData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_UploadCalibrationCurve(string curveData) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.uploadCalibrationCurve";

        object parametercurveData = curveData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercurveData);

        
        
    }

    /// <summary>
    /// Sets the vti sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="calibrationData"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Vti_UploadCalibrationCurve340(string calibrationData) {
        object _parameterCommand = "com.attocube.cryostat.interface.vti.uploadCalibrationCurve340";

        object parametercalibrationData = calibrationData;
        
        API_CallNoReturnValues(false, _parameterCommand, parametercalibrationData);

        
        
    }

    /// <summary>
    /// Grants access to a locked device for the requesting IP by checking against the password
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void GrantAccess(string password) {
        object _parameterCommand = "grantAccess";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function locks the device with a password, so the calling of functions is only possible with this password. The locking IP is automatically added to the devices which can access functions
    /// </summary>
    /// <param name="password">string the password to be set</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Lock(string password) {
        object _parameterCommand = "lock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function unlocks the device, so it will not be necessary to execute the grantAccess function to run any function
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Unlock(string password) {
        object _parameterCommand = "unlock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function returns if the device is locked and if the current client is authorized to use the device.
    /// </summary>
    /// <returns>
    ///   [0] value_locked: locked Is the device locked?
    ///   [1] value_authorized: authorized Is the client authorized?
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool> GetLockStatus() {
        object _parameterCommand = "getLockStatus";

        
        var ret = API_CallTwoReturnValues<bool, bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get list of packages installed on the device
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Comma separated list of packages
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetInstalledPackages() {
        object _parameterCommand = "com.attocube.system.about.getInstalledPackages";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the license for a specific package
    /// </summary>
    /// <param name="pckg">string: Package name</param>
    /// <returns>
    ///   [0] value_string: string: License for this package
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetPackageLicense(string pckg) {
        object _parameterCommand = "com.attocube.system.about.getPackageLicense";

        object parameterpckg = pckg;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpckg);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetSwUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getSwUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running license update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetLicenseUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getLicenseUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Execute the update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_SoftwareUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.softwareUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Upload new firmware image in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadSoftwareImageBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadSoftwareImageBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Upload new license file in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadLicenseBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadLicenseBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Execute the license update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_LicenseUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.licenseUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// If AMC is on Rack position 0, use it as DHCP server, else use it as DHCP client
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Functions_CheckAMCinRack() {
        object _parameterCommand = "com.attocube.system.functions.checkAMCinRack";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get the real IP address of the device set to the network interface (br0, eth1 or eth0)
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetRealIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getRealIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the IP address of the device
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the IP address of the device
    /// </summary>
    /// <param name="address">IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetIpAddress(string address) {
        object _parameterCommand = "com.attocube.system.network.setIpAddress";

        object parameteraddress = address;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraddress);

        
        
    }

    /// <summary>
    /// Get the subnet mask of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Subnet: Subnet mask as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetSubnetMask() {
        object _parameterCommand = "com.attocube.system.network.getSubnetMask";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the subnet mask of the device
    /// </summary>
    /// <param name="netmask">Subnet mask as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetSubnetMask(string netmask) {
        object _parameterCommand = "com.attocube.system.network.setSubnetMask";

        object parameternetmask = netmask;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternetmask);

        
        
    }

    /// <summary>
    /// Get the default gateway of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Default: Default gateway
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDefaultGateway() {
        object _parameterCommand = "com.attocube.system.network.getDefaultGateway";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the default gateway of the device
    /// </summary>
    /// <param name="gateway">Default gateway as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDefaultGateway(string gateway) {
        object _parameterCommand = "com.attocube.system.network.setDefaultGateway";

        object parametergateway = gateway;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergateway);

        
        
    }

    /// <summary>
    /// Get the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <returns>
    ///   [0] value_IP: IP address of DNS resolver
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDnsResolver(int priority) {
        object _parameterCommand = "com.attocube.system.network.getDnsResolver";

        object parameterpriority = priority;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpriority);

        
        return ret;
    }

    /// <summary>
    /// Set the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <param name="resolver">The resolver's IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDnsResolver(int priority, string resolver) {
        object _parameterCommand = "com.attocube.system.network.setDnsResolver";

        object parameterpriority = priority;
        object parameterresolver = resolver;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpriority, parameterresolver);

        
        
    }

    /// <summary>
    /// Get the proxy settings of the devide
    /// </summary>
    /// <returns>
    ///   [0] value_Proxy: Proxy Server String, empty for no proxy
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetProxyServer() {
        object _parameterCommand = "com.attocube.system.network.getProxyServer";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the proxy server of the device
    /// </summary>
    /// <param name="proxyServer">Proxy Server Setting as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetProxyServer(string proxyServer) {
        object _parameterCommand = "com.attocube.system.network.setProxyServer";

        object parameterproxyServer = proxyServer;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproxyServer);

        
        
    }

    /// <summary>
    /// Get the state of DHCP server
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP server enable, false = DHCP server disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpServer() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpServer";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP server
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP server, false = disable DHCP server</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpServer(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpServer";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Get the state of DHCP client
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP client enable, false = DHCP client disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpClient() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpClient";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP client
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP client, false = disable DHCP client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpClient(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpClient";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Apply temporary IP configuration and load it
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Apply() {
        object _parameterCommand = "com.attocube.system.network.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Verify that temporary IP configuration is correct
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Verify() {
        object _parameterCommand = "com.attocube.system.network.verify";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard temporary IP configuration
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Discard() {
        object _parameterCommand = "com.attocube.system.network.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Returns is a Wifi interface is present
    /// </summary>
    /// <returns>
    ///   [0] value_True: True, if interface is present
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetWifiPresent() {
        object _parameterCommand = "com.attocube.system.network.getWifiPresent";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the operation mode of the wifi adapter
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiMode(int mode) {
        object _parameterCommand = "com.attocube.system.network.setWifiMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Get the operation mode of the wifi adapter
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode 0: Access point, 1: Wifi client
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Network_GetWifiMode() {
        object _parameterCommand = "com.attocube.system.network.getWifiMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="ssid"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiSSID(string ssid) {
        object _parameterCommand = "com.attocube.system.network.setWifiSSID";

        object parameterssid = ssid;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterssid);

        
        
    }

    /// <summary>
    /// Get the the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] SSID: SSID
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiSSID() {
        object _parameterCommand = "com.attocube.system.network.getWifiSSID";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiPassphrase(string psk) {
        object _parameterCommand = "com.attocube.system.network.setWifiPassphrase";

        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpsk);

        
        
    }

    /// <summary>
    /// Get the the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] value_psk: psk Pre-shared key
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiPassphrase() {
        object _parameterCommand = "com.attocube.system.network.getWifiPassphrase";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the wifi configuration and applies it
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <param name="ssid"></param>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_ConfigureWifi(int mode, string ssid, string psk) {
        object _parameterCommand = "com.attocube.system.network.configureWifi";

        object parametermode = mode;
        object parameterssid = ssid;
        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode, parameterssid, parameterpsk);

        
        
    }

    /// <summary>
    /// Apply temporary system configuration
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Apply(int key) {
        object _parameterCommand = "com.attocube.system.apply";

        object parameterkey = key;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterkey);

        
        
    }

    /// <summary>
    /// Set custom name for the device
    /// </summary>
    /// <param name="name">string: device name</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetDeviceName(string name) {
        object _parameterCommand = "com.attocube.system.setDeviceName";

        object parametername = name;
        
        API_CallNoReturnValues(false, _parameterCommand, parametername);

        
        
    }

    /// <summary>
    /// Get the actual device name
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: actual device name
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetDeviceName() {
        object _parameterCommand = "com.attocube.system.getDeviceName";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reboot the system
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void RebootSystem() {
        object _parameterCommand = "com.attocube.system.rebootSystem";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Turns on the factory reset flag.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void FactoryReset() {
        object _parameterCommand = "com.attocube.system.factoryReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Performs a soft reset (Reset without deleting the network settings).
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SoftReset() {
        object _parameterCommand = "com.attocube.system.softReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get a description of an error code
    /// </summary>
    /// <param name="language">integer: Language code 0 for the error name, 1 for a more user friendly error message</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error description
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToString(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToString";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get a recommendation for the error code
    /// </summary>
    /// <param name="language">integer: Language code</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error recommendation (currently returning an int = 0 until we have recommendations)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToRecommendation(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToRecommendation";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get the firmware version of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: The firmware version
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFirmwareVersion() {
        object _parameterCommand = "com.attocube.system.getFirmwareVersion";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Return device hostname
    /// </summary>
    /// <returns>
    ///   [0] available: available
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetHostname() {
        object _parameterCommand = "com.attocube.system.getHostname";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the mac address of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Mac address of the system
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetMacAddress() {
        object _parameterCommand = "com.attocube.system.getMacAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the serial number of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Serial number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetSerialNumber() {
        object _parameterCommand = "com.attocube.system.getSerialNumber";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the flux code of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: flux code
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFluxCode() {
        object _parameterCommand = "com.attocube.system.getFluxCode";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Update system time by querying attocube.com
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void UpdateTimeFromInternet() {
        object _parameterCommand = "com.attocube.system.updateTimeFromInternet";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set system time manually
    /// </summary>
    /// <param name="day">integer: Day (1-31)</param>
    /// <param name="month">integer: Day (1-12)</param>
    /// <param name="year">integer: Day (eg. 2021)</param>
    /// <param name="hour">integer: Day (0-23)</param>
    /// <param name="minute">integer: Day (0-59)</param>
    /// <param name="second">integer: Day (0-59)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetTime(int day, int month, int year, int hour, int minute, int second) {
        object _parameterCommand = "com.attocube.system.setTime";

        object parameterday = day;
        object parametermonth = month;
        object parameteryear = year;
        object parameterhour = hour;
        object parameterminute = minute;
        object parametersecond = second;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterday, parametermonth, parameteryear, parameterhour, parameterminute, parametersecond);

        
        
    }

}
}