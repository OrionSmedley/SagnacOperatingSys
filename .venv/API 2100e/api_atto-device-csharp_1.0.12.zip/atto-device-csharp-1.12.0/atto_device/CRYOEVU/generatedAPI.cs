using System;

using Attocube.API;
using Attocube.API.Error;

namespace Attocube.attoDry_1_0_0 {

public class AttocubeattoDry : Attocube.API.AttocubeAPI {
    /// <summary>
    /// Gets the compressor status
    /// </summary>
    /// <returns>
    ///   [0] compressor_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Compressor_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.compressor.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// starts the compressor
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Compressor_Start() {
        object _parameterCommand = "com.attocube.cryostat.interface.compressor.start";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// stops the compressor
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Compressor_Stop() {
        object _parameterCommand = "com.attocube.cryostat.interface.compressor.stop";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the heater power
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] heater_power: :param channelNumber:
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Heater_GetHeaterPower(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.heater.getHeaterPower";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Initialized the heater
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Heater_InitializeHeater(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.heater.initializeHeater";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Starts the heater in open loop mode with fixed power
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="power"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Heater_StartHeaterOpenLoopPower(int channelNumber, double power) {
        object _parameterCommand = "com.attocube.cryostat.interface.heater.startHeaterOpenLoopPower";

        object parameterchannelNumber = channelNumber;
        object parameterpower = power;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterpower);

        
        
    }

    /// <summary>
    /// Stops the heater
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Heater_StopHeater(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.heater.stopHeater";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Change the cryostat type
    /// </summary>
    /// <param name="newType"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Main_ChangeCryostatType(string newType) {
        object _parameterCommand = "com.attocube.cryostat.interface.main.changeCryostatType";

        object parameternewType = newType;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternewType);

        
        
    }

    /// <summary>
    /// Get all availabe cryostat types
    /// </summary>
    /// <returns>
    ///   [0] types: CSV string of types
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Main_GetAvailableCryostatTypes() {
        object _parameterCommand = "com.attocube.cryostat.interface.main.getAvailableCryostatTypes";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the membrane pump status
    /// </summary>
    /// <returns>
    ///   [0] membrane_pump_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Membranepump_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.membranePump.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the membrane pump status as string
    /// </summary>
    /// <returns>
    ///   [0] membrane_pump_status_string: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Membranepump_GetStatusString() {
        object _parameterCommand = "com.attocube.cryostat.interface.membranePump.getStatusString";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// starts the membrane pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Membranepump_Start() {
        object _parameterCommand = "com.attocube.cryostat.interface.membranePump.start";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// stops the membrane pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Membranepump_Stop() {
        object _parameterCommand = "com.attocube.cryostat.interface.membranePump.stop";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Gets the gauge type
    /// </summary>
    /// <param name="gaugeNumber">0..5</param>
    /// <returns>
    ///   [0] type: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Pressures_GetGaugeType(int gaugeNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getGaugeType";

        object parametergaugeNumber = gaugeNumber;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametergaugeNumber);

        
        return ret;
    }

    /// <summary>
    /// Gets the cryostat in pressure
    /// </summary>
    /// <param name="gaugeNumber">0..5</param>
    /// <returns>
    ///   [0] pressure: 
    ///   [1] voltage: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double> Pressures_GetPressureAndVoltage(int gaugeNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getPressureAndVoltage";

        object parametergaugeNumber = gaugeNumber;
        
        var ret = API_CallTwoReturnValues<double, double>(false, _parameterCommand, parametergaugeNumber);

        
        return ret;
    }

    /// <summary>
    /// Gets the voltage on that would be a pressure gauge
    /// </summary>
    /// <param name="gaugeNumber">0..5</param>
    /// <returns>
    ///   [0] pressure_voltage: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Pressures_GetPressureVoltage(int gaugeNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.getPressureVoltage";

        object parametergaugeNumber = gaugeNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parametergaugeNumber);

        
        return ret;
    }

    /// <summary>
    /// Sets the gauge type
    /// </summary>
    /// <param name="gaugeNumber">0..5</param>
    /// <param name="newType"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Pressures_SetGaugeType(int gaugeNumber, string newType) {
        object _parameterCommand = "com.attocube.cryostat.interface.pressures.setGaugeType";

        object parametergaugeNumber = gaugeNumber;
        object parameternewType = newType;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergaugeNumber, parameternewType);

        
        
    }

    /// <summary>
    /// Gets the scroll pump frequency
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_frequency: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Scrollpump_GetFrequency() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getFrequency";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the scroll pump status
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Scrollpump_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the scroll pump status as string
    /// </summary>
    /// <returns>
    ///   [0] scroll_pump_status_string: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Scrollpump_GetStatusString() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.getStatusString";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Starts the scroll pump at full speed
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_StartFullSpeed() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.startFullSpeed";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Starts the scroll pump at standby speed
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_StartStandbySpeed() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.startStandbySpeed";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the scroll pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Scrollpump_Stop() {
        object _parameterCommand = "com.attocube.cryostat.interface.scrollPump.stop";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Empty database! This solved issues when the UI is hanging! Don't use it otherwise
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_EmptyExternalDatabaseToMaximumBytes() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.emptyExternalDatabaseToMaximumBytes";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// “Translate” the error code into an error text    Currently we only support the system language
    /// </summary>
    /// <param name="errorNumber">error code to translate</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ErrorNumberToString(int errorNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.errorNumberToString";

        object parametererrorNumber = errorNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parametererrorNumber);

        
        
    }

    /// <summary>
    /// Get the hardware autoprobe information
    /// </summary>
    /// <returns>
    ///   [0] infoJson: JSONd autoprobe information
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetAutoprobeInformationJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getAutoprobeInformationJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets all available configuration settings
    /// </summary>
    /// <returns>
    ///   [0] Configuration_settings: CSV of configuration settings
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetAvailableConfigurationSettings() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getAvailableConfigurationSettings";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the EEPROM JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()    and getConfigurationSettingInformation()
    /// </summary>
    /// <returns>
    ///   [0] overrideFile: String containing the override file
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigOverrideFile";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the configuration
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_value: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetConfigurationConfiguration(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationConfiguration";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Get the value of the specified configuration setting
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_setting_value: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetConfigurationSetting(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationSetting";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Gets the configuration setting info string
    /// </summary>
    /// <param name="settingName"></param>
    /// <returns>
    ///   [0] Configuration_settings_information: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetConfigurationSettingInformation(string settingName) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getConfigurationSettingInformation";

        object parametersettingName = settingName;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersettingName);

        
        return ret;
    }

    /// <summary>
    /// Get the current cryostat status
    /// </summary>
    /// <returns>
    ///   [0] status: Cryostat status
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetCurrentStatusJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getCurrentStatusJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the query result
    /// </summary>
    /// <param name="handle"></param>
    /// <returns>
    ///   [0] result: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDatabaseAsyncQueryResult(int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseAsyncQueryResult";

        object parameterhandle = handle;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterhandle);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat database columns
    /// </summary>
    /// <param name="minRow"></param>
    /// <param name="maxRow"></param>
    /// <param name="columnNames">Empty string means all available columns</param>
    /// <returns>
    ///   [0] result_rows: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDatabaseColumnsMinMaxIntervalRows(int minRow, int maxRow, string columnNames) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseColumnsMinMaxIntervalRows";

        object parameterminRow = minRow;
        object parametermaxRow = maxRow;
        object parametercolumnNames = columnNames;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterminRow, parametermaxRow, parametercolumnNames);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <returns>
    ///   [0] maximumSecondsInLog: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetDatabaseMaximumLogSeconds() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMaximumLogSeconds";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the min and max rows.
    /// </summary>
    /// <param name="handle"></param>
    /// <returns>
    ///   [0] min_row: 
    ///   [1] max_row: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, int> System_GetDatabaseMinMaxResult(int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMinMaxResult";

        object parameterhandle = handle;
        
        var ret = API_CallTwoReturnValues<int, int>(false, _parameterCommand, parameterhandle);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <returns>
    ///   [0] minimumSecondsInLog: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetDatabaseMinimumLogSeconds() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDatabaseMinimumLogSeconds";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the device type.
    /// </summary>
    /// <returns>
    ///   [0] type: type of the device
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetDeviceType() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getDeviceType";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the features of the cryostat.
    /// </summary>
    /// <returns>
    ///   [0] Feature_names: 
    ///   [1] Feature_descriptrions: 
    ///   [2] Feature_short_descriptrions: 
    ///   [3] Feature_display_names: 
    ///   [4] Feature_picture: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<string, string, string, string, string> System_GetFeatures() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeatures";

        
        var ret = API_CallFiveReturnValues<string, string, string, string, string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the active features of the cryostat.
    /// </summary>
    /// <returns>
    ///   [0] Feature_names: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFeaturesActivated() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeaturesActivated";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the features of the cryostat as a JSON string.
    /// </summary>
    /// <returns>
    ///   [0] JSON: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetFeaturesJSON() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getFeaturesJSON";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of a time interval
    /// </summary>
    /// <param name="secondsOld"></param>
    /// <param name="secondsNew"></param>
    /// <returns>
    ///   [0] intervalJson: JSONd description of cryo status in time interval
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetIntervalLongTermEntriesJSONd(double secondsOld, double secondsNew) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getIntervalLongTermEntriesJSONd";

        object parametersecondsOld = secondsOld;
        object parametersecondsNew = secondsNew;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersecondsOld, parametersecondsNew);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat status of a time interval
    /// </summary>
    /// <param name="secondsOld"></param>
    /// <param name="secondsNew"></param>
    /// <returns>
    ///   [0] Short_term_log_entries: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetIntervalShortTermEntriesJSONd(double secondsOld, double secondsNew) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getIntervalShortTermEntriesJSONd";

        object parametersecondsOld = secondsOld;
        object parametersecondsNew = secondsNew;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametersecondsOld, parametersecondsNew);

        
        return ret;
    }

    /// <summary>
    /// Gets all available information on the last error
    /// </summary>
    /// <returns>
    ///   [0] lastErrorNumber: Last error number
    ///   [1] recommendation: Recommendation
    ///   [2] component: Component that raised the error
    ///   [3] command: Command
    ///   [4] age: Age
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<int, string, string, string, int> System_GetLastError() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastError";

        
        var ret = API_CallFiveReturnValues<int, string, string, string, int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the age of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] age: time in seconds since the last error happened
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetLastErrorAge() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorAge";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the command of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] command: command running when the last error happened
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorCommand() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorCommand";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the component of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] component: cryostat component of the error
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorComponent() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorComponent";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the error number of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] errorNumber: No error = 0
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_GetLastErrorNumber() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorNumber";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the recommendation of the last error that happened
    /// </summary>
    /// <returns>
    ///   [0] recommendation: error recommendation
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorRecommendation() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorRecommendation";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the last cryostat errors as a JSON string.
    /// </summary>
    /// <returns>
    ///   [0] JSON: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorsJSONd() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorsJSONd";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the last cryostat errors from the snapshot.    Use getLastErrorsAsJSON() and unJSON the data if this call doesn't work for you    (the cryostat data can't be unpickled)
    /// </summary>
    /// <param name="pythonVersion"></param>
    /// <returns>
    ///   [0] Pickled_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastErrorsPickled(int pythonVersion) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastErrorsPickled";

        object parameterpythonVersion = pythonVersion;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpythonVersion);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat long term status of the last seconds
    /// </summary>
    /// <param name="seconds"></param>
    /// <returns>
    ///   [0] version: firmware version number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastLongTermEntriesJSONd(double seconds) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastLongTermEntriesJSONd";

        object parameterseconds = seconds;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterseconds);

        
        return ret;
    }

    /// <summary>
    /// Get the cryostat status of the last seconds
    /// </summary>
    /// <param name="seconds"></param>
    /// <returns>
    ///   [0] version: firmware version number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLastShortTermEntriesJSONd(double seconds) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLastShortTermEntriesJSONd";

        object parameterseconds = seconds;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterseconds);

        
        return ret;
    }

    /// <summary>
    /// Get the last lines of the system logfile.
    /// </summary>
    /// <param name="maxBytes">maximum bytes to read</param>
    /// <returns>
    ///   [0] logLines: String containing the logfile lines
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetLogLines(int maxBytes) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getLogLines";

        object parametermaxBytes = maxBytes;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parametermaxBytes);

        
        return ret;
    }

    /// <summary>
    /// Gets the seconds from start of cryostat installation
    /// </summary>
    /// <returns>
    ///   [0] seconds: Seconds from start of cryostat installation
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double System_GetSecondsFromStartCryostatInstallation() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getSecondsFromStartCryostatInstallation";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the user JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()     and getConfigurationSettingInformation()
    /// </summary>
    /// <returns>
    ///   [0] overrideFile: String containing the override file
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_GetUserConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.getUserConfigOverrideFile";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Resets the last error
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_LowerError() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.lowerError";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Prepare the cryostat long term status of a time interval query
    /// </summary>
    /// <param name="minRow"></param>
    /// <param name="maxRow"></param>
    /// <param name="columnNames">Empty string means all available columns</param>
    /// <param name="handle"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_PrepareDatabaseColumnsIntervalAsync(int minRow, int maxRow, string columnNames, int handle) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.prepareDatabaseColumnsIntervalAsync";

        object parameterminRow = minRow;
        object parametermaxRow = maxRow;
        object parametercolumnNames = columnNames;
        object parameterhandle = handle;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterminRow, parametermaxRow, parametercolumnNames, parameterhandle);

        
        
    }

    /// <summary>
    /// Prepare the cryostat long term status of a time interval query    Get the row numbers with getDatabaseMinMaxResult()    Get the data with getDatabaseColumnsMinMaxIntervalRows()    minTime and maxTime can be taken from getDatabaseMinimumLogSeconds()  and getDatabaseMaximumLogSeconds()
    /// </summary>
    /// <param name="minTime"></param>
    /// <param name="maxTime"></param>
    /// <returns>
    ///   [0] handle: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int System_PrepareDatabaseMinMaxInterval(double minTime, double maxTime) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.prepareDatabaseMinMaxInterval";

        object parameterminTime = minTime;
        object parametermaxTime = maxTime;
        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand, parameterminTime, parametermaxTime);

        
        return ret;
    }

    /// <summary>
    /// Copy the EEPROM config factory defaults to the user config
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_ResetUserConfigOverrideFile() {
        object _parameterCommand = "com.attocube.cryostat.interface.system.resetUserConfigOverrideFile";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Sets the configuration setting
    /// </summary>
    /// <param name="settingName"></param>
    /// <param name="settingValue"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void System_SetConfigurationSetting(string settingName, double settingValue) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.setConfigurationSetting";

        object parametersettingName = settingName;
        object parametersettingValue = settingValue;
        
        API_CallNoReturnValues(false, _parameterCommand, parametersettingName, parametersettingValue);

        
        
    }

    /// <summary>
    /// Set the user JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()     and getConfigurationSettingInformation()
    /// </summary>
    /// <param name="fileContent">Contents of the config override file</param>
    /// <returns>
    ///   [0] hint_string: Free text string to give the caller some hints if things don't work
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string System_SetUserConfigOverrideFile(string fileContent) {
        object _parameterCommand = "com.attocube.cryostat.interface.system.setUserConfigOverrideFile";

        object parameterfileContent = fileContent;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterfileContent);

        
        return ret;
    }

    /// <summary>
    /// Gets last autotune error
    /// </summary>
    /// <returns>
    ///   [0] Autotune_errorcode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Tboard_AutotunePIDError() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDError";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Check whether PID autotune is currently running
    /// </summary>
    /// <returns>
    ///   [0] running: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Tboard_AutotunePIDRunning() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDRunning";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets last autotune stage
    /// </summary>
    /// <returns>
    ///   [0] Autotune_errorcode: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Tboard_AutotunePIDStage() {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.autotunePIDStage";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the sensor calibration curve
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Tboard_DownloadCalibrationCurve(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.downloadCalibrationCurve";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Gets the sensor .340 calibration curve
    /// </summary>
    /// <param name="channel"></param>
    /// <returns>
    ///   [0] calibration_data: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Tboard_DownloadCalibrationCurve340(int channel) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.downloadCalibrationCurve340";

        object parameterchannel = channel;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterchannel);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] p_output: 
    ///   [1] i_output: 
    ///   [2] d_output: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double> Tboard_GetHeaterPIDChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterPIDChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallThreeReturnValues<double, double, double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] set_point: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetHeaterSetpointChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterSetpointChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get heater zone settings channel
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] upperbound: Upper temperature bound of zone
    ///   [1] p_output: 
    ///   [2] i_output: 
    ///   [3] d_output: 
    ///   [4] manualOutput: 
    ///   [5] heatingRange: 0 -> off, 1 -> attocube OEM on, 1 -> 335, 336 Low, , 2 -> 335, 336 Medium, , 3 -> 335, 336 High
    ///   [6] rampRate: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<double, double, double, double, double, int, double> Tboard_GetHeaterZoneSettingsChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getHeaterZoneSettingsChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallSevenReturnValues<double, double, double, double, double, int, double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Get raw sensor input.
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] Raw_sensor_input: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetRawSensorInput(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getRawSensorInput";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Gets the resistance
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] resistance: :param channelNumber:
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetResistance(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getResistance";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Gets the temperature
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] temperature: :param channelNumber:
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Tboard_GetTemperature(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.getTemperature";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <returns>
    ///   [0] isHeating: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Tboard_IsHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.isHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand, parameterchannelNumber);

        
        return ret;
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterPIDChannel(int channelNumber, double p_input, double i_input, double d_input) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterPIDChannel";

        object parameterchannelNumber = channelNumber;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterp_input, parameteri_input, parameterd_input);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="setpoint">Temperature set point</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterSetpointChannel(int channelNumber, double setpoint) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterSetpointChannel";

        object parameterchannelNumber = channelNumber;
        object parametersetpoint = setpoint;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parametersetpoint);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="zone"></param>
    /// <param name="upperbound">Upper temperature bound of zone</param>
    /// <param name="p_input"></param>
    /// <param name="i_input"></param>
    /// <param name="d_input"></param>
    /// <param name="manualOutput"></param>
    /// <param name="heatingRange">0 -> off, 1 -> attocube OEM on, 1 -> 335, 336 Low, , 2 -> 335, 336 Medium, , 3 -> 335, 336 High</param>
    /// <param name="rampRate"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_SetHeaterZoneSettingsChannel(int channelNumber, int zone, double upperbound, double p_input, double i_input, double d_input, double manualOutput, int heatingRange, double rampRate) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.setHeaterZoneSettingsChannel";

        object parameterchannelNumber = channelNumber;
        object parameterzone = zone;
        object parameterupperbound = upperbound;
        object parameterp_input = p_input;
        object parameteri_input = i_input;
        object parameterd_input = d_input;
        object parametermanualOutput = manualOutput;
        object parameterheatingRange = heatingRange;
        object parameterrampRate = rampRate;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterzone, parameterupperbound, parameterp_input, parameteri_input, parameterd_input, parametermanualOutput, parameterheatingRange, parameterrampRate);

        
        
    }

    /// <summary>
    /// Start heating
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <param name="power"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingOpenLoopChannel(int channelNumber, double power) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingOpenLoopChannel";

        object parameterchannelNumber = channelNumber;
        object parameterpower = power;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber, parameterpower);

        
        
    }

    /// <summary>
    /// Start heating in zone mode
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StartHeatingZoneModeChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.startHeatingZoneModeChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Stop heating
    /// </summary>
    /// <param name="channelNumber"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_StopHeatingChannel(int channelNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.stopHeatingChannel";

        object parameterchannelNumber = channelNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannelNumber);

        
        
    }

    /// <summary>
    /// Sets the sensor calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="curveData">calibration data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_UploadCalibrationCurve(int channel, string curveData) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.uploadCalibrationCurve";

        object parameterchannel = channel;
        object parametercurveData = curveData;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametercurveData);

        
        
    }

    /// <summary>
    /// Sets the sensor .340 calibration curve    may time out, but the upload will still work
    /// </summary>
    /// <param name="channel"></param>
    /// <param name="curveData">calibration data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Tboard_UploadCalibrationCurve340(int channel, string curveData) {
        object _parameterCommand = "com.attocube.cryostat.interface.tboard.uploadCalibrationCurve340";

        object parameterchannel = channel;
        object parametercurveData = curveData;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterchannel, parametercurveData);

        
        
    }

    /// <summary>
    /// Gets the turbo pump frequency
    /// </summary>
    /// <returns>
    ///   [0] turbo_pump_frequency: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public double Turbopump_GetFrequency() {
        object _parameterCommand = "com.attocube.cryostat.interface.turboPump.getFrequency";

        
        var ret = API_CallOneReturnValue<double>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the turbo pump status
    /// </summary>
    /// <returns>
    ///   [0] turbo_pump_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Turbopump_GetStatus() {
        object _parameterCommand = "com.attocube.cryostat.interface.turboPump.getStatus";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Gets the turbo pump status as string
    /// </summary>
    /// <returns>
    ///   [0] turbo_pump_status_string: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Turbopump_GetStatusString() {
        object _parameterCommand = "com.attocube.cryostat.interface.turboPump.getStatusString";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Starts the turbo pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Turbopump_Start() {
        object _parameterCommand = "com.attocube.cryostat.interface.turboPump.start";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Stops the turbo pump
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Turbopump_Stop() {
        object _parameterCommand = "com.attocube.cryostat.interface.turboPump.stop";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Closes the valve
    /// </summary>
    /// <param name="valveNumber">0..12</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Valves_Close(int valveNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.valves.close";

        object parametervalveNumber = valveNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalveNumber);

        
        
    }

    /// <summary>
    /// Gets the valve status
    /// </summary>
    /// <param name="valveNumber">0..11</param>
    /// <returns>
    ///   [0] valve_status: 
    ///   [1] open_status_pin_status: 
    ///   [2] closed_status_pin_status: 
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool, bool> Valves_GetStatus(int valveNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.valves.getStatus";

        object parametervalveNumber = valveNumber;
        
        var ret = API_CallThreeReturnValues<bool, bool, bool>(false, _parameterCommand, parametervalveNumber);

        
        return ret;
    }

    /// <summary>
    /// Opens the valve
    /// </summary>
    /// <param name="valveNumber">0..12</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Valves_Open(int valveNumber) {
        object _parameterCommand = "com.attocube.cryostat.interface.valves.open";

        object parametervalveNumber = valveNumber;
        
        API_CallNoReturnValues(false, _parameterCommand, parametervalveNumber);

        
        
    }

    /// <summary>
    /// Grants access to a locked device for the requesting IP by checking against the password
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void GrantAccess(string password) {
        object _parameterCommand = "grantAccess";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function locks the device with a password, so the calling of functions is only possible with this password. The locking IP is automatically added to the devices which can access functions
    /// </summary>
    /// <param name="password">string the password to be set</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Lock(string password) {
        object _parameterCommand = "lock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function unlocks the device, so it will not be necessary to execute the grantAccess function to run any function
    /// </summary>
    /// <param name="password">string the current password</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Unlock(string password) {
        object _parameterCommand = "unlock";

        object parameterpassword = password;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpassword);

        
        
    }

    /// <summary>
    /// This function returns if the device is locked and if the current client is authorized to use the device.
    /// </summary>
    /// <returns>
    ///   [0] value_locked: locked Is the device locked?
    ///   [1] value_authorized: authorized Is the client authorized?
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public Tuple<bool, bool> GetLockStatus() {
        object _parameterCommand = "getLockStatus";

        
        var ret = API_CallTwoReturnValues<bool, bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get list of packages installed on the device
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Comma separated list of packages
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetInstalledPackages() {
        object _parameterCommand = "com.attocube.system.about.getInstalledPackages";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the license for a specific package
    /// </summary>
    /// <param name="pckg">string: Package name</param>
    /// <returns>
    ///   [0] value_string: string: License for this package
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string About_GetPackageLicense(string pckg) {
        object _parameterCommand = "com.attocube.system.about.getPackageLicense";

        object parameterpckg = pckg;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpckg);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetSwUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getSwUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the progress of running license update
    /// </summary>
    /// <returns>
    ///   [0] value_int: int: progress in percent
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Update_GetLicenseUpdateProgress() {
        object _parameterCommand = "com.attocube.system.update.getLicenseUpdateProgress";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Execute the update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_SoftwareUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.softwareUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Upload new firmware image in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadSoftwareImageBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadSoftwareImageBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Upload new license file in format base 64
    /// </summary>
    /// <param name="offset">int: offset of the data</param>
    /// <param name="b64Data">string: base64 data</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_UploadLicenseBase64(int offset, string b64Data) {
        object _parameterCommand = "com.attocube.system.update.uploadLicenseBase64";

        object parameteroffset = offset;
        object parameterb64Data = b64Data;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteroffset, parameterb64Data);

        
        
    }

    /// <summary>
    /// Execute the license update with base64 file uploaded.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Update_LicenseUpdateBase64() {
        object _parameterCommand = "com.attocube.system.update.licenseUpdateBase64";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// If AMC is on Rack position 0, use it as DHCP server, else use it as DHCP client
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Functions_CheckAMCinRack() {
        object _parameterCommand = "com.attocube.system.functions.checkAMCinRack";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get the real IP address of the device set to the network interface (br0, eth1 or eth0)
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetRealIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getRealIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the IP address of the device
    /// </summary>
    /// <returns>
    ///   [0] value_IP: IP address as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetIpAddress() {
        object _parameterCommand = "com.attocube.system.network.getIpAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the IP address of the device
    /// </summary>
    /// <param name="address">IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetIpAddress(string address) {
        object _parameterCommand = "com.attocube.system.network.setIpAddress";

        object parameteraddress = address;
        
        API_CallNoReturnValues(false, _parameterCommand, parameteraddress);

        
        
    }

    /// <summary>
    /// Get the subnet mask of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Subnet: Subnet mask as string
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetSubnetMask() {
        object _parameterCommand = "com.attocube.system.network.getSubnetMask";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the subnet mask of the device
    /// </summary>
    /// <param name="netmask">Subnet mask as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetSubnetMask(string netmask) {
        object _parameterCommand = "com.attocube.system.network.setSubnetMask";

        object parameternetmask = netmask;
        
        API_CallNoReturnValues(false, _parameterCommand, parameternetmask);

        
        
    }

    /// <summary>
    /// Get the default gateway of the device
    /// </summary>
    /// <returns>
    ///   [0] value_Default: Default gateway
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDefaultGateway() {
        object _parameterCommand = "com.attocube.system.network.getDefaultGateway";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the default gateway of the device
    /// </summary>
    /// <param name="gateway">Default gateway as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDefaultGateway(string gateway) {
        object _parameterCommand = "com.attocube.system.network.setDefaultGateway";

        object parametergateway = gateway;
        
        API_CallNoReturnValues(false, _parameterCommand, parametergateway);

        
        
    }

    /// <summary>
    /// Get the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <returns>
    ///   [0] value_IP: IP address of DNS resolver
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetDnsResolver(int priority) {
        object _parameterCommand = "com.attocube.system.network.getDnsResolver";

        object parameterpriority = priority;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterpriority);

        
        return ret;
    }

    /// <summary>
    /// Set the DNS resolver
    /// </summary>
    /// <param name="priority">of DNS resolver (Usually: 0 = Default, 1 = Backup)</param>
    /// <param name="resolver">The resolver's IP address as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetDnsResolver(int priority, string resolver) {
        object _parameterCommand = "com.attocube.system.network.setDnsResolver";

        object parameterpriority = priority;
        object parameterresolver = resolver;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpriority, parameterresolver);

        
        
    }

    /// <summary>
    /// Get the proxy settings of the devide
    /// </summary>
    /// <returns>
    ///   [0] value_Proxy: Proxy Server String, empty for no proxy
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetProxyServer() {
        object _parameterCommand = "com.attocube.system.network.getProxyServer";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Set the proxy server of the device
    /// </summary>
    /// <param name="proxyServer">Proxy Server Setting as string</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetProxyServer(string proxyServer) {
        object _parameterCommand = "com.attocube.system.network.setProxyServer";

        object parameterproxyServer = proxyServer;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterproxyServer);

        
        
    }

    /// <summary>
    /// Get the state of DHCP server
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP server enable, false = DHCP server disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpServer() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpServer";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP server
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP server, false = disable DHCP server</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpServer(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpServer";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Get the state of DHCP client
    /// </summary>
    /// <returns>
    ///   [0] value_boolean: boolean: true = DHCP client enable, false = DHCP client disable
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetEnableDhcpClient() {
        object _parameterCommand = "com.attocube.system.network.getEnableDhcpClient";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Enable or disable DHCP client
    /// </summary>
    /// <param name="enable">boolean: true = enable DHCP client, false = disable DHCP client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetEnableDhcpClient(bool enable) {
        object _parameterCommand = "com.attocube.system.network.setEnableDhcpClient";

        object parameterenable = enable;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterenable);

        
        
    }

    /// <summary>
    /// Apply temporary IP configuration and load it
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Apply() {
        object _parameterCommand = "com.attocube.system.network.apply";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Verify that temporary IP configuration is correct
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Verify() {
        object _parameterCommand = "com.attocube.system.network.verify";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Discard temporary IP configuration
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_Discard() {
        object _parameterCommand = "com.attocube.system.network.discard";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Returns is a Wifi interface is present
    /// </summary>
    /// <returns>
    ///   [0] value_True: True, if interface is present
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public bool Network_GetWifiPresent() {
        object _parameterCommand = "com.attocube.system.network.getWifiPresent";

        
        var ret = API_CallOneReturnValue<bool>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the operation mode of the wifi adapter
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiMode(int mode) {
        object _parameterCommand = "com.attocube.system.network.setWifiMode";

        object parametermode = mode;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode);

        
        
    }

    /// <summary>
    /// Get the operation mode of the wifi adapter
    /// </summary>
    /// <returns>
    ///   [0] value_mode: mode 0: Access point, 1: Wifi client
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public int Network_GetWifiMode() {
        object _parameterCommand = "com.attocube.system.network.getWifiMode";

        
        var ret = API_CallOneReturnValue<int>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="ssid"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiSSID(string ssid) {
        object _parameterCommand = "com.attocube.system.network.setWifiSSID";

        object parameterssid = ssid;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterssid);

        
        
    }

    /// <summary>
    /// Get the the SSID of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] SSID: SSID
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiSSID() {
        object _parameterCommand = "com.attocube.system.network.getWifiSSID";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_SetWifiPassphrase(string psk) {
        object _parameterCommand = "com.attocube.system.network.setWifiPassphrase";

        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterpsk);

        
        
    }

    /// <summary>
    /// Get the the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
    /// </summary>
    /// <returns>
    ///   [0] value_psk: psk Pre-shared key
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string Network_GetWifiPassphrase() {
        object _parameterCommand = "com.attocube.system.network.getWifiPassphrase";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Change the wifi configuration and applies it
    /// </summary>
    /// <param name="mode">0: Access point, 1: Wifi client</param>
    /// <param name="ssid"></param>
    /// <param name="psk">Pre-shared key</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Network_ConfigureWifi(int mode, string ssid, string psk) {
        object _parameterCommand = "com.attocube.system.network.configureWifi";

        object parametermode = mode;
        object parameterssid = ssid;
        object parameterpsk = psk;
        
        API_CallNoReturnValues(false, _parameterCommand, parametermode, parameterssid, parameterpsk);

        
        
    }

    /// <summary>
    /// Apply temporary system configuration
    /// </summary>
    /// <param name="key"></param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void Apply(int key) {
        object _parameterCommand = "com.attocube.system.apply";

        object parameterkey = key;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterkey);

        
        
    }

    /// <summary>
    /// Set custom name for the device
    /// </summary>
    /// <param name="name">string: device name</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetDeviceName(string name) {
        object _parameterCommand = "com.attocube.system.setDeviceName";

        object parametername = name;
        
        API_CallNoReturnValues(false, _parameterCommand, parametername);

        
        
    }

    /// <summary>
    /// Get the actual device name
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: actual device name
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetDeviceName() {
        object _parameterCommand = "com.attocube.system.getDeviceName";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Reboot the system
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void RebootSystem() {
        object _parameterCommand = "com.attocube.system.rebootSystem";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Turns on the factory reset flag.
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void FactoryReset() {
        object _parameterCommand = "com.attocube.system.factoryReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Performs a soft reset (Reset without deleting the network settings).
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SoftReset() {
        object _parameterCommand = "com.attocube.system.softReset";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Get a description of an error code
    /// </summary>
    /// <param name="language">integer: Language code 0 for the error name, 1 for a more user friendly error message</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error description
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToString(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToString";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get a recommendation for the error code
    /// </summary>
    /// <param name="language">integer: Language code</param>
    /// <param name="errNbr">interger: Error code to translate</param>
    /// <returns>
    ///   [0] value_string: string: Error recommendation (currently returning an int = 0 until we have recommendations)
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string ErrorNumberToRecommendation(int language, int errNbr) {
        object _parameterCommand = "com.attocube.system.errorNumberToRecommendation";

        object parameterlanguage = language;
        object parametererrNbr = errNbr;
        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand, parameterlanguage, parametererrNbr);

        
        return ret;
    }

    /// <summary>
    /// Get the firmware version of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: The firmware version
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFirmwareVersion() {
        object _parameterCommand = "com.attocube.system.getFirmwareVersion";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Return device hostname
    /// </summary>
    /// <returns>
    ///   [0] available: available
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetHostname() {
        object _parameterCommand = "com.attocube.system.getHostname";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the mac address of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Mac address of the system
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetMacAddress() {
        object _parameterCommand = "com.attocube.system.getMacAddress";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the serial number of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: Serial number
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetSerialNumber() {
        object _parameterCommand = "com.attocube.system.getSerialNumber";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Get the flux code of the system
    /// </summary>
    /// <returns>
    ///   [0] value_string: string: flux code
    /// </returns>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public string GetFluxCode() {
        object _parameterCommand = "com.attocube.system.getFluxCode";

        
        var ret = API_CallOneReturnValue<string>(false, _parameterCommand);

        
        return ret;
    }

    /// <summary>
    /// Update system time by querying attocube.com
    /// </summary>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void UpdateTimeFromInternet() {
        object _parameterCommand = "com.attocube.system.updateTimeFromInternet";

        
        API_CallNoReturnValues(false, _parameterCommand);

        
        
    }

    /// <summary>
    /// Set system time manually
    /// </summary>
    /// <param name="day">integer: Day (1-31)</param>
    /// <param name="month">integer: Day (1-12)</param>
    /// <param name="year">integer: Day (eg. 2021)</param>
    /// <param name="hour">integer: Day (0-23)</param>
    /// <param name="minute">integer: Day (0-59)</param>
    /// <param name="second">integer: Day (0-59)</param>
    /// <exception cref="AttocubeAPIException">Thrown if the call failed - e.g. response is null or invalid, some error was signalled by the embedded target</exception>
    public void SetTime(int day, int month, int year, int hour, int minute, int second) {
        object _parameterCommand = "com.attocube.system.setTime";

        object parameterday = day;
        object parametermonth = month;
        object parameteryear = year;
        object parameterhour = hour;
        object parameterminute = minute;
        object parametersecond = second;
        
        API_CallNoReturnValues(false, _parameterCommand, parameterday, parametermonth, parameteryear, parameterhour, parameterminute, parametersecond);

        
        
    }

}
}