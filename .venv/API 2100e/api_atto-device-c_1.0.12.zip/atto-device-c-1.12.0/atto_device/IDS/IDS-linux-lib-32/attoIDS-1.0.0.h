/**
 * Copyright (C) 2020 attocube systems AG
 * Usage is up to a separate agreement
**/

/**
 * @file generatedAPI.h
 * @brief API for use with attocube devices
**/

#ifndef __GENERATEDAPI_H_IDS_1_0_0__
#define __GENERATEDAPI_H_IDS_1_0_0__

#ifndef ATTO_PREFIX
#define ATTO_PREFIX IDS_1_0_0_
#endif

#define ATTO_PREFIX_CONCAT(x,y) x ## y
#define ATTO_PREFIX_EVALUATOR(x,y) ATTO_PREFIX_CONCAT(x,y)
#define ATTO_FUNCTION(function_name) ATTO_PREFIX_EVALUATOR(ATTO_PREFIX, function_name)

#include <stdbool.h>
#include "attocubeJSONCall.h"
#ifdef __cplusplus
extern "C" {
#endif

/** @brief @system_about_getInstalledPackages
*  Get list of packages installed on the device
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: Comma separated list of packages
*  @param size             Maximum size of buffer value_string
*
*  @return string: Comma separated list of packages
*/
int ATTOCUBE_API system_about_getInstalledPackages_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_about_getInstalledPackages)(int deviceHandle, char* value_string, int size) {
    return system_about_getInstalledPackages_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_about_getPackageLicense
*  Get the license for a specific package
*
*  @param deviceHandle     Handle of device
*  @param pckg             string: Package name
*
*  @param value_string     string: License for this package
*  @param size             Maximum size of buffer value_string
*
*  @return string: License for this package
*/
int ATTOCUBE_API system_about_getPackageLicense_IDS_1_0_0(int deviceHandle, const char* pckg, char* value_string, int size);

static inline int ATTO_FUNCTION(system_about_getPackageLicense)(int deviceHandle, const char* pckg, char* value_string, int size) {
    return system_about_getPackageLicense_IDS_1_0_0(deviceHandle, pckg, value_string, size);
}


/** @brief @system_update_getSwUpdateProgress
*  Get the progress of running update
*
*  @param deviceHandle     Handle of device
*
*  @param value_int        int: progress in percent
*
*  @return int: progress in percent
*/
int ATTOCUBE_API system_update_getSwUpdateProgress_IDS_1_0_0(int deviceHandle, int* value_int);

static inline int ATTO_FUNCTION(system_update_getSwUpdateProgress)(int deviceHandle, int* value_int) {
    return system_update_getSwUpdateProgress_IDS_1_0_0(deviceHandle, value_int);
}


/** @brief @system_update_getLicenseUpdateProgress
*  Get the progress of running license update
*
*  @param deviceHandle     Handle of device
*
*  @param value_int        int: progress in percent
*
*  @return int: progress in percent
*/
int ATTOCUBE_API system_update_getLicenseUpdateProgress_IDS_1_0_0(int deviceHandle, int* value_int);

static inline int ATTO_FUNCTION(system_update_getLicenseUpdateProgress)(int deviceHandle, int* value_int) {
    return system_update_getLicenseUpdateProgress_IDS_1_0_0(deviceHandle, value_int);
}


/** @brief @system_update_softwareUpdateBase64
*  Execute the update with base64 file uploaded.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_update_softwareUpdateBase64_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_update_softwareUpdateBase64)(int deviceHandle) {
    return system_update_softwareUpdateBase64_IDS_1_0_0(deviceHandle);
}


/** @brief @system_update_uploadSoftwareImageBase64
*  Upload new firmware image in format base 64
*
*  @param deviceHandle     Handle of device
*  @param offset           int: offset of the data
*  @param b64Data          string: base64 data
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_update_uploadSoftwareImageBase64_IDS_1_0_0(int deviceHandle, int offset, const char* b64Data);

static inline int ATTO_FUNCTION(system_update_uploadSoftwareImageBase64)(int deviceHandle, int offset, const char* b64Data) {
    return system_update_uploadSoftwareImageBase64_IDS_1_0_0(deviceHandle, offset, b64Data);
}


/** @brief @system_update_uploadLicenseBase64
*  Upload new license file in format base 64
*
*  @param deviceHandle     Handle of device
*  @param offset           int: offset of the data
*  @param b64Data          string: base64 data
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_update_uploadLicenseBase64_IDS_1_0_0(int deviceHandle, int offset, const char* b64Data);

static inline int ATTO_FUNCTION(system_update_uploadLicenseBase64)(int deviceHandle, int offset, const char* b64Data) {
    return system_update_uploadLicenseBase64_IDS_1_0_0(deviceHandle, offset, b64Data);
}


/** @brief @system_update_licenseUpdateBase64
*  Execute the license update with base64 file uploaded.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_update_licenseUpdateBase64_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_update_licenseUpdateBase64)(int deviceHandle) {
    return system_update_licenseUpdateBase64_IDS_1_0_0(deviceHandle);
}


/** @brief @system_functions_checkAMCinRack
*  If AMC is on Rack position 0, use it as DHCP server, else use it as DHCP client
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_functions_checkAMCinRack_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_functions_checkAMCinRack)(int deviceHandle) {
    return system_functions_checkAMCinRack_IDS_1_0_0(deviceHandle);
}


/** @brief @system_network_getRealIpAddress
*  Get the real IP address of the device set to the network interface (br0, eth1 or eth0)
*
*  @param deviceHandle     Handle of device
*
*  @param value_IP         IP address as string
*  @param size             Maximum size of buffer value_IP
*
*  @return IP address as string
*/
int ATTOCUBE_API system_network_getRealIpAddress_IDS_1_0_0(int deviceHandle, char* value_IP, int size);

static inline int ATTO_FUNCTION(system_network_getRealIpAddress)(int deviceHandle, char* value_IP, int size) {
    return system_network_getRealIpAddress_IDS_1_0_0(deviceHandle, value_IP, size);
}


/** @brief @system_network_getIpAddress
*  Get the IP address of the device
*
*  @param deviceHandle     Handle of device
*
*  @param value_IP         IP address as string
*  @param size             Maximum size of buffer value_IP
*
*  @return IP address as string
*/
int ATTOCUBE_API system_network_getIpAddress_IDS_1_0_0(int deviceHandle, char* value_IP, int size);

static inline int ATTO_FUNCTION(system_network_getIpAddress)(int deviceHandle, char* value_IP, int size) {
    return system_network_getIpAddress_IDS_1_0_0(deviceHandle, value_IP, size);
}


/** @brief @system_network_setIpAddress
*  Set the IP address of the device
*
*  @param deviceHandle     Handle of device
*  @param address          IP address as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setIpAddress_IDS_1_0_0(int deviceHandle, const char* address);

static inline int ATTO_FUNCTION(system_network_setIpAddress)(int deviceHandle, const char* address) {
    return system_network_setIpAddress_IDS_1_0_0(deviceHandle, address);
}


/** @brief @system_network_getSubnetMask
*  Get the subnet mask of the device
*
*  @param deviceHandle     Handle of device
*
*  @param value_Subnet     Subnet mask as string
*  @param size             Maximum size of buffer value_Subnet
*
*  @return Subnet mask as string
*/
int ATTOCUBE_API system_network_getSubnetMask_IDS_1_0_0(int deviceHandle, char* value_Subnet, int size);

static inline int ATTO_FUNCTION(system_network_getSubnetMask)(int deviceHandle, char* value_Subnet, int size) {
    return system_network_getSubnetMask_IDS_1_0_0(deviceHandle, value_Subnet, size);
}


/** @brief @system_network_setSubnetMask
*  Set the subnet mask of the device
*
*  @param deviceHandle     Handle of device
*  @param netmask          Subnet mask as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setSubnetMask_IDS_1_0_0(int deviceHandle, const char* netmask);

static inline int ATTO_FUNCTION(system_network_setSubnetMask)(int deviceHandle, const char* netmask) {
    return system_network_setSubnetMask_IDS_1_0_0(deviceHandle, netmask);
}


/** @brief @system_network_getDefaultGateway
*  Get the default gateway of the device
*
*  @param deviceHandle     Handle of device
*
*  @param value_Default    Default gateway
*  @param size             Maximum size of buffer value_Default
*
*  @return Default gateway
*/
int ATTOCUBE_API system_network_getDefaultGateway_IDS_1_0_0(int deviceHandle, char* value_Default, int size);

static inline int ATTO_FUNCTION(system_network_getDefaultGateway)(int deviceHandle, char* value_Default, int size) {
    return system_network_getDefaultGateway_IDS_1_0_0(deviceHandle, value_Default, size);
}


/** @brief @system_network_setDefaultGateway
*  Set the default gateway of the device
*
*  @param deviceHandle     Handle of device
*  @param gateway          Default gateway as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setDefaultGateway_IDS_1_0_0(int deviceHandle, const char* gateway);

static inline int ATTO_FUNCTION(system_network_setDefaultGateway)(int deviceHandle, const char* gateway) {
    return system_network_setDefaultGateway_IDS_1_0_0(deviceHandle, gateway);
}


/** @brief @system_network_getDnsResolver
*  Get the DNS resolver
*
*  @param deviceHandle     Handle of device
*  @param priority         of DNS resolver (Usually: 0 = Default, 1 = Backup)
*
*  @param value_IP         IP address of DNS resolver
*  @param size             Maximum size of buffer value_IP
*
*  @return IP address of DNS resolver
*/
int ATTOCUBE_API system_network_getDnsResolver_IDS_1_0_0(int deviceHandle, int priority, char* value_IP, int size);

static inline int ATTO_FUNCTION(system_network_getDnsResolver)(int deviceHandle, int priority, char* value_IP, int size) {
    return system_network_getDnsResolver_IDS_1_0_0(deviceHandle, priority, value_IP, size);
}


/** @brief @system_network_setDnsResolver
*  Set the DNS resolver
*
*  @param deviceHandle     Handle of device
*  @param priority         of DNS resolver (Usually: 0 = Default, 1 = Backup)
*  @param resolver         The resolver's IP address as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setDnsResolver_IDS_1_0_0(int deviceHandle, int priority, const char* resolver);

static inline int ATTO_FUNCTION(system_network_setDnsResolver)(int deviceHandle, int priority, const char* resolver) {
    return system_network_setDnsResolver_IDS_1_0_0(deviceHandle, priority, resolver);
}


/** @brief @system_network_getProxyServer
*  Get the proxy settings of the devide
*
*  @param deviceHandle     Handle of device
*
*  @param value_Proxy      Proxy Server String, empty for no proxy
*  @param size             Maximum size of buffer value_Proxy
*
*  @return Proxy Server String, empty for no proxy
*/
int ATTOCUBE_API system_network_getProxyServer_IDS_1_0_0(int deviceHandle, char* value_Proxy, int size);

static inline int ATTO_FUNCTION(system_network_getProxyServer)(int deviceHandle, char* value_Proxy, int size) {
    return system_network_getProxyServer_IDS_1_0_0(deviceHandle, value_Proxy, size);
}


/** @brief @system_network_setProxyServer
*  Set the proxy server of the device
*
*  @param deviceHandle     Handle of device
*  @param proxyServer      Proxy Server Setting as string
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setProxyServer_IDS_1_0_0(int deviceHandle, const char* proxyServer);

static inline int ATTO_FUNCTION(system_network_setProxyServer)(int deviceHandle, const char* proxyServer) {
    return system_network_setProxyServer_IDS_1_0_0(deviceHandle, proxyServer);
}


/** @brief @system_network_getEnableDhcpServer
*  Get the state of DHCP server
*
*  @param deviceHandle     Handle of device
*
*  @param value_boolean    boolean: true = DHCP server enable, false = DHCP server disable
*
*  @return boolean: true = DHCP server enable, false = DHCP server disable
*/
int ATTOCUBE_API system_network_getEnableDhcpServer_IDS_1_0_0(int deviceHandle, bool* value_boolean);

static inline int ATTO_FUNCTION(system_network_getEnableDhcpServer)(int deviceHandle, bool* value_boolean) {
    return system_network_getEnableDhcpServer_IDS_1_0_0(deviceHandle, value_boolean);
}


/** @brief @system_network_setEnableDhcpServer
*  Enable or disable DHCP server
*
*  @param deviceHandle     Handle of device
*  @param enable           boolean: true = enable DHCP server, false = disable DHCP server
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setEnableDhcpServer_IDS_1_0_0(int deviceHandle, bool enable);

static inline int ATTO_FUNCTION(system_network_setEnableDhcpServer)(int deviceHandle, bool enable) {
    return system_network_setEnableDhcpServer_IDS_1_0_0(deviceHandle, enable);
}


/** @brief @system_network_getEnableDhcpClient
*  Get the state of DHCP client
*
*  @param deviceHandle     Handle of device
*
*  @param value_boolean    boolean: true = DHCP client enable, false = DHCP client disable
*
*  @return boolean: true = DHCP client enable, false = DHCP client disable
*/
int ATTOCUBE_API system_network_getEnableDhcpClient_IDS_1_0_0(int deviceHandle, bool* value_boolean);

static inline int ATTO_FUNCTION(system_network_getEnableDhcpClient)(int deviceHandle, bool* value_boolean) {
    return system_network_getEnableDhcpClient_IDS_1_0_0(deviceHandle, value_boolean);
}


/** @brief @system_network_setEnableDhcpClient
*  Enable or disable DHCP client
*
*  @param deviceHandle     Handle of device
*  @param enable           boolean: true = enable DHCP client, false = disable DHCP client
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setEnableDhcpClient_IDS_1_0_0(int deviceHandle, bool enable);

static inline int ATTO_FUNCTION(system_network_setEnableDhcpClient)(int deviceHandle, bool enable) {
    return system_network_setEnableDhcpClient_IDS_1_0_0(deviceHandle, enable);
}


/** @brief @system_network_apply
*  Apply temporary IP configuration and load it
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_apply_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_network_apply)(int deviceHandle) {
    return system_network_apply_IDS_1_0_0(deviceHandle);
}


/** @brief @system_network_verify
*  Verify that temporary IP configuration is correct
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_verify_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_network_verify)(int deviceHandle) {
    return system_network_verify_IDS_1_0_0(deviceHandle);
}


/** @brief @system_network_discard
*  Discard temporary IP configuration
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_discard_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_network_discard)(int deviceHandle) {
    return system_network_discard_IDS_1_0_0(deviceHandle);
}


/** @brief @system_network_getWifiPresent
*  Returns is a Wifi interface is present
*
*  @param deviceHandle     Handle of device
*
*  @param value_True       True, if interface is present
*
*  @return True, if interface is present
*/
int ATTOCUBE_API system_network_getWifiPresent_IDS_1_0_0(int deviceHandle, bool* value_True);

static inline int ATTO_FUNCTION(system_network_getWifiPresent)(int deviceHandle, bool* value_True) {
    return system_network_getWifiPresent_IDS_1_0_0(deviceHandle, value_True);
}


/** @brief @system_network_setWifiMode
*  Change the operation mode of the wifi adapter
*
*  @param deviceHandle     Handle of device
*  @param mode             0: Access point, 1: Wifi client
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setWifiMode_IDS_1_0_0(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(system_network_setWifiMode)(int deviceHandle, int mode) {
    return system_network_setWifiMode_IDS_1_0_0(deviceHandle, mode);
}


/** @brief @system_network_getWifiMode
*  Get the operation mode of the wifi adapter
*
*  @param deviceHandle     Handle of device
*
*  @param value_mode       mode 0: Access point, 1: Wifi client
*
*  @return mode 0: Access point, 1: Wifi client
*/
int ATTOCUBE_API system_network_getWifiMode_IDS_1_0_0(int deviceHandle, int* value_mode);

static inline int ATTO_FUNCTION(system_network_getWifiMode)(int deviceHandle, int* value_mode) {
    return system_network_getWifiMode_IDS_1_0_0(deviceHandle, value_mode);
}


/** @brief @system_network_setWifiSSID
*  Change the SSID of the network hosted (mode: Access point) or connected to (mode: client)
*
*  @param deviceHandle     Handle of device
*  @param ssid             
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setWifiSSID_IDS_1_0_0(int deviceHandle, const char* ssid);

static inline int ATTO_FUNCTION(system_network_setWifiSSID)(int deviceHandle, const char* ssid) {
    return system_network_setWifiSSID_IDS_1_0_0(deviceHandle, ssid);
}


/** @brief @system_network_getWifiSSID
*  Get the the SSID of the network hosted (mode: Access point) or connected to (mode: client)
*
*  @param deviceHandle     Handle of device
*
*  @param SSID             SSID
*  @param size             Maximum size of buffer SSID
*
*  @return SSID
*/
int ATTOCUBE_API system_network_getWifiSSID_IDS_1_0_0(int deviceHandle, char* SSID, int size);

static inline int ATTO_FUNCTION(system_network_getWifiSSID)(int deviceHandle, char* SSID, int size) {
    return system_network_getWifiSSID_IDS_1_0_0(deviceHandle, SSID, size);
}


/** @brief @system_network_setWifiPassphrase
*  Change the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
*
*  @param deviceHandle     Handle of device
*  @param psk              Pre-shared key
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_setWifiPassphrase_IDS_1_0_0(int deviceHandle, const char* psk);

static inline int ATTO_FUNCTION(system_network_setWifiPassphrase)(int deviceHandle, const char* psk) {
    return system_network_setWifiPassphrase_IDS_1_0_0(deviceHandle, psk);
}


/** @brief @system_network_getWifiPassphrase
*  Get the the passphrase of the network hosted (mode: Access point) or connected to (mode: client)
*
*  @param deviceHandle     Handle of device
*
*  @param value_psk        psk Pre-shared key
*  @param size             Maximum size of buffer value_psk
*
*  @return psk Pre-shared key
*/
int ATTOCUBE_API system_network_getWifiPassphrase_IDS_1_0_0(int deviceHandle, char* value_psk, int size);

static inline int ATTO_FUNCTION(system_network_getWifiPassphrase)(int deviceHandle, char* value_psk, int size) {
    return system_network_getWifiPassphrase_IDS_1_0_0(deviceHandle, value_psk, size);
}


/** @brief @system_network_configureWifi
*  Change the wifi configuration and applies it
*
*  @param deviceHandle     Handle of device
*  @param mode             0: Access point, 1: Wifi client
*  @param ssid             
*  @param psk              Pre-shared key
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_network_configureWifi_IDS_1_0_0(int deviceHandle, int mode, const char* ssid, const char* psk);

static inline int ATTO_FUNCTION(system_network_configureWifi)(int deviceHandle, int mode, const char* ssid, const char* psk) {
    return system_network_configureWifi_IDS_1_0_0(deviceHandle, mode, ssid, psk);
}


/** @brief @system_apply
*  Apply temporary system configuration
*
*  @param deviceHandle     Handle of device
*  @param key              
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_apply_IDS_1_0_0(int deviceHandle, int key);

static inline int ATTO_FUNCTION(system_apply)(int deviceHandle, int key) {
    return system_apply_IDS_1_0_0(deviceHandle, key);
}


/** @brief @system_setDeviceName
*  Set custom name for the device
*
*  @param deviceHandle     Handle of device
*  @param name             string: device name
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_setDeviceName_IDS_1_0_0(int deviceHandle, const char* name);

static inline int ATTO_FUNCTION(system_setDeviceName)(int deviceHandle, const char* name) {
    return system_setDeviceName_IDS_1_0_0(deviceHandle, name);
}


/** @brief @system_getDeviceName
*  Get the actual device name
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: actual device name
*  @param size             Maximum size of buffer value_string
*
*  @return string: actual device name
*/
int ATTOCUBE_API system_getDeviceName_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_getDeviceName)(int deviceHandle, char* value_string, int size) {
    return system_getDeviceName_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_rebootSystem
*  Reboot the system
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_rebootSystem_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_rebootSystem)(int deviceHandle) {
    return system_rebootSystem_IDS_1_0_0(deviceHandle);
}


/** @brief @system_factoryReset
*  Turns on the factory reset flag.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_factoryReset_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_factoryReset)(int deviceHandle) {
    return system_factoryReset_IDS_1_0_0(deviceHandle);
}


/** @brief @system_softReset
*  Performs a soft reset (Reset without deleting the network settings).
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_softReset_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_softReset)(int deviceHandle) {
    return system_softReset_IDS_1_0_0(deviceHandle);
}


/** @brief @system_errorNumberToString
*  Get a description of an error code
*
*  @param deviceHandle     Handle of device
*  @param language         integer: Language code 0 for the error name, 1 for a more user friendly error message
*  @param errNbr           interger: Error code to translate
*
*  @param value_string     string: Error description
*  @param size             Maximum size of buffer value_string
*
*  @return string: Error description
*/
int ATTOCUBE_API system_errorNumberToString_IDS_1_0_0(int deviceHandle, int language, int errNbr, char* value_string, int size);

static inline int ATTO_FUNCTION(system_errorNumberToString)(int deviceHandle, int language, int errNbr, char* value_string, int size) {
    return system_errorNumberToString_IDS_1_0_0(deviceHandle, language, errNbr, value_string, size);
}


/** @brief @system_errorNumberToRecommendation
*  Get a recommendation for the error code
*
*  @param deviceHandle     Handle of device
*  @param language         integer: Language code
*  @param errNbr           interger: Error code to translate
*
*  @param value_string     string: Error recommendation (currently returning an int = 0 until we have recommendations)
*  @param size             Maximum size of buffer value_string
*
*  @return string: Error recommendation (currently returning an int = 0 until we have recommendations)
*/
int ATTOCUBE_API system_errorNumberToRecommendation_IDS_1_0_0(int deviceHandle, int language, int errNbr, char* value_string, int size);

static inline int ATTO_FUNCTION(system_errorNumberToRecommendation)(int deviceHandle, int language, int errNbr, char* value_string, int size) {
    return system_errorNumberToRecommendation_IDS_1_0_0(deviceHandle, language, errNbr, value_string, size);
}


/** @brief @system_getFirmwareVersion
*  Get the firmware version of the system
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: The firmware version
*  @param size             Maximum size of buffer value_string
*
*  @return string: The firmware version
*/
int ATTOCUBE_API system_getFirmwareVersion_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_getFirmwareVersion)(int deviceHandle, char* value_string, int size) {
    return system_getFirmwareVersion_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_getHostname
*  Return device hostname
*
*  @param deviceHandle     Handle of device
*
*  @param available        available
*  @param size             Maximum size of buffer available
*
*  @return available
*/
int ATTOCUBE_API system_getHostname_IDS_1_0_0(int deviceHandle, char* available, int size);

static inline int ATTO_FUNCTION(system_getHostname)(int deviceHandle, char* available, int size) {
    return system_getHostname_IDS_1_0_0(deviceHandle, available, size);
}


/** @brief @system_getMacAddress
*  Get the mac address of the system
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: Mac address of the system
*  @param size             Maximum size of buffer value_string
*
*  @return string: Mac address of the system
*/
int ATTOCUBE_API system_getMacAddress_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_getMacAddress)(int deviceHandle, char* value_string, int size) {
    return system_getMacAddress_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_getSerialNumber
*  Get the serial number of the system
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: Serial number
*  @param size             Maximum size of buffer value_string
*
*  @return string: Serial number
*/
int ATTOCUBE_API system_getSerialNumber_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_getSerialNumber)(int deviceHandle, char* value_string, int size) {
    return system_getSerialNumber_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_getFluxCode
*  Get the flux code of the system
*
*  @param deviceHandle     Handle of device
*
*  @param value_string     string: flux code
*  @param size             Maximum size of buffer value_string
*
*  @return string: flux code
*/
int ATTOCUBE_API system_getFluxCode_IDS_1_0_0(int deviceHandle, char* value_string, int size);

static inline int ATTO_FUNCTION(system_getFluxCode)(int deviceHandle, char* value_string, int size) {
    return system_getFluxCode_IDS_1_0_0(deviceHandle, value_string, size);
}


/** @brief @system_updateTimeFromInternet
*  Update system time by querying attocube.com
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_updateTimeFromInternet_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(system_updateTimeFromInternet)(int deviceHandle) {
    return system_updateTimeFromInternet_IDS_1_0_0(deviceHandle);
}


/** @brief @system_setTime
*  Set system time manually
*
*  @param deviceHandle     Handle of device
*  @param day              integer: Day (1-31)
*  @param month            integer: Day (1-12)
*  @param year             integer: Day (eg. 2021)
*  @param hour             integer: Day (0-23)
*  @param minute           integer: Day (0-59)
*  @param second           integer: Day (0-59)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API system_setTime_IDS_1_0_0(int deviceHandle, int day, int month, int year, int hour, int minute, int second);

static inline int ATTO_FUNCTION(system_setTime)(int deviceHandle, int day, int month, int year, int hour, int minute, int second) {
    return system_setTime_IDS_1_0_0(deviceHandle, day, month, year, hour, minute, second);
}


/** @brief @IDS_grantAccess
*  Grants access to a locked device for the requesting IP by checking against the password
*
*  @param deviceHandle     Handle of device
*  @param password         string the current password
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_grantAccess_IDS_1_0_0(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(IDS_grantAccess)(int deviceHandle, const char* password) {
    return IDS_grantAccess_IDS_1_0_0(deviceHandle, password);
}


/** @brief @IDS_lock
*  This function locks the device with a password, so the calling of functions is only possible with this password. The locking IP is automatically added to the devices which can access functions
*
*  @param deviceHandle     Handle of device
*  @param password         string the password to be set
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_lock_IDS_1_0_0(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(IDS_lock)(int deviceHandle, const char* password) {
    return IDS_lock_IDS_1_0_0(deviceHandle, password);
}


/** @brief @IDS_unlock
*  This function unlocks the device, so it will not be necessary to execute the grantAccess function to run any function
*
*  @param deviceHandle     Handle of device
*  @param password         string the current password
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_unlock_IDS_1_0_0(int deviceHandle, const char* password);

static inline int ATTO_FUNCTION(IDS_unlock)(int deviceHandle, const char* password) {
    return IDS_unlock_IDS_1_0_0(deviceHandle, password);
}


/** @brief @IDS_getLockStatus
*  This function returns if the device is locked and if the current client is authorized to use the device.
*
*  @param deviceHandle     Handle of device
*
*  @param value_locked     locked Is the device locked?
*  @param value_authorized authorized Is the client authorized?
*
*  @return locked Is the device locked?
*/
int ATTOCUBE_API IDS_getLockStatus_IDS_1_0_0(int deviceHandle, bool* value_locked, bool* value_authorized);

static inline int ATTO_FUNCTION(IDS_getLockStatus)(int deviceHandle, bool* value_locked, bool* value_authorized) {
    return IDS_getLockStatus_IDS_1_0_0(deviceHandle, value_locked, value_authorized);
}


/** @brief @IDS_adjustment_getContrastInPermille
*  This function can be used to monitor the alignment contrast (peak-to-peak of the /nbasic interference signal amplitude) and the basline (its offset) during alignment /nmode.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the value from [0..2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_contast    contast Contrast of the base band signal in permille
*  @param value_baseline   baseline Offset of the contrast measurement in permille
*  @param value_mixcontrast mixcontrast lower contrast measurment when measuring a mix contrast (indicated by error code)
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_adjustment_getContrastInPermille_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, int* value_contast, int* value_baseline, int* value_mixcontrast);

static inline int ATTO_FUNCTION(IDS_adjustment_getContrastInPermille)(int deviceHandle, int axis, int* value_warningNo, int* value_contast, int* value_baseline, int* value_mixcontrast) {
    return IDS_adjustment_getContrastInPermille_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_contast, value_baseline, value_mixcontrast);
}


/** @brief @IDS_adjustment_getAdjustmentEnabled
*  This function can be used to see if the adjustment is running
*
*  @param deviceHandle     Handle of device
*
*  @param value_enable     enable true = enabled; false = disabled
*
*  @return enable true = enabled; false = disabled
*/
int ATTOCUBE_API IDS_adjustment_getAdjustmentEnabled_IDS_1_0_0(int deviceHandle, bool* value_enable);

static inline int ATTO_FUNCTION(IDS_adjustment_getAdjustmentEnabled)(int deviceHandle, bool* value_enable) {
    return IDS_adjustment_getAdjustmentEnabled_IDS_1_0_0(deviceHandle, value_enable);
}


/** @brief @IDS_axis_getPassMode
*  Reads out the current pass mode.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_mode       mode 0 = single; pass 1 = dual pass
*
*  @return mode 0 = single; pass 1 = dual pass
*/
int ATTOCUBE_API IDS_axis_getPassMode_IDS_1_0_0(int deviceHandle, int tempVal, int* value_mode);

static inline int ATTO_FUNCTION(IDS_axis_getPassMode)(int deviceHandle, int tempVal, int* value_mode) {
    return IDS_axis_getPassMode_IDS_1_0_0(deviceHandle, tempVal, value_mode);
}


/** @brief @IDS_axis_setPassMode
*  Sets the desired pass mode.
*
*  @param deviceHandle     Handle of device
*  @param mode             0 = single pass; 1 = dual pass
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_axis_setPassMode_IDS_1_0_0(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(IDS_axis_setPassMode)(int deviceHandle, int mode) {
    return IDS_axis_setPassMode_IDS_1_0_0(deviceHandle, mode);
}


/** @brief @IDS_axis_getMasterAxis
*  Returns the master axis (for more information please refer to the IDS User Manual).
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_masteraxis masteraxis Axis which is operating as masteraxis [0..2]
*
*  @return masteraxis Axis which is operating as masteraxis [0..2]
*/
int ATTOCUBE_API IDS_axis_getMasterAxis_IDS_1_0_0(int deviceHandle, int tempVal, int* value_masteraxis);

static inline int ATTO_FUNCTION(IDS_axis_getMasterAxis)(int deviceHandle, int tempVal, int* value_masteraxis) {
    return IDS_axis_getMasterAxis_IDS_1_0_0(deviceHandle, tempVal, value_masteraxis);
}


/** @brief @IDS_axis_setMasterAxis
*  Sets the master axis (for more information please refer to the IDS User Manual).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis which is operating as masteraxis [0..2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_axis_setMasterAxis_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_axis_setMasterAxis)(int deviceHandle, int axis) {
    return IDS_axis_setMasterAxis_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_axis_apply
*  Applies new axis settings.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_axis_apply_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_axis_apply)(int deviceHandle) {
    return IDS_axis_apply_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_axis_discard
*  Discards new axis settings.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_axis_discard_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_axis_discard)(int deviceHandle) {
    return IDS_axis_discard_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_displacement_getMeasurementEnabled
*  This function can be used to see if the measurement is running
*
*  @param deviceHandle     Handle of device
*
*  @param value_enable     enable true = enabled; false = disabled
*
*  @return enable true = enabled; false = disabled
*/
int ATTOCUBE_API IDS_displacement_getMeasurementEnabled_IDS_1_0_0(int deviceHandle, bool* value_enable);

static inline int ATTO_FUNCTION(IDS_displacement_getMeasurementEnabled)(int deviceHandle, bool* value_enable) {
    return IDS_displacement_getMeasurementEnabled_IDS_1_0_0(deviceHandle, value_enable);
}


/** @brief @IDS_displacement_getAverageN
*  Reads-out the averaging (lowpass) parameter N.
*
*  @param deviceHandle     Handle of device
*
*  @param value_averageN   averageN A value from 0 to 24
*
*  @return averageN A value from 0 to 24
*/
int ATTOCUBE_API IDS_displacement_getAverageN_IDS_1_0_0(int deviceHandle, int* value_averageN);

static inline int ATTO_FUNCTION(IDS_displacement_getAverageN)(int deviceHandle, int* value_averageN) {
    return IDS_displacement_getAverageN_IDS_1_0_0(deviceHandle, value_averageN);
}


/** @brief @IDS_displacement_setAverageN
*  Sets the averaging (lowpass) parameter N.
*
*  @param deviceHandle     Handle of device
*  @param value            AverageN value from 0 to 24
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_displacement_setAverageN_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_displacement_setAverageN)(int deviceHandle, int value) {
    return IDS_displacement_setAverageN_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_displacement_linProc
*  Important note: This function is not actively supported anymore.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*  @param fringesnbr       Number of fringes to be acquired
*  @param samplesperfringe Number of samples per fringe
*  @param set              0 = evaluate current nonlinear amplitude /n1 = perform linearization and upload look up table /n2 = Clear look up table /n3 = Perform only calculation of Phi file
*
*  @param value_lintable   lintable String, which contains all 512 phase related correction values
*  @param value_nonlinearamp nonlinearamp String which contains the residual positive and negative maximal nonlinear amplitude
*
*  @return lintable String, which contains all 512 phase related correction values
*/
int ATTOCUBE_API IDS_displacement_linProc_IDS_1_0_0(int deviceHandle, int axis, int fringesnbr, int samplesperfringe, int set, int* value_lintable, int* value_nonlinearamp);

static inline int ATTO_FUNCTION(IDS_displacement_linProc)(int deviceHandle, int axis, int fringesnbr, int samplesperfringe, int set, int* value_lintable, int* value_nonlinearamp) {
    return IDS_displacement_linProc_IDS_1_0_0(deviceHandle, axis, fringesnbr, samplesperfringe, set, value_lintable, value_nonlinearamp);
}


/** @brief @IDS_displacement_getSignalQuality
*  This function can be used to monitor the alignment contrast (peak-to-peak of the basic /ninterference signal amplitude) and the basline (its offset) during a running /nmeasurement.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_contrast   contrast Contrast of the base band signal in ‰
*  @param value_baseline   baseline Offset of the contrast measurement in ‰
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getSignalQuality_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, int* value_contrast, int* value_baseline);

static inline int ATTO_FUNCTION(IDS_displacement_getSignalQuality)(int deviceHandle, int axis, int* value_warningNo, int* value_contrast, int* value_baseline) {
    return IDS_displacement_getSignalQuality_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_contrast, value_baseline);
}


/** @brief @IDS_displacement_getAxisSignalQuality
*  This function can be used to monitor the alignment contrast (peak-to-peak of the basic /ninterference signal amplitude) and the basline (its offset) during a running /nmeasurement.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_contrast   contrast Contrast of the base band signal in ‰
*  @param value_baseline   baseline Offset of the contrast measurement in ‰
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getAxisSignalQuality_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, int* value_contrast, int* value_baseline);

static inline int ATTO_FUNCTION(IDS_displacement_getAxisSignalQuality)(int deviceHandle, int axis, int* value_warningNo, int* value_contrast, int* value_baseline) {
    return IDS_displacement_getAxisSignalQuality_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_contrast, value_baseline);
}


/** @brief @IDS_displacement_getReferencePosition
*  The reference position information is estimated at the measurement initialization procedure or on reset.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_position   position reference position of the axis in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getReferencePosition_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, double* value_position);

static inline int ATTO_FUNCTION(IDS_displacement_getReferencePosition)(int deviceHandle, int axis, int* value_warningNo, double* value_position) {
    return IDS_displacement_getReferencePosition_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_position);
}


/** @brief @IDS_displacement_getReferencePositions
*  The reference position information is estimated at the measurement initialization procedure or on reset.
*
*  @param deviceHandle     Handle of device
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_position1  position0 position of the axis 0 in pm
*  @param value_position2  position1 position of the axis 1 in pm
*  @param value_position3  position2 position of the axis 2 in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getReferencePositions_IDS_1_0_0(int deviceHandle, int* value_warningNo, double* value_position1, double* value_position2, double* value_position3);

static inline int ATTO_FUNCTION(IDS_displacement_getReferencePositions)(int deviceHandle, int* value_warningNo, double* value_position1, double* value_position2, double* value_position3) {
    return IDS_displacement_getReferencePositions_IDS_1_0_0(deviceHandle, value_warningNo, value_position1, value_position2, value_position3);
}


/** @brief @IDS_displacement_getAbsolutePosition
*  The absolute position information is estimated at the measurement initialization procedure.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_position   position position of the axis in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getAbsolutePosition_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, double* value_position);

static inline int ATTO_FUNCTION(IDS_displacement_getAbsolutePosition)(int deviceHandle, int axis, int* value_warningNo, double* value_position) {
    return IDS_displacement_getAbsolutePosition_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_position);
}


/** @brief @IDS_displacement_getAbsolutePositions
*  The absolute position information is estimated at the measurement initialization /nprocedure.
*
*  @param deviceHandle     Handle of device
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_position1  position0 position of the axis 0 in pm
*  @param value_position2  position1 position of the axis 1 in pm
*  @param value_position3  position2 position of the axis 2 in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getAbsolutePositions_IDS_1_0_0(int deviceHandle, int* value_warningNo, double* value_position1, double* value_position2, double* value_position3);

static inline int ATTO_FUNCTION(IDS_displacement_getAbsolutePositions)(int deviceHandle, int* value_warningNo, double* value_position1, double* value_position2, double* value_position3) {
    return IDS_displacement_getAbsolutePositions_IDS_1_0_0(deviceHandle, value_warningNo, value_position1, value_position2, value_position3);
}


/** @brief @IDS_displacement_getAxisDisplacement
*  Reads out the displacement value of a specific measurement axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_displacement displacement Displacement of the axis in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getAxisDisplacement_IDS_1_0_0(int deviceHandle, int axis, int* value_warningNo, double* value_displacement);

static inline int ATTO_FUNCTION(IDS_displacement_getAxisDisplacement)(int deviceHandle, int axis, int* value_warningNo, double* value_displacement) {
    return IDS_displacement_getAxisDisplacement_IDS_1_0_0(deviceHandle, axis, value_warningNo, value_displacement);
}


/** @brief @IDS_displacement_getAxesDisplacement
*  Reads out the displacement values of all three measurement axes.
*
*  @param deviceHandle     Handle of device
*
*  @param value_warningNo  warningNo Warning code, can be converted into a string using the errorNumberToString function
*  @param value_displacement1 displacement0 displacement of the axis 0 in pm
*  @param value_displacement2 displacement1 displacement of the axis 1 in pm
*  @param value_displacement3 displacement2 displacement of the axis 2 in pm
*
*  @return warningNo Warning code, can be converted into a string using the errorNumberToString function
*/
int ATTOCUBE_API IDS_displacement_getAxesDisplacement_IDS_1_0_0(int deviceHandle, int* value_warningNo, double* value_displacement1, double* value_displacement2, double* value_displacement3);

static inline int ATTO_FUNCTION(IDS_displacement_getAxesDisplacement)(int deviceHandle, int* value_warningNo, double* value_displacement1, double* value_displacement2, double* value_displacement3) {
    return IDS_displacement_getAxesDisplacement_IDS_1_0_0(deviceHandle, value_warningNo, value_displacement1, value_displacement2, value_displacement3);
}


/** @brief @IDS_pilotlaser_enable
*  Enables the pilot laser.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_pilotlaser_enable_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_pilotlaser_enable)(int deviceHandle) {
    return IDS_pilotlaser_enable_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_pilotlaser_disable
*  Disables the pilot laser.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_pilotlaser_disable_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_pilotlaser_disable)(int deviceHandle) {
    return IDS_pilotlaser_disable_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_pilotlaser_getEnabled
*  Reads out whether the pilot laser is enabled or not.
*
*  @param deviceHandle     Handle of device
*
*  @param value_enable     enable true = enabled; false = disabled
*
*  @return enable true = enabled; false = disabled
*/
int ATTOCUBE_API IDS_pilotlaser_getEnabled_IDS_1_0_0(int deviceHandle, bool* value_enable);

static inline int ATTO_FUNCTION(IDS_pilotlaser_getEnabled)(int deviceHandle, bool* value_enable) {
    return IDS_pilotlaser_getEnabled_IDS_1_0_0(deviceHandle, value_enable);
}


/** @brief @IDS_realtime_getRtOutMode
*  Reads out the current realtime output mode.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_rtOutMode  rtOutMode 0 = HSSL (TTL), 1 = HSSL (LVDS), 2 = AquadB (TTL), /n3 = AquadB (LVDS), 4 = SinCos (TTL Error Signal), /n5 = SinCos (LVDS Error Signal), 6 = Linear (TTL), 7 = Linear (LVDS), /n8 = BiSS-C, 9 = Deactivated
*
*  @return rtOutMode 0 = HSSL (TTL), 1 = HSSL (LVDS), 2 = AquadB (TTL), /n3 = AquadB (LVDS), 4 = SinCos (TTL Error Signal), /n5 = SinCos (LVDS Error Signal), 6 = Linear (TTL), 7 = Linear (LVDS), /n8 = BiSS-C, 9 = Deactivated
*/
int ATTOCUBE_API IDS_realtime_getRtOutMode_IDS_1_0_0(int deviceHandle, int tempVal, int* value_rtOutMode);

static inline int ATTO_FUNCTION(IDS_realtime_getRtOutMode)(int deviceHandle, int tempVal, int* value_rtOutMode) {
    return IDS_realtime_getRtOutMode_IDS_1_0_0(deviceHandle, tempVal, value_rtOutMode);
}


/** @brief @IDS_realtime_setRtOutMode
*  Sets the real time output mode.
*
*  @param deviceHandle     Handle of device
*  @param value            rtOutMode 0 = HSSL (TTL), 1 = HSSL (LVDS), 2 = AquadB (TTL), /n3 = AquadB (LVDS), 4 = SinCos (TTL Error Signal), /n5 = SinCos (LVDS Error Signal), 6 = Linear (TTL), 7 = Linear (LVDS), /n8 = BiSS-C, 9 = Deactivated
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setRtOutMode_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setRtOutMode)(int deviceHandle, int value) {
    return IDS_realtime_setRtOutMode_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getRtDistanceMode
*  Reads out the distance mode.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_linearmode linearmode 1 = Displacement (Available in HSSL mode and Linear Mode) /n2 = Absolute Distance (Available in HSSL mode only) /n3 = Vibrometry (Available in Linear mode)
*
*  @return linearmode 1 = Displacement (Available in HSSL mode and Linear Mode) /n2 = Absolute Distance (Available in HSSL mode only) /n3 = Vibrometry (Available in Linear mode)
*/
int ATTOCUBE_API IDS_realtime_getRtDistanceMode_IDS_1_0_0(int deviceHandle, int tempVal, int* value_linearmode);

static inline int ATTO_FUNCTION(IDS_realtime_getRtDistanceMode)(int deviceHandle, int tempVal, int* value_linearmode) {
    return IDS_realtime_getRtDistanceMode_IDS_1_0_0(deviceHandle, tempVal, value_linearmode);
}


/** @brief @IDS_realtime_setRtDistanceMode
*  Sets the distance mode.
*
*  @param deviceHandle     Handle of device
*  @param value            1 = Displacement (HSSL mode and Linear Mode) /n2 = Absolute Distance (HSSL mode only) /n3 = Vibrometry (Linear mode)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setRtDistanceMode_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setRtDistanceMode)(int deviceHandle, int value) {
    return IDS_realtime_setRtDistanceMode_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getResolutionBissC
*  Reads out the BissC resolution.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_resolution resolution 1pm to 65535pm
*
*  @return resolution 1pm to 65535pm
*/
int ATTOCUBE_API IDS_realtime_getResolutionBissC_IDS_1_0_0(int deviceHandle, int tempVal, int* value_resolution);

static inline int ATTO_FUNCTION(IDS_realtime_getResolutionBissC)(int deviceHandle, int tempVal, int* value_resolution) {
    return IDS_realtime_getResolutionBissC_IDS_1_0_0(deviceHandle, tempVal, value_resolution);
}


/** @brief @IDS_realtime_setResolutionBissC
*  Sets the BissC resolution.
*
*  @param deviceHandle     Handle of device
*  @param value            resolution 1pm to 65535pm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setResolutionBissC_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setResolutionBissC)(int deviceHandle, int value) {
    return IDS_realtime_setResolutionBissC_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getResolutionHsslLow
*  Reads out the HSSL resolution low bit.#
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_resolution resolution Resolution in the range of [0..46]
*
*  @return resolution Resolution in the range of [0..46]
*/
int ATTOCUBE_API IDS_realtime_getResolutionHsslLow_IDS_1_0_0(int deviceHandle, int tempVal, int* value_resolution);

static inline int ATTO_FUNCTION(IDS_realtime_getResolutionHsslLow)(int deviceHandle, int tempVal, int* value_resolution) {
    return IDS_realtime_getResolutionHsslLow_IDS_1_0_0(deviceHandle, tempVal, value_resolution);
}


/** @brief @IDS_realtime_setResolutionHsslLow
*  Sets the HSSL resolution low bit.
*
*  @param deviceHandle     Handle of device
*  @param value            Resolution in the Range of [0..46]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setResolutionHsslLow_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setResolutionHsslLow)(int deviceHandle, int value) {
    return IDS_realtime_setResolutionHsslLow_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getResolutionHsslHigh
*  Reads out the HSSL resolution high bit.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_resolution resolution Resolution in the Range of [0..46]
*
*  @return resolution Resolution in the Range of [0..46]
*/
int ATTOCUBE_API IDS_realtime_getResolutionHsslHigh_IDS_1_0_0(int deviceHandle, int tempVal, int* value_resolution);

static inline int ATTO_FUNCTION(IDS_realtime_getResolutionHsslHigh)(int deviceHandle, int tempVal, int* value_resolution) {
    return IDS_realtime_getResolutionHsslHigh_IDS_1_0_0(deviceHandle, tempVal, value_resolution);
}


/** @brief @IDS_realtime_setResolutionHsslHigh
*  Sets the HSSL resolution high bit.
*
*  @param deviceHandle     Handle of device
*  @param value            Resolution in the Range of [0..46]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setResolutionHsslHigh_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setResolutionHsslHigh)(int deviceHandle, int value) {
    return IDS_realtime_setResolutionHsslHigh_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getLinearRange
*  Reads out the range number of Linear/Analog output mode.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_rangenumber rangenumber N, Linear Analog Range is +-2^(N+11) pm, with N /in [0, 34]
*
*  @return rangenumber N, Linear Analog Range is +-2^(N+11) pm, with N /in [0, 34]
*/
int ATTOCUBE_API IDS_realtime_getLinearRange_IDS_1_0_0(int deviceHandle, int tempVal, int* value_rangenumber);

static inline int ATTO_FUNCTION(IDS_realtime_getLinearRange)(int deviceHandle, int tempVal, int* value_rangenumber) {
    return IDS_realtime_getLinearRange_IDS_1_0_0(deviceHandle, tempVal, value_rangenumber);
}


/** @brief @IDS_realtime_setLinearRange
*  Sets the range number of Linear/Analog output mode.
*
*  @param deviceHandle     Handle of device
*  @param rangenumber      N, Linear Analog Range is +-2^(N+11) pm, with N /in [0, 34]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setLinearRange_IDS_1_0_0(int deviceHandle, int rangenumber);

static inline int ATTO_FUNCTION(IDS_realtime_setLinearRange)(int deviceHandle, int rangenumber) {
    return IDS_realtime_setLinearRange_IDS_1_0_0(deviceHandle, rangenumber);
}


/** @brief @IDS_realtime_getPeriodHsslClk
*  Reads out the HSSL period clock.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_period     period Period in the Range of [40ns..10200ns]
*
*  @return period Period in the Range of [40ns..10200ns]
*/
int ATTOCUBE_API IDS_realtime_getPeriodHsslClk_IDS_1_0_0(int deviceHandle, int tempVal, int* value_period);

static inline int ATTO_FUNCTION(IDS_realtime_getPeriodHsslClk)(int deviceHandle, int tempVal, int* value_period) {
    return IDS_realtime_getPeriodHsslClk_IDS_1_0_0(deviceHandle, tempVal, value_period);
}


/** @brief @IDS_realtime_setPeriodHsslClk
*  Set the HSSL period clock.
*
*  @param deviceHandle     Handle of device
*  @param period           Period in the Range of [40ns..10200ns]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setPeriodHsslClk_IDS_1_0_0(int deviceHandle, int period);

static inline int ATTO_FUNCTION(IDS_realtime_setPeriodHsslClk)(int deviceHandle, int period) {
    return IDS_realtime_setPeriodHsslClk_IDS_1_0_0(deviceHandle, period);
}


/** @brief @IDS_realtime_getPeriodHsslGap
*  Reads out the HSSL period gap.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_gap        gap Number of clocks
*
*  @return gap Number of clocks
*/
int ATTOCUBE_API IDS_realtime_getPeriodHsslGap_IDS_1_0_0(int deviceHandle, int tempVal, int* value_gap);

static inline int ATTO_FUNCTION(IDS_realtime_getPeriodHsslGap)(int deviceHandle, int tempVal, int* value_gap) {
    return IDS_realtime_getPeriodHsslGap_IDS_1_0_0(deviceHandle, tempVal, value_gap);
}


/** @brief @IDS_realtime_setPeriodHsslGap
*  Set the HSSL gap.
*
*  @param deviceHandle     Handle of device
*  @param value            Number of clocks
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setPeriodHsslGap_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setPeriodHsslGap)(int deviceHandle, int value) {
    return IDS_realtime_setPeriodHsslGap_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getPeriodSinCosClk
*  Reads out the Sine-Cosine and AquadB period clock.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_period     period 40ns to 10200ns
*
*  @return period 40ns to 10200ns
*/
int ATTOCUBE_API IDS_realtime_getPeriodSinCosClk_IDS_1_0_0(int deviceHandle, int tempVal, int* value_period);

static inline int ATTO_FUNCTION(IDS_realtime_getPeriodSinCosClk)(int deviceHandle, int tempVal, int* value_period) {
    return IDS_realtime_getPeriodSinCosClk_IDS_1_0_0(deviceHandle, tempVal, value_period);
}


/** @brief @IDS_realtime_setPeriodSinCosClk
*  Sets the Sine-Cosine and AquadB period clock.
*
*  @param deviceHandle     Handle of device
*  @param value            period 40ns to 10200ns
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setPeriodSinCosClk_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setPeriodSinCosClk)(int deviceHandle, int value) {
    return IDS_realtime_setPeriodSinCosClk_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getResolutionSinCos
*  Reads out the Sine-Cosine and AquadB resolution.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_resolution resolution 1pm to 65535pm
*
*  @return resolution 1pm to 65535pm
*/
int ATTOCUBE_API IDS_realtime_getResolutionSinCos_IDS_1_0_0(int deviceHandle, int tempVal, int* value_resolution);

static inline int ATTO_FUNCTION(IDS_realtime_getResolutionSinCos)(int deviceHandle, int tempVal, int* value_resolution) {
    return IDS_realtime_getResolutionSinCos_IDS_1_0_0(deviceHandle, tempVal, value_resolution);
}


/** @brief @IDS_realtime_setResolutionSinCos
*  Sets the Sine-Cosine and AquadB resolution.
*
*  @param deviceHandle     Handle of device
*  @param value            resolution 1pm to 65535pm
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setResolutionSinCos_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setResolutionSinCos)(int deviceHandle, int value) {
    return IDS_realtime_setResolutionSinCos_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_getHighPassCutOffFreq
*  Reads out the high pass filter number of Linear/Analog output mode.
*
*  @param deviceHandle     Handle of device
*  @param tempVal          
*
*  @param value_value      value N, Linear Analog High Pass Cut-Off freqency is 1600/2^N kHz, with N /in [1,24]
*
*  @return value N, Linear Analog High Pass Cut-Off freqency is 1600/2^N kHz, with N /in [1,24]
*/
int ATTOCUBE_API IDS_realtime_getHighPassCutOffFreq_IDS_1_0_0(int deviceHandle, int tempVal, int* value_value);

static inline int ATTO_FUNCTION(IDS_realtime_getHighPassCutOffFreq)(int deviceHandle, int tempVal, int* value_value) {
    return IDS_realtime_getHighPassCutOffFreq_IDS_1_0_0(deviceHandle, tempVal, value_value);
}


/** @brief @IDS_realtime_setHighPassCutOffFreq
*  Sets the high pass filter number of Linear/Analog output mode.
*
*  @param deviceHandle     Handle of device
*  @param value            N, Linear Analog High Pass Cut-Off freqency is 1600/2^N kHz, with N /in [1,24]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setHighPassCutOffFreq_IDS_1_0_0(int deviceHandle, int value);

static inline int ATTO_FUNCTION(IDS_realtime_setHighPassCutOffFreq)(int deviceHandle, int value) {
    return IDS_realtime_setHighPassCutOffFreq_IDS_1_0_0(deviceHandle, value);
}


/** @brief @IDS_realtime_setAaf
*  Sets the anti-aliasing filter with assigned filter window.
*
*  @param deviceHandle     Handle of device
*  @param enabled          0 - disables the Anti-Aliasing Filter /n 1 - enables the Anti-Aliasing Filter
*  @param attenuation      [3-30] dB m f_nyquist
*  @param window           0 = Rectangular,/n 1 = Cosine,/n 2 = Cosine^2,/n 3 = Hamming,/n 4 = Raised Cosine,/n 5 = Automatic
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_setAaf_IDS_1_0_0(int deviceHandle, int enabled, int attenuation, int window);

static inline int ATTO_FUNCTION(IDS_realtime_setAaf)(int deviceHandle, int enabled, int attenuation, int window) {
    return IDS_realtime_setAaf_IDS_1_0_0(deviceHandle, enabled, attenuation, window);
}


/** @brief @IDS_realtime_getAafAttenuation
*  Returns the current attenuation at f_nyquist of the anti-aliasing filter.
*
*  @param deviceHandle     Handle of device
*
*  @param value_attenuation attenuation [3-30] dB m f_nyquist
*
*  @return attenuation [3-30] dB m f_nyquist
*/
int ATTOCUBE_API IDS_realtime_getAafAttenuation_IDS_1_0_0(int deviceHandle, int* value_attenuation);

static inline int ATTO_FUNCTION(IDS_realtime_getAafAttenuation)(int deviceHandle, int* value_attenuation) {
    return IDS_realtime_getAafAttenuation_IDS_1_0_0(deviceHandle, value_attenuation);
}


/** @brief @IDS_realtime_getAafWindow
*  Returns the current filter window of the anti-aliasing filter.
*
*  @param deviceHandle     Handle of device
*
*  @param value_window     window 0 = Rectangular,/n 1 = Cosine,/n 2 = Cosine^2,/n 3 = Hamming,/n 4 = Raised Cosine,/n 5 = Automatic
*
*  @return window 0 = Rectangular,/n 1 = Cosine,/n 2 = Cosine^2,/n 3 = Hamming,/n 4 = Raised Cosine,/n 5 = Automatic
*/
int ATTOCUBE_API IDS_realtime_getAafWindow_IDS_1_0_0(int deviceHandle, int* value_window);

static inline int ATTO_FUNCTION(IDS_realtime_getAafWindow)(int deviceHandle, int* value_window) {
    return IDS_realtime_getAafWindow_IDS_1_0_0(deviceHandle, value_window);
}


/** @brief @IDS_realtime_AafIsEnabled
*  Checks if the anti-aliasing filter is enabled.
*
*  @param deviceHandle     Handle of device
*
*  @param value_enabled    enabled false: Anti-Aliasing Filter is disabled /ntrue: Anti-Aliasing Filter is enabled
*
*  @return enabled false: Anti-Aliasing Filter is disabled /ntrue: Anti-Aliasing Filter is enabled
*/
int ATTOCUBE_API IDS_realtime_AafIsEnabled_IDS_1_0_0(int deviceHandle, bool* value_enabled);

static inline int ATTO_FUNCTION(IDS_realtime_AafIsEnabled)(int deviceHandle, bool* value_enabled) {
    return IDS_realtime_AafIsEnabled_IDS_1_0_0(deviceHandle, value_enabled);
}


/** @brief @IDS_realtime_getAafEnabled
*  Checks if the anti-aliasing filter is enabled.
*
*  @param deviceHandle     Handle of device
*
*  @param value_enabled    enabled false - the Anti-Aliasing Filter is disabled /n true - the Anti-Aliasing Filter is enabled
*
*  @return enabled false - the Anti-Aliasing Filter is disabled /n true - the Anti-Aliasing Filter is enabled
*/
int ATTOCUBE_API IDS_realtime_getAafEnabled_IDS_1_0_0(int deviceHandle, bool* value_enabled);

static inline int ATTO_FUNCTION(IDS_realtime_getAafEnabled)(int deviceHandle, bool* value_enabled) {
    return IDS_realtime_getAafEnabled_IDS_1_0_0(deviceHandle, value_enabled);
}


/** @brief @IDS_realtime_apply
*  Applies new real time settings.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_apply_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_realtime_apply)(int deviceHandle) {
    return IDS_realtime_apply_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_realtime_discard
*  Discards new real time settings.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_discard_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_realtime_discard)(int deviceHandle) {
    return IDS_realtime_discard_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_realtime_enableTestChannel
*  Enables the Test Channel, which can be used for estimating the maximum signal range.
*
*  @param deviceHandle     Handle of device
*  @param axis             Test Channel Master Axis
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_enableTestChannel_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_realtime_enableTestChannel)(int deviceHandle, int axis) {
    return IDS_realtime_enableTestChannel_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_realtime_disableTestChannel
*  Disables the test channel.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_realtime_disableTestChannel_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_realtime_disableTestChannel)(int deviceHandle) {
    return IDS_realtime_disableTestChannel_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_realtime_getTestChannelEnabled
*  Checks if the test channel is enabled
*
*  @param deviceHandle     Handle of device
*
*  @param value_enabled    enabled true = enabled, false = disabled
*
*  @return enabled true = enabled, false = disabled
*/
int ATTOCUBE_API IDS_realtime_getTestChannelEnabled_IDS_1_0_0(int deviceHandle, bool* value_enabled);

static inline int ATTO_FUNCTION(IDS_realtime_getTestChannelEnabled)(int deviceHandle, bool* value_enabled) {
    return IDS_realtime_getTestChannelEnabled_IDS_1_0_0(deviceHandle, value_enabled);
}


/** @brief @IDS_system_stopMeasurement
*  Stops the displacement measurement system state.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_stopMeasurement_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_stopMeasurement)(int deviceHandle) {
    return IDS_system_stopMeasurement_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_startMeasurement
*  Starts the displacement measurement system state.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_startMeasurement_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_startMeasurement)(int deviceHandle) {
    return IDS_system_startMeasurement_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_startOpticsAlignment
*  Starts the optical alignment system state.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_startOpticsAlignment_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_startOpticsAlignment)(int deviceHandle) {
    return IDS_system_startOpticsAlignment_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_stopOpticsAlignment
*  Stops the optical alignment system state.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_stopOpticsAlignment_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_stopOpticsAlignment)(int deviceHandle) {
    return IDS_system_stopOpticsAlignment_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_resetAxes
*  Resets the position value of all measurement axes to zero.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_resetAxes_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_resetAxes)(int deviceHandle) {
    return IDS_system_resetAxes_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_resetAxis
*  Resets the position value of a specific measurement axis to zero.
*
*  @param deviceHandle     Handle of device
*  @param axis             [0|1|2]
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_resetAxis_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_system_resetAxis)(int deviceHandle, int axis) {
    return IDS_system_resetAxis_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_system_resetError
*  Resets a measurement error that can have occurred with the aim to continue the interrupted measurement.
*
*  @param deviceHandle     Handle of device
*  @param perform          renormalization
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_resetError_IDS_1_0_0(int deviceHandle, bool perform);

static inline int ATTO_FUNCTION(IDS_system_resetError)(int deviceHandle, bool perform) {
    return IDS_system_resetError_IDS_1_0_0(deviceHandle, perform);
}


/** @brief @IDS_system_getCurrentMode
*  Reads out the current IDS system state.
*
*  @param deviceHandle     Handle of device
*
*  @param value_mode       mode Values: "system idle", "measurement starting", "measurement running", "optics alignment starting", "optics alignment running", "test channels enabled"
*  @param size             Maximum size of buffer value_mode
*
*  @return mode Values: "system idle", "measurement starting", "measurement running", "optics alignment starting", "optics alignment running", "test channels enabled"
*/
int ATTOCUBE_API IDS_system_getCurrentMode_IDS_1_0_0(int deviceHandle, char* value_mode, int size);

static inline int ATTO_FUNCTION(IDS_system_getCurrentMode)(int deviceHandle, char* value_mode, int size) {
    return IDS_system_getCurrentMode_IDS_1_0_0(deviceHandle, value_mode, size);
}


/** @brief @IDS_system_getFpgaVersion
*  Reads out the IDS FPGA version.
*
*  @param deviceHandle     Handle of device
*
*  @param value_version    version Version in the form X.Y.Z
*  @param size             Maximum size of buffer value_version
*
*  @return version Version in the form X.Y.Z
*/
int ATTOCUBE_API IDS_system_getFpgaVersion_IDS_1_0_0(int deviceHandle, char* value_version, int size);

static inline int ATTO_FUNCTION(IDS_system_getFpgaVersion)(int deviceHandle, char* value_version, int size) {
    return IDS_system_getFpgaVersion_IDS_1_0_0(deviceHandle, value_version, size);
}


/** @brief @IDS_system_getDeviceType
*  Reads out the IDS device type.
*
*  @param deviceHandle     Handle of device
*
*  @param value_type       type Type of IDS (e.g. "IDS3010")
*  @param size             Maximum size of buffer value_type
*
*  @return type Type of IDS (e.g. "IDS3010")
*/
int ATTOCUBE_API IDS_system_getDeviceType_IDS_1_0_0(int deviceHandle, char* value_type, int size);

static inline int ATTO_FUNCTION(IDS_system_getDeviceType)(int deviceHandle, char* value_type, int size) {
    return IDS_system_getDeviceType_IDS_1_0_0(deviceHandle, value_type, size);
}


/** @brief @IDS_system_getSystemError
*  Cheks for a system error.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_getSystemError_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_system_getSystemError)(int deviceHandle) {
    return IDS_system_getSystemError_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_system_getNbrFeaturesActivated
*  Reads out the amount of activated features activated on the IDS.
*
*  @param deviceHandle     Handle of device
*
*  @param value_nbr        nbr Gives the number of activated features.
*
*  @return nbr Gives the number of activated features.
*/
int ATTOCUBE_API IDS_system_getNbrFeaturesActivated_IDS_1_0_0(int deviceHandle, int* value_nbr);

static inline int ATTO_FUNCTION(IDS_system_getNbrFeaturesActivated)(int deviceHandle, int* value_nbr) {
    return IDS_system_getNbrFeaturesActivated_IDS_1_0_0(deviceHandle, value_nbr);
}


/** @brief @IDS_system_getFeaturesName
*  Converts the IDS feature number to its corresponding name.
*
*  @param deviceHandle     Handle of device
*  @param featurenumber    Number of feature
*
*  @param value_names      names The name of the corresponding feature
*  @param size             Maximum size of buffer value_names
*
*  @return names The name of the corresponding feature
*/
int ATTOCUBE_API IDS_system_getFeaturesName_IDS_1_0_0(int deviceHandle, int featurenumber, char* value_names, int size);

static inline int ATTO_FUNCTION(IDS_system_getFeaturesName)(int deviceHandle, int featurenumber, char* value_names, int size) {
    return IDS_system_getFeaturesName_IDS_1_0_0(deviceHandle, featurenumber, value_names, size);
}


/** @brief @IDS_system_getInitMode
*  Returns the Initialization mode.
*
*  @param deviceHandle     Handle of device
*
*  @param value_mode       mode 0 = High Accuracy Initialization; 1 = Quick Initialization
*
*  @return mode 0 = High Accuracy Initialization; 1 = Quick Initialization
*/
int ATTOCUBE_API IDS_system_getInitMode_IDS_1_0_0(int deviceHandle, int* value_mode);

static inline int ATTO_FUNCTION(IDS_system_getInitMode)(int deviceHandle, int* value_mode) {
    return IDS_system_getInitMode_IDS_1_0_0(deviceHandle, value_mode);
}


/** @brief @IDS_system_setInitMode
*  Sets the mode for the initialization procedure that is performed when starting a measurement.
*
*  @param deviceHandle     Handle of device
*  @param mode             0 = High Accuracy Initialization; 1 = Quick Initialization
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_system_setInitMode_IDS_1_0_0(int deviceHandle, int mode);

static inline int ATTO_FUNCTION(IDS_system_setInitMode)(int deviceHandle, int mode) {
    return IDS_system_setInitMode_IDS_1_0_0(deviceHandle, mode);
}


/** @brief @IDS_nlc_clearLut
*  Deactivates the LUT and removes it from the device
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_clearLut_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_nlc_clearLut)(int deviceHandle, int axis) {
    return IDS_nlc_clearLut_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_nlc_createLut
*  Creates a new LUT for the given axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS where the LUT should be generated
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_createLut_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_nlc_createLut)(int deviceHandle, int axis) {
    return IDS_nlc_createLut_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_nlc_estimateNonlinearities
*  Estimates the nonlinearity error for the current device settings without changing or updating any settings.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the nonlinearity error is to be estimated
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_estimateNonlinearities_IDS_1_0_0(int deviceHandle, int axis);

static inline int ATTO_FUNCTION(IDS_nlc_estimateNonlinearities)(int deviceHandle, int axis) {
    return IDS_nlc_estimateNonlinearities_IDS_1_0_0(deviceHandle, axis);
}


/** @brief @IDS_nlc_getDynamicNormalization
*  Returns the normalization mode of a specific axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the normalization mode is queried
*
*  @param mode             Normalization Mode

    0    Dynamic normalization

    1    Normalization frozen

    2    Normalization mode determined by target velocity
*
*  @return Normalization Mode

    0    Dynamic normalization

    1    Normalization frozen

    2    Normalization mode determined by target velocity
*/
int ATTOCUBE_API IDS_nlc_getDynamicNormalization_IDS_1_0_0(int deviceHandle, int axis, int* mode);

static inline int ATTO_FUNCTION(IDS_nlc_getDynamicNormalization)(int deviceHandle, int axis, int* mode) {
    return IDS_nlc_getDynamicNormalization_IDS_1_0_0(deviceHandle, axis, mode);
}


/** @brief @IDS_nlc_getHistogram
*  Returns a histogram of the measured nonlinearity errors obtained from the last call of createLut or estimateNonlinearites.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS
*
*  @param histogram        Json dumped histogram array
*  @param size             Maximum size of buffer histogram
*
*  @return Json dumped histogram array
*/
int ATTOCUBE_API IDS_nlc_getHistogram_IDS_1_0_0(int deviceHandle, int axis, char* histogram, int size);

static inline int ATTO_FUNCTION(IDS_nlc_getHistogram)(int deviceHandle, int axis, char* histogram, int size) {
    return IDS_nlc_getHistogram_IDS_1_0_0(deviceHandle, axis, histogram, size);
}


/** @brief @IDS_nlc_getLut
*  Returns the LUT determined by createLut (which can be applied by setLutApplied).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS
*
*  @param lut              Json dumped LUT array with 512 integers
*  @param size             Maximum size of buffer lut
*
*  @return Json dumped LUT array with 512 integers
*/
int ATTOCUBE_API IDS_nlc_getLut_IDS_1_0_0(int deviceHandle, int axis, char* lut, int size);

static inline int ATTO_FUNCTION(IDS_nlc_getLut)(int deviceHandle, int axis, char* lut, int size) {
    return IDS_nlc_getLut_IDS_1_0_0(deviceHandle, axis, lut, size);
}


/** @brief @IDS_nlc_getLutApplied
*  Returns whether a LUT is applied or not for a given axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the LUT apply rule is queried
*
*  @param apply            True, if LUT is applied on this axis else False
*
*  @return True, if LUT is applied on this axis else False
*/
int ATTOCUBE_API IDS_nlc_getLutApplied_IDS_1_0_0(int deviceHandle, int axis, bool* apply);

static inline int ATTO_FUNCTION(IDS_nlc_getLutApplied)(int deviceHandle, int axis, bool* apply) {
    return IDS_nlc_getLutApplied_IDS_1_0_0(deviceHandle, axis, apply);
}


/** @brief @IDS_nlc_getLutStatus
*  Returns if a LUT is available and if warnings or errors occurred during creation.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the status of the LUT should be returned
*
*  @param creationWarning  Error or warning number if one occured while creating the LUT, 0 in case of no error
*  @param status           True, if a LUT exists else False
*
*  @return Error or warning number if one occured while creating the LUT, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_getLutStatus_IDS_1_0_0(int deviceHandle, int axis, int* creationWarning, bool* status);

static inline int ATTO_FUNCTION(IDS_nlc_getLutStatus)(int deviceHandle, int axis, int* creationWarning, bool* status) {
    return IDS_nlc_getLutStatus_IDS_1_0_0(deviceHandle, axis, creationWarning, status);
}


/** @brief @IDS_nlc_getNonlinearityEstimation
*  Returns the LUT created by estimateNonlinearities (read-only mode) to compensate the nonlinearity error of the device for the current device settings. If no estimation was created an array of zeros is returned.
*
*  @param deviceHandle     Handle of device
*
*  @param lut              Json dumped LUT array with 512 integers
*  @param size             Maximum size of buffer lut
*
*  @return Json dumped LUT array with 512 integers
*/
int ATTOCUBE_API IDS_nlc_getNonlinearityEstimation_IDS_1_0_0(int deviceHandle, char* lut, int size);

static inline int ATTO_FUNCTION(IDS_nlc_getNonlinearityEstimation)(int deviceHandle, char* lut, int size) {
    return IDS_nlc_getNonlinearityEstimation_IDS_1_0_0(deviceHandle, lut, size);
}


/** @brief @IDS_nlc_getRawLut
*  Returns the raw lut created by createLut or estimateNonlinearites.
*   For debugging only.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS
*
*  @param raw_lut          Json dumped lut array
*  @param size             Maximum size of buffer raw_lut
*
*  @return Json dumped lut array
*/
int ATTOCUBE_API IDS_nlc_getRawLut_IDS_1_0_0(int deviceHandle, int axis, char* raw_lut, int size);

static inline int ATTO_FUNCTION(IDS_nlc_getRawLut)(int deviceHandle, int axis, char* raw_lut, int size) {
    return IDS_nlc_getRawLut_IDS_1_0_0(deviceHandle, axis, raw_lut, size);
}


/** @brief @IDS_nlc_getVelocityThresholds
*  Returns the threshold velocity (in µm/s) for mode 2 of setDynamicNormalization.
*
*  @param deviceHandle     Handle of device
*
*  @param velocityOn       Velocity of the target in µm/s when to switch the normalization on (default: 10 µm/s)
*  @param velocityOff      Velocity of the target in µm/s when to switch the normalization off (default: 5 µm/s)
*
*  @return Velocity of the target in µm/s when to switch the normalization on (default: 10 µm/s)
*/
int ATTOCUBE_API IDS_nlc_getVelocityThresholds_IDS_1_0_0(int deviceHandle, int* velocityOn, int* velocityOff);

static inline int ATTO_FUNCTION(IDS_nlc_getVelocityThresholds)(int deviceHandle, int* velocityOn, int* velocityOff) {
    return IDS_nlc_getVelocityThresholds_IDS_1_0_0(deviceHandle, velocityOn, velocityOff);
}


/** @brief @IDS_nlc_setDynamicNormalization
*  Sets the normalization mode of a specific axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the normalization mode should be set
*  @param mode             Normalization Mode
    0    Dynamic normalization (default)
    1    Normalization frozen (for slow target drifts)
    2    Automatic alternation between mode 0 and 1 depending on the target velocity
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_setDynamicNormalization_IDS_1_0_0(int deviceHandle, int axis, int mode);

static inline int ATTO_FUNCTION(IDS_nlc_setDynamicNormalization)(int deviceHandle, int axis, int mode) {
    return IDS_nlc_setDynamicNormalization_IDS_1_0_0(deviceHandle, axis, mode);
}


/** @brief @IDS_nlc_setLut
*  Uploads a LUT for a specific axis (which can be applied by setLutApplied)
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS
*  @param lut              Json dumped LUT array with 512 integers
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_setLut_IDS_1_0_0(int deviceHandle, int axis, const char* lut);

static inline int ATTO_FUNCTION(IDS_nlc_setLut)(int deviceHandle, int axis, const char* lut) {
    return IDS_nlc_setLut_IDS_1_0_0(deviceHandle, axis, lut);
}


/** @brief @IDS_nlc_setLutApplied
*  Sets the apply rule for the given axis
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis [0|1|2] of the IDS of which the apply rule should be set
*  @param apply            True for applying a LUT, False for disabling a LUT
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_setLutApplied_IDS_1_0_0(int deviceHandle, int axis, bool apply);

static inline int ATTO_FUNCTION(IDS_nlc_setLutApplied)(int deviceHandle, int axis, bool apply) {
    return IDS_nlc_setLutApplied_IDS_1_0_0(deviceHandle, axis, apply);
}


/** @brief @IDS_nlc_setVelocityThresholds
*  Sets the threshold velocity (in µm/s) for mode 2 of setDynamicNormalization. By default, the normalization in mode 2 is frozen for velocities below 5 µm/s and switched to dynamic mode for velocities above 10 µm/s.
*
*  @param deviceHandle     Handle of device
*  @param velocityOn       Velocity of the target in µm/s when to switch the normalization on (default: 10 µm/s)
*  @param velocityOff      Velocity of the target in µm/s when to switch the normalization off (default: 5 µm/s)
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_nlc_setVelocityThresholds_IDS_1_0_0(int deviceHandle, int velocityOn, int velocityOff);

static inline int ATTO_FUNCTION(IDS_nlc_setVelocityThresholds)(int deviceHandle, int velocityOn, int velocityOff) {
    return IDS_nlc_setVelocityThresholds_IDS_1_0_0(deviceHandle, velocityOn, velocityOff);
}


/** @brief @IDS_manual_getHumidityInPercent
*  Reads out the manually configured humidity (compensation mode 1).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the humidity for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param humidity         humidity in hPa
*
*  @return humidity in hPa
*/
int ATTOCUBE_API IDS_manual_getHumidityInPercent_IDS_1_0_0(int deviceHandle, int axis, double* humidity);

static inline int ATTO_FUNCTION(IDS_manual_getHumidityInPercent)(int deviceHandle, int axis, double* humidity) {
    return IDS_manual_getHumidityInPercent_IDS_1_0_0(deviceHandle, axis, humidity);
}


/** @brief @IDS_manual_getPressureInHPa
*  Reads out the manually configured Pressure (compensation mode 1).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the pressure for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param pressure         pressure in hPa
*
*  @return pressure in hPa
*/
int ATTOCUBE_API IDS_manual_getPressureInHPa_IDS_1_0_0(int deviceHandle, int axis, double* pressure);

static inline int ATTO_FUNCTION(IDS_manual_getPressureInHPa)(int deviceHandle, int axis, double* pressure) {
    return IDS_manual_getPressureInHPa_IDS_1_0_0(deviceHandle, axis, pressure);
}


/** @brief @IDS_manual_getRefractiveIndex
*  Reads out the manually configured value for the refractive index (compensation mode 2).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the mode for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param rindex           refractive index
*
*  @return refractive index
*/
int ATTOCUBE_API IDS_manual_getRefractiveIndex_IDS_1_0_0(int deviceHandle, int axis, double* rindex);

static inline int ATTO_FUNCTION(IDS_manual_getRefractiveIndex)(int deviceHandle, int axis, double* rindex) {
    return IDS_manual_getRefractiveIndex_IDS_1_0_0(deviceHandle, axis, rindex);
}


/** @brief @IDS_manual_getTemperatureInDegrees
*  Reads out the manually configured Temperature (compensation mode 1).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the temperature for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param temperature      temperature in degree celsius
*
*  @return temperature in degree celsius
*/
int ATTOCUBE_API IDS_manual_getTemperatureInDegrees_IDS_1_0_0(int deviceHandle, int axis, double* temperature);

static inline int ATTO_FUNCTION(IDS_manual_getTemperatureInDegrees)(int deviceHandle, int axis, double* temperature) {
    return IDS_manual_getTemperatureInDegrees_IDS_1_0_0(deviceHandle, axis, temperature);
}


/** @brief @IDS_manual_setHumidityInPercent
*  Sets the manually configured Humidity (compensation mode 1). The input range is defined to 0 to 100 % (valid range for the Ciddor Equation).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the humidity for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*  @param humidity         humidity in Percent
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_manual_setHumidityInPercent_IDS_1_0_0(int deviceHandle, int axis, double humidity);

static inline int ATTO_FUNCTION(IDS_manual_setHumidityInPercent)(int deviceHandle, int axis, double humidity) {
    return IDS_manual_setHumidityInPercent_IDS_1_0_0(deviceHandle, axis, humidity);
}


/** @brief @IDS_manual_setPressureInHPa
*  Sets the manually configured Pressure (compensation mode 1). The input range is defined to 800 to 1200 hPa (valid range for the Ciddor Equation).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the pressure for-
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*  @param pressure         pressure in hPa
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_manual_setPressureInHPa_IDS_1_0_0(int deviceHandle, int axis, double pressure);

static inline int ATTO_FUNCTION(IDS_manual_setPressureInHPa)(int deviceHandle, int axis, double pressure) {
    return IDS_manual_setPressureInHPa_IDS_1_0_0(deviceHandle, axis, pressure);
}


/** @brief @IDS_manual_setRefractiveIndex
*  Sets the refractive index for the direct mode (compensation mode 2). The input range is defined to be greater than 1.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the mode for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*  @param rindex           refractive index
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_manual_setRefractiveIndex_IDS_1_0_0(int deviceHandle, int axis, double rindex);

static inline int ATTO_FUNCTION(IDS_manual_setRefractiveIndex)(int deviceHandle, int axis, double rindex) {
    return IDS_manual_setRefractiveIndex_IDS_1_0_0(deviceHandle, axis, rindex);
}


/** @brief @IDS_manual_setTemperatureInDegrees
*  Sets the manually configured Temperature (compensation mode 1). The input range is defined to -40 to +100 °C (valid range for the Ciddor Equation).
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the temperature for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*  @param temperature      temperature in degree celcius
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_manual_setTemperatureInDegrees_IDS_1_0_0(int deviceHandle, int axis, double temperature);

static inline int ATTO_FUNCTION(IDS_manual_setTemperatureInDegrees)(int deviceHandle, int axis, double temperature) {
    return IDS_manual_setTemperatureInDegrees_IDS_1_0_0(deviceHandle, axis, temperature);
}


/** @brief @IDS_ecu_disable
*  Disables the ECU interface.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_ecu_disable_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_ecu_disable)(int deviceHandle) {
    return IDS_ecu_disable_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_ecu_enable
*  Enables the ECU interface.
*
*  @param deviceHandle     Handle of device
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_ecu_enable_IDS_1_0_0(int deviceHandle);

static inline int ATTO_FUNCTION(IDS_ecu_enable)(int deviceHandle) {
    return IDS_ecu_enable_IDS_1_0_0(deviceHandle);
}


/** @brief @IDS_ecu_getConnected
*  Reads out whether the ECU interface is physically connected or not. Checking if the ECU is connected can only be done on an enabled ECU interface.
*
*  @param deviceHandle     Handle of device
*
*  @param connected        true if connected, false if not
*
*  @return true if connected, false if not
*/
int ATTOCUBE_API IDS_ecu_getConnected_IDS_1_0_0(int deviceHandle, bool* connected);

static inline int ATTO_FUNCTION(IDS_ecu_getConnected)(int deviceHandle, bool* connected) {
    return IDS_ecu_getConnected_IDS_1_0_0(deviceHandle, connected);
}


/** @brief @IDS_ecu_getEnabled
*  Reads out whether the ECU interface is enabled or not. Enabling the ECU interface is crucial for working with the ECU.
*
*  @param deviceHandle     Handle of device
*
*  @param enabled          true if enabled, false if not
*
*  @return true if enabled, false if not
*/
int ATTOCUBE_API IDS_ecu_getEnabled_IDS_1_0_0(int deviceHandle, bool* enabled);

static inline int ATTO_FUNCTION(IDS_ecu_getEnabled)(int deviceHandle, bool* enabled) {
    return IDS_ecu_getEnabled_IDS_1_0_0(deviceHandle, enabled);
}


/** @brief @IDS_ecu_getHumidityInPercent
*  Reads out the ECU measured air humidity in percent.
*
*  @param deviceHandle     Handle of device
*
*  @param humidity         humidity in %
*
*  @return humidity in %
*/
int ATTOCUBE_API IDS_ecu_getHumidityInPercent_IDS_1_0_0(int deviceHandle, double* humidity);

static inline int ATTO_FUNCTION(IDS_ecu_getHumidityInPercent)(int deviceHandle, double* humidity) {
    return IDS_ecu_getHumidityInPercent_IDS_1_0_0(deviceHandle, humidity);
}


/** @brief @IDS_ecu_getPressureInHPa
*  Reads out the ECU measured air pressure in hPa.
*
*  @param deviceHandle     Handle of device
*
*  @param pressure         pressure in hPa
*
*  @return pressure in hPa
*/
int ATTOCUBE_API IDS_ecu_getPressureInHPa_IDS_1_0_0(int deviceHandle, double* pressure);

static inline int ATTO_FUNCTION(IDS_ecu_getPressureInHPa)(int deviceHandle, double* pressure) {
    return IDS_ecu_getPressureInHPa_IDS_1_0_0(deviceHandle, pressure);
}


/** @brief @IDS_ecu_getRefractiveIndex
*  Reads out the ECU estimated refractive index for the current
*   ECU readings. To get the refractive index for other modes, please see
*   getRefractiveIndexForCompensation.
*
*  @param deviceHandle     Handle of device
*
*  @param rIndex           refractive index
*
*  @return refractive index
*/
int ATTOCUBE_API IDS_ecu_getRefractiveIndex_IDS_1_0_0(int deviceHandle, double* rIndex);

static inline int ATTO_FUNCTION(IDS_ecu_getRefractiveIndex)(int deviceHandle, double* rIndex) {
    return IDS_ecu_getRefractiveIndex_IDS_1_0_0(deviceHandle, rIndex);
}


/** @brief @IDS_ecu_getRefractiveIndexCompensationMode
*  Reads out the compensation mode (see below) which is currently used for the environmental compensation.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the mode for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param mode             mode see defintion in set function
*
*  @return mode see defintion in set function
*/
int ATTOCUBE_API IDS_ecu_getRefractiveIndexCompensationMode_IDS_1_0_0(int deviceHandle, int axis, int* mode);

static inline int ATTO_FUNCTION(IDS_ecu_getRefractiveIndexCompensationMode)(int deviceHandle, int axis, int* mode) {
    return IDS_ecu_getRefractiveIndexCompensationMode_IDS_1_0_0(deviceHandle, axis, mode);
}


/** @brief @IDS_ecu_getRefractiveIndexForCompensation
*  Reads out the refractive index used according to the current environmental compensation mode for this axis.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to get the refractive index for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*
*  @param rIndex           refractive index
*
*  @return refractive index
*/
int ATTOCUBE_API IDS_ecu_getRefractiveIndexForCompensation_IDS_1_0_0(int deviceHandle, int axis, double* rIndex);

static inline int ATTO_FUNCTION(IDS_ecu_getRefractiveIndexForCompensation)(int deviceHandle, int axis, double* rIndex) {
    return IDS_ecu_getRefractiveIndexForCompensation_IDS_1_0_0(deviceHandle, axis, rIndex);
}


/** @brief @IDS_ecu_getTemperatureInDegrees
*  Reads out the ECU measured air temperature in degrees Celsius.
*
*  @param deviceHandle     Handle of device
*
*  @param temperature      temperature in degrees C
*
*  @return temperature in degrees C
*/
int ATTOCUBE_API IDS_ecu_getTemperatureInDegrees_IDS_1_0_0(int deviceHandle, double* temperature);

static inline int ATTO_FUNCTION(IDS_ecu_getTemperatureInDegrees)(int deviceHandle, double* temperature) {
    return IDS_ecu_getTemperatureInDegrees_IDS_1_0_0(deviceHandle, temperature);
}


/** @brief @IDS_ecu_setRefractiveIndexCompensationMode
*  Sets the refractive index mode.
*
*  @param deviceHandle     Handle of device
*  @param axis             Axis to set the mode for.
Parameter has to be -1 for the moment,
individual axes will be supported in the next firmware release
*  @param mode             mode can be 0 for direct ECU mode, 1 to take the manual values and calculate the refractive index from this or 2 to directly take the set refrative index
*
*  @return Error number if one occurred, 0 in case of no error
*/
int ATTOCUBE_API IDS_ecu_setRefractiveIndexCompensationMode_IDS_1_0_0(int deviceHandle, int axis, int mode);

static inline int ATTO_FUNCTION(IDS_ecu_setRefractiveIndexCompensationMode)(int deviceHandle, int axis, int mode) {
    return IDS_ecu_setRefractiveIndexCompensationMode_IDS_1_0_0(deviceHandle, axis, mode);
}


#ifdef __cplusplus
}
#endif
#undef ATTO_PREFIX
#endif // __GENERATEDAPI_H_IDS_1_0_0__