function [errorcode] = condenser_heaterRampOn(tcp, rate)
% brief : Set condenser heater ramp on
%
% param[in] tcp: TCP/IP connection ID
%           rate: Ramp rate in Kelvin / minute 0.1 - 100
% param[out]
%           errorcode: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.heaterRampOn", "params": [%d], "id": 1, "api": 2}', rate);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end