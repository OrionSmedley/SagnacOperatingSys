function [errorNumber, present] = magnet_getPersistentSwitchPresent(tcp, channel)
% brief : Gets whether the persistent switch option is present for a channel
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
% param[out]
%           errorNumber: No error = 0
%           present: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getPersistentSwitchPresent", "params": [%i], "id": 1, "api": 2}', channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
present = data.result(2);


end