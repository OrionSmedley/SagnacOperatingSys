function [errorNumber, Configuration_settings] = system_getAvailableConfigurationSettings(tcp)
% brief : Gets all available configuration settings
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           Configuration_settings: CSV of configuration settings


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getAvailableConfigurationSettings", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Configuration_settings = data.result(2);


end