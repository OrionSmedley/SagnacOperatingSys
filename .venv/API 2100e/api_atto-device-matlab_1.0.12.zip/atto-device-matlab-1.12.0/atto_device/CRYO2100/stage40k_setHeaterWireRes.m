function [errorNumber] = stage40k_setHeaterWireRes(tcp, value)
% brief : Sets the Stage40K heater wire resistance
%
% param[in] tcp: TCP/IP connection ID
%           value: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.setHeaterWireRes", "params": [%d], "id": 1, "api": 2}', value);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end