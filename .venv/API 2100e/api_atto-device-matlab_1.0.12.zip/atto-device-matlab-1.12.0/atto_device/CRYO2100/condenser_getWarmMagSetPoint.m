function [errorNumber, Set_point] = condenser_getWarmMagSetPoint(tcp)
% brief : Gets offset between sample and condenser
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           Set_point: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getWarmMagSetPoint", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Set_point = data.result(2);


end