function [errorNumber] = main_changeCryostatType(tcp, newType)
% brief : Change the cryostat type
%
% param[in] tcp: TCP/IP connection ID
%           newType: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.main.changeCryostatType", "params": [%s], "id": 1, "api": 2}', newType);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end