function [errorNumber] = magnet_setHSetPoint3D(tcp, setPointZ, setPointY, setPointX)
% brief : Sets the magnetic field set points
%
% param[in] tcp: TCP/IP connection ID
%           setPointZ: 
%           setPointY: 
%           setPointX: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setHSetPoint3D", "params": [%d, %d, %d], "id": 1, "api": 2}', setPointZ, setPointY, setPointX);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end