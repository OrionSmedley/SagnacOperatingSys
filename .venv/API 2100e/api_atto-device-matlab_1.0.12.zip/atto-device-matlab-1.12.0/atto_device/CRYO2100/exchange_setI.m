function [errorNumber] = exchange_setI(tcp, value)
% brief : Sets the exchange heater I value
%
% param[in] tcp: TCP/IP connection ID
%           value: 
% param[out]
%           errorNumber: No error = 0:param value::param value:


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.setI", "params": [%d], "id": 1, "api": 2}', value);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end