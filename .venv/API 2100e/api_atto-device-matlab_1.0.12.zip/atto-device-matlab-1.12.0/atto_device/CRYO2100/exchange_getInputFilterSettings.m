function [errorNumber, off_or_on, point, window] = exchange_getInputFilterSettings(tcp)
% brief : Gets the vti input filter settings
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           off_or_on: 
%           point: 
%           window: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.getInputFilterSettings", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
off_or_on = data.result(2);
point = data.result(3);
window = data.result(4);


end