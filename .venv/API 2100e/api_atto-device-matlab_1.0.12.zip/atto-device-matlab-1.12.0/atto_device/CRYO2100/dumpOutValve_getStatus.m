function [errorNumber, dump_out_valve_status] = dumpOutValve_getStatus(tcp)
% brief : Gets the dump out valve status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           dump_out_valve_status: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.dumpOutValve.getStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
dump_out_valve_status = data.result(2);


end