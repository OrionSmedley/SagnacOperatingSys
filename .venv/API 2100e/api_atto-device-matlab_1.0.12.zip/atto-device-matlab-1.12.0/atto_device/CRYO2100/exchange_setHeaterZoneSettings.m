function [errorcode] = exchange_setHeaterZoneSettings(tcp, zone, upperbound, P, I, D, manualOutput, heatingRange)
% brief : Set exchange heater zone settings
%
% param[in] tcp: TCP/IP connection ID
%           zone: Zone number
%           upperbound: Upper Setpoint boundary of this zone in kelvin
%           P: P
%           I: I
%           D: D
%           manualOutput: Manual output for this zone 0 to 100%
%           heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
% param[out]
%           errorcode: Error code


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.setHeaterZoneSettings", "params": [%i, %d, %d, %d, %d, %d, %i], "id": 1, "api": 2}', zone, upperbound, P, I, D, manualOutput, heatingRange);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end