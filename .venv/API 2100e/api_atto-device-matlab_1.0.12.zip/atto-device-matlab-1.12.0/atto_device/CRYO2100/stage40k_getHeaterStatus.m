function [errorNumber] = stage40k_getHeaterStatus(tcp)
% brief : Gets the Stage40K heater status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error  = 0Open load = 32Short     = 33


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getHeaterStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end