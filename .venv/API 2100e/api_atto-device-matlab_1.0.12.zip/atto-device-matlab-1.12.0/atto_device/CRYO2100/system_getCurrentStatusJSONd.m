function [errorNumber, status] = system_getCurrentStatusJSONd(tcp)
% brief : Get the current cryostat status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           status: Cryostat status


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getCurrentStatusJSONd", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
status = data.result(2);


end