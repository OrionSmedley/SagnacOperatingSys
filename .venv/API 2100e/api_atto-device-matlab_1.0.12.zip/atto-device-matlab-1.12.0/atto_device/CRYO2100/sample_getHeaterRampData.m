function [errorcode, OnOff, Rate] = sample_getHeaterRampData(tcp)
% brief : Get sample heater ramp data
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: 
%           OnOff: Ramp is on or off
%           Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.sample.getHeaterRampData", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
OnOff = data.result(2);
Rate = data.result(3);


end