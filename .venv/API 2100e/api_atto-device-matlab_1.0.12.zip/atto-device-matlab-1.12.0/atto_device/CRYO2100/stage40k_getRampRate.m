function [errorcode, Rate] = stage40k_getRampRate(tcp)
% brief : Get Stage40K ramp rate
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: 
%           Rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getRampRate", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
Rate = data.result(2);


end