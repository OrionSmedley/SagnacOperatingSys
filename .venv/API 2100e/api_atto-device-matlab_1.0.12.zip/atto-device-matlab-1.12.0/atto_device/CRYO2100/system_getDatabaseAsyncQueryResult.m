function [errorNumber, result] = system_getDatabaseAsyncQueryResult(tcp, handle)
% brief : Get the query result
%
% param[in] tcp: TCP/IP connection ID
%           handle: 
% param[out]
%           errorNumber: No error = 0
%           result: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getDatabaseAsyncQueryResult", "params": [%i], "id": 1, "api": 2}', handle);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
result = data.result(2);


end