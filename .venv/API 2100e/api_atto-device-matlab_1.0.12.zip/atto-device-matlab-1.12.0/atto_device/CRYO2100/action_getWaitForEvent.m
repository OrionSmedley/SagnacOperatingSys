function [errorNumber, event] = action_getWaitForEvent(tcp)
% brief : Gets the event the cryostat waits for currently
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           event: event the cryostat waits for


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.action.getWaitForEvent", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
event = data.result(2);


end