function [errorNumber, scroll_pump_status] = scrollPump_getStatus(tcp)
% brief : Gets the scroll pump status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           scroll_pump_status: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.scrollPump.getStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
scroll_pump_status = data.result(2);


end