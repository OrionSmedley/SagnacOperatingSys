function [errorNumber] = magnet_setPersistentMode(tcp, channel, onOrOff)
% brief : Sets the magnet persistent heater
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
%           onOrOff: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setPersistentMode", "params": [%i, %i], "id": 1, "api": 2}', channel, onOrOff);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end