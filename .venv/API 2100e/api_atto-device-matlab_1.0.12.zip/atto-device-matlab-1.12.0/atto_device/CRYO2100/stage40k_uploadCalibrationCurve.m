function [errorNumber] = stage40k_uploadCalibrationCurve(tcp, calibrationData)
% brief : Sets the Stage40K sensor calibration curve    may time out, but the upload will still work
%
% param[in] tcp: TCP/IP connection ID
%           calibrationData: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.uploadCalibrationCurve", "params": [%s], "id": 1, "api": 2}', calibrationData);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end