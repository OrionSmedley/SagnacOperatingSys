function [errorNumber, Stage40K_resistance] = stage40k_getResistance(tcp)
% brief : Gets the Stage40K resistance
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           Stage40K_resistance: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getResistance", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Stage40K_resistance = data.result(2);


end