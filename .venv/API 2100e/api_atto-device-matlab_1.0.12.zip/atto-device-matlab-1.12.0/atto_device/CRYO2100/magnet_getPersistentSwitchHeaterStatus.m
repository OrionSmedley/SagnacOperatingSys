function [errorNumber, state] = magnet_getPersistentSwitchHeaterStatus(tcp, channel)
% brief : Gets the state of the Persistent Heater
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
% param[out]
%           errorNumber: No error = 0
%           state: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getPersistentSwitchHeaterStatus", "params": [%i], "id": 1, "api": 2}', channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
state = data.result(2);


end