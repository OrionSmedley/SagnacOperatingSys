function [errorcode, number_of_zones] = stage40k_getHeaterNumberOfDefaultZones(tcp)
% brief : Get the number of the Stage40K heater default zones
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: Error code
%           number_of_zones: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getHeaterNumberOfDefaultZones", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
number_of_zones = data.result(2);


end