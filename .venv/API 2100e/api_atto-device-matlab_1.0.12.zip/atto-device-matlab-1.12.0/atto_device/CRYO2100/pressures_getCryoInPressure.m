function [errorNumber, cryostat_in_pressure] = pressures_getCryoInPressure(tcp)
% brief : Gets the cryostat in pressure
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           cryostat_in_pressure: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.pressures.getCryoInPressure", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
cryostat_in_pressure = data.result(2);


end