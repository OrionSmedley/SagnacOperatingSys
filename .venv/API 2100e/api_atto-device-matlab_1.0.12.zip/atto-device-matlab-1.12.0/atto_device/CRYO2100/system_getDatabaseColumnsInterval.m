function [errorNumber, result_rows] = system_getDatabaseColumnsInterval(tcp)
% brief : Get the cryostat long term status of a time interval    The query has to be prepared with prepareDatabaseColumnsInterval() before. Query until the result is empty    Currently only one query is allowed. If several clients do this simultaneously the results will be garbled. The last client "wins"        We like to query this as quickly as possible. So don't wait after the call here.    Deprecated!!!!
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           result_rows: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getDatabaseColumnsInterval", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
result_rows = data.result(2);


end