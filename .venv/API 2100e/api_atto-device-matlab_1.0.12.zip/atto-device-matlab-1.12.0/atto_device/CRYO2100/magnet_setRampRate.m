function [errorNumber] = magnet_setRampRate(tcp, channel, index, range_this, rate)
% brief : Change the ramp rates
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
%           index: 
%           range_this: 
%           rate: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setRampRate", "params": [%i, %i, %d, %d], "id": 1, "api": 2}', channel, index, range_this, rate);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end