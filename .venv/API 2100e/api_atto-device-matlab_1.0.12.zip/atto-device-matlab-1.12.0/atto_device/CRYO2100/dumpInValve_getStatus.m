function [errorNumber, dump_in_valve_status] = dumpInValve_getStatus(tcp)
% brief : Gets the dump in valve status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           dump_in_valve_status: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.dumpInValve.getStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
dump_in_valve_status = data.result(2);


end