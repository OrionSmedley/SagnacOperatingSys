function [errorNumber, infoJson] = system_getAutoprobeInformationJSONd(tcp)
% brief : Get the hardware autoprobe information
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           infoJson: JSONd autoprobe information


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getAutoprobeInformationJSONd", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
infoJson = data.result(2);


end