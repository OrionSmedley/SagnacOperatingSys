function [errorNumber] = exchange_setMaxPower(tcp, value)
% brief : Sets the exchange heater maximum power
%
% param[in] tcp: TCP/IP connection ID
%           value: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.setMaxPower", "params": [%d], "id": 1, "api": 2}', value);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end