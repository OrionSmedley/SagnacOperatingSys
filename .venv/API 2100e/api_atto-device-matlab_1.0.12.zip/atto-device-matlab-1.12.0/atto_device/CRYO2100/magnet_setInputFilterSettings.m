function [errorNumber] = magnet_setInputFilterSettings(tcp, filterOn, numberOfPoints, windowSize)
% brief : Sets the magnet input filter settings
%
% param[in] tcp: TCP/IP connection ID
%           filterOn: 
%           numberOfPoints: 
%           windowSize: 
% param[out]
%           errorNumber: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setInputFilterSettings", "params": [%i, %i, %i], "id": 1, "api": 2}', filterOn, numberOfPoints, windowSize);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end