function [errorNumber] = action_postEvent(tcp, eventName)
% brief : Posts the event. See: getWaitForEvent()
%
% param[in] tcp: TCP/IP connection ID
%           eventName: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.action.postEvent", "params": [%s], "id": 1, "api": 2}', eventName);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end