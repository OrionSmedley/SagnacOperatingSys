function [errorNumber, resistance] = condenser_getHeaterRes(tcp)
% brief : Gets the condenser heater resistance
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           resistance: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getHeaterRes", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
resistance = data.result(2);


end