function [errorNumber] = condenser_setBaseTSetPoint(tcp, offset)
% brief : Sets offset between sample and condenser
%
% param[in] tcp: TCP/IP connection ID
%           offset: ----------
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.setBaseTSetPoint", "params": [%d], "id": 1, "api": 2}', offset);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end