function [errorNumber, mode] = stage40k_getHeaterHeatingMode(tcp)
% brief : Gets the Stage40K heater heating mode
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           mode: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getHeaterHeatingMode", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
mode = data.result(2);


end