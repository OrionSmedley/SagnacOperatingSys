function [errorNumber] = exchange_setSetPoint(tcp, temperature)
% brief : Sets the exchange set point
%
% param[in] tcp: TCP/IP connection ID
%           temperature: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.setSetPoint", "params": [%d], "id": 1, "api": 2}', temperature);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end