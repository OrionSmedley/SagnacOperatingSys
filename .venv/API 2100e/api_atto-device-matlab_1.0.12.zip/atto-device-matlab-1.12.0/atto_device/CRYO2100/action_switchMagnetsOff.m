function [errorNumber] = action_switchMagnetsOff(tcp)
% brief : Switches magnets off
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.action.switchMagnetsOff", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end