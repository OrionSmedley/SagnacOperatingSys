function [errorNumber, num] = magnet_getNumRampRates(tcp, channel)
% brief : Return the number of RampRates
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
% param[out]
%           errorNumber: 
%           num: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getNumRampRates", "params": [%i], "id": 1, "api": 2}', channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
num = data.result(2);


end