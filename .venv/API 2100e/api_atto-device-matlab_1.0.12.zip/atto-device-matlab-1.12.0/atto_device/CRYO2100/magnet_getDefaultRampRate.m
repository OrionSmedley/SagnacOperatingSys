function [errorNumber, range, rate] = magnet_getDefaultRampRate(tcp, index, channel)
% brief : Get the factory defaults for the Ramp Rates
%
% param[in] tcp: TCP/IP connection ID
%           index: 
%           channel: 
% param[out]
%           errorNumber: No error = 0
%           range: 
%           rate: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getDefaultRampRate", "params": [%i, %i], "id": 1, "api": 2}', index, channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
range = data.result(2);
rate = data.result(3);


end