function [errorNumber, name] = magnet_getMagnetChannelName(tcp, channel)
% brief : Gets the Name of magnets
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
% param[out]
%           errorNumber: No error = 0
%           name: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getMagnetChannelName", "params": [%i], "id": 1, "api": 2}', channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
name = data.result(2);


end