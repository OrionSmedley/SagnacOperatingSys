function [errorNumber, range, rate] = magnet_getRampRate(tcp, channel, index)
% brief : Get ramp rate at index for channel
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
%           index: 
% param[out]
%           errorNumber: No error = 0
%           range: 
%           rate: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getRampRate", "params": [%i, %i], "id": 1, "api": 2}', channel, index);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
range = data.result(2);
rate = data.result(3);


end