function [errorNumber, calibration_data] = magnet_downloadCalibrationCurve(tcp)
% brief : Gets the magnet sensor calibration curve
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           calibration_data: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.downloadCalibrationCurve", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
calibration_data = data.result(2);


end