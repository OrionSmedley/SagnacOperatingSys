function [errorNumber, proportional, integral, derivative] = stage40k_getPID(tcp)
% brief : Gets the Stage40K heater PID values
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           proportional: 
%           integral: 
%           derivative: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getPID", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
proportional = data.result(2);
integral = data.result(3);
derivative = data.result(4);


end