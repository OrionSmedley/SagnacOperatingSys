function [errorNumber] = magnet_setPersistentMode3D(tcp, onOff)
% brief : Sets the combined persistent mode
%
% param[in] tcp: TCP/IP connection ID
%           onOff: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setPersistentMode3D", "params": [%i], "id": 1, "api": 2}', onOff);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end