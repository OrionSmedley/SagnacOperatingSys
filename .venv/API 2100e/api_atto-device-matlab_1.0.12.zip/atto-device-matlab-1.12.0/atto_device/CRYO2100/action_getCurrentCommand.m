function [errorNumber, current_command] = action_getCurrentCommand(tcp)
% brief : Get current command name
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           current_command: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.action.getCurrentCommand", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
current_command = data.result(2);


end