function [errorcode, upperbound, P, I, D, manualOutput, heatingRange, rampRate] = sample_getHeaterDefaultZoneSettings(tcp, zone)
% brief : Get sample heater zone settings
%
% param[in] tcp: TCP/IP connection ID
%           zone: Zone number
% param[out]
%           errorcode: Error code
%           upperbound: Upper set point boundary of this zone in kelvin
%           P: P
%           I: I
%           D: D
%           manualOutput: Manual output for this zone 0 to 100%
%           heatingRange: Heating range see class HeaterRanges and Lake Shore 336 manual for ZONE command
%           rampRate: Ramp rate for this zone 0.1 100 K/min


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.sample.getHeaterDefaultZoneSettings", "params": [%i], "id": 1, "api": 2}', zone);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
upperbound = data.result(2);
P = data.result(3);
I = data.result(4);
D = data.result(5);
manualOutput = data.result(6);
heatingRange = data.result(7);
rampRate = data.result(8);


end