function [errorcode] = exchange_startRampControl(tcp)
% brief : Set exchange heater ramp on
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.startRampControl", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end