function [errorNumber] = magnet_setPause3D(tcp, onOff)
% brief : Sets the pause state of the power supply channels
%
% param[in] tcp: TCP/IP connection ID
%           onOff: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setPause3D", "params": [%i], "id": 1, "api": 2}', onOff);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end