function [errorNumber, NumberOfRates] = magnet_getNumDefaultRampRates(tcp, channel)
% brief : Gets the number of default RampRates
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
% param[out]
%           errorNumber: 
%           NumberOfRates: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getNumDefaultRampRates", "params": [%i], "id": 1, "api": 2}', channel);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
NumberOfRates = data.result(2);


end