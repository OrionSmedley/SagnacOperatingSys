function [errorNumber, condenser_resistance] = condenser_getResistance(tcp)
% brief : Gets the condenser temperature resistance
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           condenser_resistance: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getResistance", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
condenser_resistance = data.result(2);


end