function [errorcode, rampRate] = condenser_getHeaterAllZoneRampRates(tcp)
% brief : Get condenser heater all zones ramp rate
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: Error code
%           rampRate: Ramp rate for this zone 0.1 100 K/min


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getHeaterAllZoneRampRates", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
rampRate = data.result(2);


end