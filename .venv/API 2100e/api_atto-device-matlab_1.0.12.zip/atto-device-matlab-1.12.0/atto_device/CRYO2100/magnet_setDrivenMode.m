function [errorNumber] = magnet_setDrivenMode(tcp, channel, onOrOff)
% brief : Set driven mode for a specific channel
%
% param[in] tcp: TCP/IP connection ID
%           channel: 
%           onOrOff: drivenMode on or off
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.setDrivenMode", "params": [%i, %i], "id": 1, "api": 2}', channel, onOrOff);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end