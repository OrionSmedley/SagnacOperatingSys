function [errorcode] = condenser_heaterRampOff(tcp)
% brief : Set condenser heater ramp off
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.heaterRampOff", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end