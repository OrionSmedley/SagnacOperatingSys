function [errorcode, OnOff] = stage40k_getRampControlStatus(tcp)
% brief : Get Stage40K heater ramp control status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: 
%           OnOff: Ramp is on or off


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getRampControlStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
OnOff = data.result(2);


end