function [errorNumber, dump_pressure] = pressures_getDumpPressure(tcp)
% brief : Gets the dump pressure
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           dump_pressure: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.pressures.getDumpPressure", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
dump_pressure = data.result(2);


end