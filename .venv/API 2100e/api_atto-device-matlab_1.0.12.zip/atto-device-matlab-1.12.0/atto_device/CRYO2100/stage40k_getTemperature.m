function [errorNumber, Stage40K_temperature] = stage40k_getTemperature(tcp)
% brief : Gets the Stage40K temperature
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           Stage40K_temperature: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.getTemperature", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Stage40K_temperature = data.result(2);


end