function [errorNumber, resistance] = magnet_getResistance(tcp)
% brief : Gets the magnet temperature resistance. There is only one for all magnets
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           resistance: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getResistance", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
resistance = data.result(2);


end