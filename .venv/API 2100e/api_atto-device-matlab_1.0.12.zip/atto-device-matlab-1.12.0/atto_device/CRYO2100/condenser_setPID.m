function [errorNumber] = condenser_setPID(tcp, proportional, integral, derivative)
% brief : Sets the condenser heater PID values
%
% param[in] tcp: TCP/IP connection ID
%           proportional: 
%           integral: 
%           derivative: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.setPID", "params": [%d, %d, %d], "id": 1, "api": 2}', proportional, integral, derivative);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end