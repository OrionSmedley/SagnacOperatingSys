function [errorNumber, exchange_temperature] = exchange_getTemperature(tcp)
% brief : Gets the exchange temperature
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           exchange_temperature: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.getTemperature", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
exchange_temperature = data.result(2);


end