function [errorNumber, onOrOff] = magnet_getLeadsHot(tcp)
% brief : Checks if current is running in the PS Leads
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           onOrOff: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getLeadsHot", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
onOrOff = data.result(2);


end