function [errorNumber, Status] = condenser_getTempControlStatus(tcp)
% brief : Gets the condenser heater status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           Status: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getTempControlStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Status = data.result(2);


end