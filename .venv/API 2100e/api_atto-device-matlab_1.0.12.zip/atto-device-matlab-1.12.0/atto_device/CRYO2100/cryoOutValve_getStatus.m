function [errorNumber, pump_valve_status] = cryoOutValve_getStatus(tcp)
% brief : Gets the cryostat out valve status
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           pump_valve_status: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.cryoOutValve.getStatus", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
pump_valve_status = data.result(2);


end