function [errorNumber] = condenser_setInputFilterSettings(tcp, filterOn, numberOfPoints, windowSize)
% brief : Sets the condenser input filter settings
%
% param[in] tcp: TCP/IP connection ID
%           filterOn: 
%           numberOfPoints: 
%           windowSize: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.setInputFilterSettings", "params": [%i, %i, %i], "id": 1, "api": 2}', filterOn, numberOfPoints, windowSize);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end