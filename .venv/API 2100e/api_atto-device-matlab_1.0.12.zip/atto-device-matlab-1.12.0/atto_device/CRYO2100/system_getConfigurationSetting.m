function [errorNumber, Configuration_setting_value] = system_getConfigurationSetting(tcp, settingName)
% brief : Get the value of the specified configuration setting
%
% param[in] tcp: TCP/IP connection ID
%           settingName: 
% param[out]
%           errorNumber: No error = 0
%           Configuration_setting_value: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getConfigurationSetting", "params": [%s], "id": 1, "api": 2}', settingName);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Configuration_setting_value = data.result(2);


end