function [errorNumber, temperature] = magnet_getTemperature(tcp)
% brief : Gets the magnet temperature. There is only one for all magnets
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           temperature: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getTemperature", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
temperature = data.result(2);


end