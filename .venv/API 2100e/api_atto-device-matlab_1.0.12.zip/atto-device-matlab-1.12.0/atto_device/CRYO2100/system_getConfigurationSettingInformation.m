function [errorNumber, Configuration_settings_information] = system_getConfigurationSettingInformation(tcp, settingName)
% brief : Gets the configuration setting info string
%
% param[in] tcp: TCP/IP connection ID
%           settingName: 
% param[out]
%           errorNumber: No error = 0
%           Configuration_settings_information: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getConfigurationSettingInformation", "params": [%s], "id": 1, "api": 2}', settingName);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
Configuration_settings_information = data.result(2);


end