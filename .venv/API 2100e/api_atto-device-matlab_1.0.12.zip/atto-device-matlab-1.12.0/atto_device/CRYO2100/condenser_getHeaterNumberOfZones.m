function [errorcode, number_of_zones] = condenser_getHeaterNumberOfZones(tcp)
% brief : Get the number of the condenser heater zones
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorcode: Error code
%           number_of_zones: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.getHeaterNumberOfZones", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);
number_of_zones = data.result(2);


end