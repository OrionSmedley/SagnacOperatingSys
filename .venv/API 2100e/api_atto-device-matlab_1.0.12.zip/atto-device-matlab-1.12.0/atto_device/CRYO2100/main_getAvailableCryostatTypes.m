function [errorNumber, types] = main_getAvailableCryostatTypes(tcp)
% brief : Get all available cryostat types
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           types: CSV string of types


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.main.getAvailableCryostatTypes", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
types = data.result(2);


end