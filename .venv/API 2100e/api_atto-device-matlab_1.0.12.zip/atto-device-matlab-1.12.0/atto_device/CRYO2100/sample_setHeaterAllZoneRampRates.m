function [errorcode] = sample_setHeaterAllZoneRampRates(tcp, rampRate)
% brief : Set sample heater all zones ramp rate
%
% param[in] tcp: TCP/IP connection ID
%           rampRate: Ramp rate for this zone 0.1 100 K/min
% param[out]
%           errorcode: Error code


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.sample.setHeaterAllZoneRampRates", "params": [%d], "id": 1, "api": 2}', rampRate);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end