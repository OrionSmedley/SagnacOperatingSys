function [errorNumber, setPointZ, setPointY, setPointX] = magnet_getHSetPoint3D(tcp)
% brief : Gets the magnetic field set points
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           setPointZ: 
%           setPointY: 
%           setPointX: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.getHSetPoint3D", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
setPointZ = data.result(2);
setPointY = data.result(3);
setPointX = data.result(4);


end