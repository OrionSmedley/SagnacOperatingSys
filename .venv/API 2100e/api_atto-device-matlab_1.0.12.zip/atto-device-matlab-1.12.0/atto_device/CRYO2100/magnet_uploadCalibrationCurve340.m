function [errorNumber] = magnet_uploadCalibrationCurve340(tcp, calibrationData)
% brief : Sets the magnet sensor .340 calibration curve    may time out, but the upload will still work
%
% param[in] tcp: TCP/IP connection ID
%           calibrationData: 
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.magnet.uploadCalibrationCurve340", "params": [%s], "id": 1, "api": 2}', calibrationData);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end