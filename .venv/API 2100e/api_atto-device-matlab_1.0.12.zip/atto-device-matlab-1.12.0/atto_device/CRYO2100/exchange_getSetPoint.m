function [errorNumber, set_point] = exchange_getSetPoint(tcp)
% brief : Gets the exchange set point
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           set_point: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.exchange.getSetPoint", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
set_point = data.result(2);


end