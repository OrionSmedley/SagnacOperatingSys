function [errorNumber, calibration_data] = stage40k_downloadCalibrationCurve(tcp)
% brief : Gets the Stage40K sensor calibration curve
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           calibration_data: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.stage40k.downloadCalibrationCurve", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
calibration_data = data.result(2);


end