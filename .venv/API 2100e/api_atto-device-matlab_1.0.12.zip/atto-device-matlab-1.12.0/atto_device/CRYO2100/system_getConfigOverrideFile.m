function [errorNumber, overrideFile] = system_getConfigOverrideFile(tcp)
% brief : Get the EEPROM JSON file containing the config overrides.    To know what entries exist have a look at getAvailableConfigurationSettings()    and getConfigurationSettingInformation()
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           overrideFile: String containing the override file


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.system.getConfigOverrideFile", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
overrideFile = data.result(2);


end