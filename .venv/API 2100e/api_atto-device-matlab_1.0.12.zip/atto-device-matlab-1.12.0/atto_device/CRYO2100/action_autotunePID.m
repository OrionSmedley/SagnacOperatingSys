function [errorNumber] = action_autotunePID(tcp, channel, tuningType)
% brief : Autotune heater PID
%
% param[in] tcp: TCP/IP connection ID
%           channel: Channel number
%           tuningType: 0 tune P, 1 tune PI, 2 tune PID
% param[out]
%           errorNumber: No error = 0


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.action.autotunePID", "params": [%i, %i], "id": 1, "api": 2}', channel, tuningType);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);


end