function [errorNumber, cryostat_out_pressure] = pressures_getCryoOutPressure(tcp)
% brief : Gets the cryostat out pressure
%
% param[in] tcp: TCP/IP connection ID
% param[out]
%           errorNumber: No error = 0
%           cryostat_out_pressure: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.pressures.getCryoOutPressure", "params": [], "id": 1, "api": 2}');

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorNumber = data.result(1);
cryostat_out_pressure = data.result(2);


end