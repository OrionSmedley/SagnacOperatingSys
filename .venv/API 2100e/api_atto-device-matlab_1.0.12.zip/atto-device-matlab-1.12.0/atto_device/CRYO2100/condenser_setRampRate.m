function [errorcode] = condenser_setRampRate(tcp, rate)
% brief : Set condenser ramp rate
%
% param[in] tcp: TCP/IP connection ID
%           rate: Ramp rate in Kelvin / minute. 0.1 - 100. 0.0 means ramp limit is off.
% param[out]
%           errorcode: 


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.cryostat.interface.condenser.setRampRate", "params": [%d], "id": 1, "api": 2}', rate);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errorcode = data.result(1);


end