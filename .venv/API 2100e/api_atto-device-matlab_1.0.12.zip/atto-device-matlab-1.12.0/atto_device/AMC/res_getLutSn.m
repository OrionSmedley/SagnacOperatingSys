function [errNo, value_string] = res_getLutSn(tcp, axis)
% brief : get the identifier of the loaded lookuptable (will be empty if disabled)
%
% param[in] tcp: TCP/IP connection ID
%           axis: [0|1|2]
% param[out]
%           errNo: errNo
%           value_string: string : identifier


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.amc.res.getLutSn", "params": [%i], "id": 1, "api": 2}', axis);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errNo = data.result(1);
value_string = data.result(2);


end