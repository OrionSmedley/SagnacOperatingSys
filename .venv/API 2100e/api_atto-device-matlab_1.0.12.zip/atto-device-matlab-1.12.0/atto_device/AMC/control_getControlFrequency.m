function [errNo, value_frequency] = control_getControlFrequency(tcp, axis)
% brief : This function gets the frequency of the actuator signal of the selected axis.
%
% param[in] tcp: TCP/IP connection ID
%           axis: [0|1|2]
% param[out]
%           errNo: errNo
%           value_frequency: frequency in mHz


data_send = sprintf('{"jsonrpc": "2.0", "method": "com.attocube.amc.control.getControlFrequency", "params": [%i], "id": 1, "api": 2}', axis);

writeline(tcp, data_send);
data_receive = readline(tcp);
data = jsondecode(data_receive);

errNo = data.result(1);
value_frequency = data.result(2);


end