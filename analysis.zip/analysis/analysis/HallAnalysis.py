import os
from itertools import product

import numpy as np
import matplotlib.pyplot as plt
import xarray as xr
from scipy.optimize import leastsq, curve_fit

from .baseAnalysis import baseAnalysis
from .dataset_manipulation import plot_dataset, fit_dataset, fit_dataset_models
from .converters import HallConverter
from .constants import deg2rad, rad2deg
from .parsers import pymeasure_hysteresis_parser

from .models import fitParameter, fitModel, lin_model, const_model

# Fitting models

def first_harmonic_simple_tilt_model(p, IRp, IRa, psi, omega, eta, offset):
    """
    Model for the expected Hall signal if you have a tilted sample and did an
    in-plane angle sweep. Assumes magnetization follows magnetic field perfectly

    Parameters
    ----------
    p : float
        azimuthal angle of the applied magnetic field
    IRp : float
        Planar hall coefficient
    IRa : float
        Anomalous hall coefficient
    psi : float
        tilt angle of sample plane with respect to magnet plane
    omega : float
        angle in the sample plane between current direction on Hall bar and the 
        intersection line of the sample plane and magnet planes
    eta : float
        angle in the magnet plane between the magnet's x axis and the intersection
        line of the sample and magnet planes
    offset : float
        constant offset
    
    Returns
    -------
    float
    """
    phi = p*deg2rad
    psi = psi*deg2rad
    omega = omega*deg2rad
    eta = eta*deg2rad
    phipnum = np.cos(omega) + np.sin(omega)/(np.tan(eta+phi)*np.cos(psi))
    phipdenom = np.cos(omega)/(np.tan(eta+phi)*np.cos(psi))-np.sin(omega)
    phiprime = np.arctan2(phipnum, phipdenom)
    
    costhetap = np.sin(eta+phi)*np.sin(psi) # Bz simplifies to this.
    return IRp*np.sin(2*phiprime)+IRa*costhetap+offset

def first_harmonic_simple_tilt_guess(p, IR, **kwargs):
    """
    Guess function for the Hall tilt model. Not very good.
    """

    amp_guess = np.mean(np.abs(IR))
    offset_guess = np.mean(IR)

    return [0.1*amp_guess, amp_guess, 1e-2, 10, 10, offset_guess]

first_harmonic_simple_tilt_param_names = ['IRp','IRa','psi','omega','eta','offset']

## in-plane magnetized systems

def PHE_1harm_angular_model(phi, IRp, phi0):
    """
    Expected first harmonic signal for in-plane magnetized samples. From PHE

    Parameters
    ----------
    phi : float
        Azimuthal angle of the magnetization
    IRp : float
        Planar Hall resistance coefficient times current amplitude
    phi0 : float
        Offset angle
    offset : float
        constant offset
    """
    return 0.5*IRp*np.sin(2*deg2rad*(phi-phi0))

def PHE_1harm_angular_guess(phi, X1, **kwargs):
    """
    Function for generating guesses for
    :meth:`~.HallAnalysis.first_harmonic_model`

    Returns
    -------
    list of float
        parameter guesses in the order [IRp, phi0, offset]
    """
    return 2*np.max(np.abs(X1-np.mean(X1))), 1

PHE_1harm_params = [
    fitParameter('IRphe'),
    fitParameter('phi0', (-45,45))
]

PHE_1harm_model = fitModel('PHE', PHE_1harm_angular_model,
                           PHE_1harm_params, PHE_1harm_angular_guess)

def PHE_2harm_angular_func(phi, phi0, C):
    p = (phi-phi0)*np.pi/180
    return C*np.cos(2*p)*np.cos(p)

def PHE2_harm_angular_guess(phi, V, **kwargs):
    return 0.0*np.max(np.abs(V-np.mean(V))), 1

PHE2harm_angular_params = [
    fitParameter('phi0', (-45, 45)),
    fitParameter('Vphe', (-np.inf, np.inf))
]

PHE2harm_model = fitModel('PHE', PHE_2harm_angular_func, PHE2harm_angular_params, PHE2_harm_angular_guess)

def PHE_2harm_angular_ani_func(phi, phi0, C, an_ratio, phiE):
    p = (phi - phi0 - 0.5*an_ratio*rad2deg*np.sin(2*deg2rad*(phi-phi0-phiE)))*deg2rad
    return C*np.cos(2*p)*np.cos(p)

def PHE2_harm_angular_ani_guess(phi, V, **kwargs):
    return np.max(np.abs(V-np.mean(V))), 1, 0.01, 0.

PHE2harm_angular_ani_params = [
    fitParameter('phi0', (-45, 45)),
    fitParameter('Vphe', (-np.inf, np.inf)),
    fitParameter('an_ratio', (-1., 1.)),
    fitParameter('phiE', (-90., 90.))
]

PHE2harm_ani_model = fitModel('PHE', PHE_2harm_angular_ani_func, PHE2harm_angular_ani_params, PHE2_harm_angular_ani_guess)


def AHE_2harm_angular_func(phi, phi0, A):
    p = (phi-phi0)*np.pi/180
    return A*np.cos(p)

def AHE_2harm_angular_guess(phi, V, **kwargs):
    return np.max(np.abs(V-np.mean(V))), 1

AHE2harm_angular_params = [
    fitParameter('phi0', (-90, 90)),
    fitParameter('Vahe', (-np.inf, np.inf))
]

AHE2harm_model = fitModel('AHE', AHE_2harm_angular_func, AHE2harm_angular_params, AHE_2harm_angular_guess)

## out-of-plane magnetized systems

def first_harmonic_PMA_field_func(B_IP, curvature, shift, offset):
    """
    Expected first harmonic field sweep response for a PMA sample. From AHE and
    small tilting of the magnetization. Is of form a(x-b)^2+c
    
    Parameters
    ----------
    curvature : float
        Coefficient of quadratic term of parabola
    shift : float
        Shift from zero of extrema of parabola
    offset : float
        Offset from zero of extrema of parabola
    """
    return curvature*(B_IP-shift)**2 + offset

def first_harmonic_PMA_field_guess(B_IP, X1, fixed_oop_field=0, **kwargs):
    """
    Guess for first harmonic PMA field sweep. Not very good.
    """
    if fixed_oop_field == 0:
        if (X1[0] + X1[1])/2 > X1[X1.size//2]: 
            curv_sign=1
        else: 
            curv_sign = -1
    elif fixed_oop_field > 0: 
        if X1.mean() < 0:
            curv_sign=1
        else:
            curv_sign=-1
    else: 
        if X1.mean() < 0:
            curv_sign=-1
        else:
            curv_sign=1
    
    if curv_sign > 0:
        offset_guess = X1.min()
        crux_position = np.argmin(X1)
        furthest_position = np.argmax(X1)
    else:
        offset_guess = X1.max()
        crux_position = np.argmax(X1)
        furthest_position = np.argmin(X1)

    shift_guess = B_IP[crux_position]
    # fitting has trouble if shift is very close to zero
    if np.isclose(shift_guess, 0, atol=1e-6):
        shift_guess = 1e-4
    curvature_guess = (X1[furthest_position]-X1[crux_position])/(B_IP[furthest_position]-B_IP[crux_position])**2

    return [curvature_guess, shift_guess, offset_guess]

first_harmonic_PMA_field_params = [
    fitParameter('curvature'),
    fitParameter('shift'),
    fitParameter('offset')
    ]

first_harmonic_PMA_field_model = fitModel('2harm', first_harmonic_PMA_field_func, 
                                          first_harmonic_PMA_field_params,
                                          first_harmonic_PMA_field_guess)

class HallAnalysis(baseAnalysis):
    """
    Class to contain all second harmonic Hall related functions, and acts as a
    convenient container for importing and storing datasets etc.

    Parameters
    ----------
    scan_type : str
        Should be 'angle' or 'field', representing what was swept within each
        procedure. Defaults to angle

    Attributes
    ----------
    sweep_ds : xarray.Dataset
        Dataset containing the data
    procedure_swept_cols : list of str
        columns swept in the procedure
    series_swept_params : list of str
        parameters swept in the series
    """

    BFIELD_DIM = 'field_strength'
    ANGLE_DIM = 'field_azimuth'
    TEMP_DIM = 'temperature'
    X2_DATA_VAR = 'X2'
    X1_DATA_VAR = 'X1'

    def __init__(self, scan_type='angle', swept_temp=False, hysteresis=False):
        """
        Instantiates the analysis object with a nonsensical empty dataset.
        Must load data with a separate method.
        Sets swept procedure column and series swept params, depending on
        what scan_type is. Should be angle for angle sweep procedure, or field
        for field sweep procedure.
        """
        super().__init__()
        if swept_temp:
            if scan_type.lower() == 'angle':
                self.procedure_swept_cols = [self.ANGLE_DIM]
                self.series_swept_params = [self.BFIELD_DIM, self.TEMP_DIM]
            elif scan_type.lower() == 'field':
                self.procedure_swept_cols = [self.BFIELD_DIM]
                self.series_swept_params = [self.ANGLE_DIM, self.TEMP_DIM]
            else:
                raise ValueError("scan_type must be 'field' or 'angle'")
        else:
            if scan_type.lower() == 'angle':
                self.procedure_swept_cols = [self.ANGLE_DIM]
                self.series_swept_params = [self.BFIELD_DIM]
            elif scan_type.lower() == 'field':
                self.procedure_swept_cols = [self.BFIELD_DIM]
                self.series_swept_params = [self.ANGLE_DIM]
            else:
                raise ValueError("scan_type must be 'field' or 'angle'")
        
        if hysteresis:
            self.procedure_swept_cols.append('direction')
            self.parser = pymeasure_hysteresis_parser

        self.codename_converter = HallConverter

    def plot_2harm_angle_dependence(self, **kwargs):
        """
        Plots the second harmonic voltage as a function of field angle.
        Is a thin wrapper around :func:`~dataset_manipulation.plot_dataset`.

        Parameters
        ----------
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`

        Returns
        -------
        None
            Just creates the requested plots
        """

        plot_dataset(self.sweep_ds, self.ANGLE_DIM,
                     self.X2_DATA_VAR, **kwargs)

    def plot_2harm_field_dependence(self, **kwargs):
        """
        Plots the second harmonic voltage as a function of field strength. Is a
        thin wrapper around :func:`~dataset_manipulation.plot_dataset`.

        Parameters
        ----------
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`

        Returns
        -------
        None
            Just creates the requested plots
        """

        plot_dataset(self.sweep_ds, self.BFIELD_DIM,
                          self.X2_DATA_VAR, **kwargs)

    def plot_1harm_field_dependence(self, **kwargs):
        """
        Plots the first harmonic voltage as a function of field strength. Is a
        thin wrapper around :func:`~dataset_manipulation.plot_dataset`.

        Parameters
        ----------
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`

        Returns
        -------
        None
            Just creates the requested plots
        """

        plot_dataset(self.sweep_ds, self.BFIELD_DIM,
                          self.X1_DATA_VAR, **kwargs)

    def plot_1harm_angle_dependence(self, **kwargs):
        """
        Plots the first harmonic voltage as a function of field angle. Is a
        thin wrapper around :func:`~dataset_manipulation.plot_dataset`.

        Parameters
        ----------
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`

        Returns
        -------
        None
            Just creates the requested plots
        """

        plot_dataset(self.sweep_ds, self.ANGLE_DIM,
                     self.X1_DATA_VAR, **kwargs)

    def fit_1harm_angular(self, extra_models=[], **kwargs):
        """
        Fits expected signal from PHE to first harmonic for an in-plane magnet
        """

        return fit_dataset_models(
            self.sweep_ds,
            [PHE_1harm_model, const_model.rename_params({'c': 'offset'})]+extra_models,
            self.ANGLE_DIM, self.X1_DATA_VAR, **kwargs
            )

    def fit_2harm_angular(self, extra_models=[], **kwargs):
        """
        Fits expected 2nd harmonic signal for in-plane magnetized systems,
        assuming PHE, AHE and "standard" torques
        """
        
        return fit_dataset_models(
            self.sweep_ds,
            [PHE2harm_model, AHE2harm_model, const_model]+extra_models,
            self.ANGLE_DIM, self.X2_DATA_VAR, **kwargs
        )

    def fit_2harm_angular_ani(self, extra_models=[], **kwargs):
        """
        Fits expected 2nd harmonic signal for in-plane magnetized systems,
        assuming PHE, AHE and "standard" torques
        """
        
        return fit_dataset_models(
            self.sweep_ds,
            [PHE2harm_ani_model, AHE2harm_model, const_model]+extra_models,
            self.ANGLE_DIM, self.X2_DATA_VAR, **kwargs
        )

    def fit_first_harmonic_PMA_field(self, extra_models=[], **kwargs):
        """
        Fits the first harmonic data for a PMA sample to a quadratic model
        parameterized as `y=a(x-b)^2 + c`.
        """
        
        return fit_dataset_models(self.sweep_ds,
                                  [first_harmonic_PMA_field_model]+extra_models,
                                  self.BFIELD_DIM, self.X1_DATA_VAR, **kwargs)
        
    def fit_second_harmonic_PMA_field(self, extra_models=[], **kwargs):
        """
        Fits the second harmonic data for a PMA sample to a linear model
        """

        return fit_dataset_models(self.sweep_ds, [lin_model]+extra_models,
                                  self.BFIELD_DIM, self.X2_DATA_VAR, **kwargs)

    def fit_first_harmonic_simple_tilt(self, **kwargs):
        """
        Fits first harmonic to expected signal if the sample is tilted 
        slightly out of plane and magnetization follows the field perfectly
        """

        return fit_dataset(self.sweep_ds, first_harmonic_simple_tilt_model,
        first_harmonic_simple_tilt_guess, first_harmonic_simple_tilt_param_names, 
        self.ANGLE_DIM, self.X1_DATA_VAR, **kwargs)