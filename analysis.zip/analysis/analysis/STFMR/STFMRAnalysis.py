import numpy as np
import xarray as xr

from ..baseAnalysis import baseAnalysis
from ..baseAnalysis import combine_new_dim
from ..dataset_manipulation import plot_dataset, coordinate_slice
from ..dataset_manipulation import analyzedModelFit, fit_dataset, fit_dataArray_models
from ..converters import STFMRConverter
from ..constants import *

from ..models import fitParameter, fitModel, lin_model, const_model
from .STFMRModels import sym_lor_model, asym_lor_model
from .STFMRModels import FLx_AMR_model, FLy_AMR_model, FLz_AMR_model
from .STFMRModels import ADx_AMR_model, ADy_AMR_model, ADz_AMR_model
from .STFMRModels import B0_model, Delta_model 

class STFMRAnalysis(baseAnalysis):
    """
    Class to contain all STFMR related functions, and acts as a convenient
    container for importing and storing datasets etc.

    Parameters
    ----------
    swept_temp : bool
        Whether temperature was swept in this scan and hence should be a
        dimension of :attr:`.STFMRAnalysis.sweep_ds`

    Attributes
    ----------
    sweep_ds : xarray.Dataset
        Dataset containing the data
    procedure_swept_cols : list of str
        column swept in the procedure
    series_swept_params : list of str
        parameters swept in the series
    """

    # PyMeasure procedure names of parameters, for accessing things from
    # xarray Datasets
    BFIELD_DIM = 'field_strength'
    ANGLE_DIM = 'field_azimuth'
    FREQUENCY_DIM = 'rf_freq'
    TEMPERATURE_DIM = 'temperature'
    BIAS_DIM = 'dc_bias'
    X_DATA_VAR = 'X'

    def __init__(self, swept_temp = False, swept_bias = False):
        """
        Instantiates the analysis object with an empty dataset with the correct
        dimension names. Records the guesses for initial parameters for
        fitting of the resonances.

        Must load data with a separate method.
        """

        super().__init__()
        self.procedure_swept_cols = [self.BFIELD_DIM]
        self.series_swept_params = [self.ANGLE_DIM, self.FREQUENCY_DIM]

        if swept_temp:
            self.series_swept_params.append(self.TEMPERATURE_DIM)
        if swept_bias:
            self.series_swept_params.append(self.BIAS_DIM)

        self.codename_converter = STFMRConverter

    def separate_field_data(self, phi_offset=0., reverse=False, sort=False):
        """
        Separates the positive and negative field data and assigns the negative
        field data to an angle 180 deg from the corresponding positive field
        data. Shifts the angle coordinates as well if requested.

        Parameters
        ----------
        phi_offset : float
            Angle to offset the angles by. If ``reverse`` is ``True``, we do
            ``phi_offset - phi``, otherwise ``phi - phi_offset``
        reverse : bool
            Whether to reverse the angular coordinates as well, i.e. go from
            increasing phi meaning clockwise to counter-clockwise

        Returns
        -------
        None
            Modifies :attr:`~.STFMRAnalysis.sweep_ds` in-place

        Raises
        ------
        ValueError
            If there is no negative field data. This could either mean none was
            taken or that this method has already been used.
        """
        pfield = self.sweep_ds.where(self.sweep_ds[self.BFIELD_DIM]>0, drop=True)
        nfield = self.sweep_ds.where(self.sweep_ds[self.BFIELD_DIM]<0, drop=True)

        if nfield[self.X_DATA_VAR].size == 0:
            raise ValueError('''No negative field data! This method was probably
                             already ran''')

        # Ensuring that the positive and negative fields have the same length,
        # dropping low-field data if they do not.
        plen = pfield.coords[self.BFIELD_DIM].values.size
        nlen = nfield.coords[self.BFIELD_DIM].values.size
        final_len = min(plen, nlen)
        # slicing is different since pfield is 0...max_field and nfield is
        # -max_field...0
        pfield = pfield.where(pfield[self.BFIELD_DIM] == pfield[self.BFIELD_DIM][-final_len:])
        nfield = nfield.where(nfield[self.BFIELD_DIM] == nfield[self.BFIELD_DIM][:final_len])

        # Assume positive and negative field points are (nominally) the same.
        # This is not actually true since e.g. +-.05 mA current to magnet does
        # *not* give the same magnitude of field, but it is pretty close.
        nfield.coords[self.BFIELD_DIM] = pfield.coords[self.BFIELD_DIM].values[::-1]
        nfield.coords[self.ANGLE_DIM] = 180 + nfield.coords[self.ANGLE_DIM].values
        # QUESTION: is this how we want to handle offsets?
        nfield.coords[self.ANGLE_DIM] -= phi_offset
        pfield.coords[self.ANGLE_DIM] -= phi_offset
        if reverse:
            nfield.coords[self.ANGLE_DIM] *= -1
            pfield.coords[self.ANGLE_DIM] *= -1

        # ensure all angles are in [0,360]
        nfield.coords[self.ANGLE_DIM].values = [x+360 if x<0 else x for x in nfield.coords[self.ANGLE_DIM].values]
        pfield.coords[self.ANGLE_DIM].values = [x+360 if x<0 else x for x in pfield.coords[self.ANGLE_DIM].values]

        if sort:
            self.sweep_ds = xr.concat([pfield,nfield], dim='field_azimuth').sortby('field_azimuth')
        else:
            self.sweep_ds = xr.concat([pfield,nfield], dim='field_azimuth')
        self.coords = self.sweep_ds.coords
        self.dims = self.sweep_ds.dims
        self.data_vars = self.sweep_ds.data_vars

    def shift_angles(self, phi_offset, reverse):
        """
        Shifts the angle coordinates of the data according to the function
        `phi <- phi - phi0` if reverse is False, otherwise `phi <- phi_0 - phi`

        Parameters
        ----------
        phi_offset : float
            Amount to offset the angle coordinate by
        reverse : bool
            Whether to reverse the meaning of increasing phi, exchanges CW
            rotation for CCW rotation and vice-versa.

        Returns
        -------
        None
            Makes the changes to sweep_ds in-place
        """

        # subtract offset
        self.sweep_ds.coords[self.ANGLE_DIM] -= phi_offset

        # change polarity if requested
        if reverse:
            self.sweep_ds.coords[self.ANGLE_DIM] *= -1

        # ensure all angles are between 0 and 360
        self.sweep_ds.coords[self.ANGLE_DIM].values = [x+360 if x<0 else x for x in self.sweep_ds.coords[self.ANGLE_DIM].values]

    def field_slice(self, llim=-np.inf, ulim=np.inf):
        """
        Returns a field slice
        """
        return coordinate_slice(self.sweep_ds, self.BFIELD_DIM, llim, ulim)

    def plot_resonances(self, **kwargs):
        """
        Plots just the resonances.

        Parameters
        ----------
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`
        """

        plot_dataset(self.sweep_ds, self.BFIELD_DIM, self.X_DATA_VAR, **kwargs)

    def fit_resonances(self, Meff_guess, alpha_guess, S45_guess, A45_guess, additional_models=[], **kwargs):
        """
        Fits resonances after
        :meth:`~.STFMRAnalysis.separate_field_data`
        is ran.

        This uses ``curve_fit`` and is a thin wrapper around
        :func:`~dataset_manipulation.fit_dataset`.fit_dataArray_models

        Parameters
        ----------
        Meff_guess : float
            guess of Meff
        alpha_guess : float
            guess of magnet damping
        S45_guess : float
            Guess of symmetric amplitude of the lorentzian with ang(B, I)=45
        A45_guess : float
            Guess of antisymmetric amplitude of the lorentzian with ang(B, I)=45
        additional_models : list of fitModels
            any additional models to be added to the symmetric+antisymmetric+constant
            models assumed by default
        **kwargs
            can be:
            - names of ``dims`` of ``ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data withconstants coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        resonanceFit
            Object containing the results of the fitting and convenience
            functions for dealing with the fit parameters
        """
        guess_help_params = {
            "Meff_guess": Meff_guess,
            "alpha_guess": alpha_guess,
            "S_guess": S45_guess,
            "A_guess": A45_guess
        }

        afit = fit_dataArray_models(
            self.sweep_ds[self.X_DATA_VAR],
            [sym_lor_model, asym_lor_model, const_model]+additional_models,
            self.BFIELD_DIM,
            guess_func_help_params=guess_help_params,
            **kwargs
            )

        return resonanceFit.from_analyzedModelFit(afit)

class resonanceFit(analyzedModelFit):
    """
    Class to contain methods related to STFMR resonance fit parameters. Wrapper
    around :class:`~baseAnalysis.analyzedFit`
    """

    ANGLE_DIM = 'field_azimuth'
    FREQUENCY_DIM = 'rf_freq'
    TEMPERATURE_DIM = 'temperature'
    BIAS_DIM = 'dc_bias'

    @staticmethod
    def from_analyzedModelFit(afit):
        """
        Returns an instance of this class starting from an analyzedFit instance

        Parameters
        ----------
        afit : analysis.baseAnalysis.analyzedFit instance
        """
        return resonanceFit(afit.models, afit.fit_ds, afit.main_da, afit.main_xda,
                            afit.fit_func, afit.guess_func, afit.param_names,
                            afit.xname, afit.yname, afit.yerr_da)

    def plot_resonance_fits(self, additional_backgrounds=[], **kwargs):
        """
        Plots the symmetric and antisymmetric resonance components with the 
        constant model (along with any additional ones) as a background
        """
        
        self.plot_model_fits(['symmetric','antisymmetric'],
                             background_models=['constant']+additional_backgrounds,
                             **kwargs)

    def find_Meff(self, **kwargs):
        """
        Fits the resonat field as a function of frequency to find the effective
        magnetization assuming Kittel's formula holds.

        Parameters
        ----------
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the effective
            magnetization as a function of any other dimensions.
        """

        return self.fit_params_model([B0_model], self.FREQUENCY_DIM, 'B0', **kwargs)

    def find_damping(self, **kwargs):
        """
        Fits the linewidth as a function of frequency to find the gilbert
        Damping parameter.

        Parameters
        ----------
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the damping
            as a function of any other dimensions.
        """

        return self.fit_params_model([Delta_model], self.FREQUENCY_DIM, 'Delta', **kwargs)

    def calculate_SHE(self, Ms, Meff, tmag, tnm):
        """
        Calculates the spin Hall efficiency assuming we only have
        "standard" torques in our system, i.e. a field-like torque from an
        Oersted field and a y AD torque.

        Parameters
        ----------
        Ms : float
            Saturation magnetization of the magnetic layer.
        Meff : xarray.Dataset
            Dataset of the effective magnetization which has coordinates
            commensurate with that of ``fit_ds``. Can use the ``fit_ds``
            attribute of the output of find_Meff.
        tmag : float
            thickness of the magnetic layer, in m
        tnm : float
            thickness of the normal metal, in m

        Returns
        -------
        xarray.DataArray
            A DataArray with the same dimensions and coordinates as ``fit_ds``
            containing the calculated SHE.
        """
        SHE = self.fit_ds['S']/self.fit_ds['A']*echarge*Ms \
               *tmag*tnm/hbar*np.sqrt(1 + Meff/self.fit_ds['B0'])
        return SHE.rename('SHE')

    def fit_bias_linewidth_change(self, **kwargs):
        """
        Fits the linewidth change as a function of DC bias.

        Parameters
        ----------
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains
            d(Delta)/d(I_DC) as a function of any other dimensions.
        """
        
        return biasLinewidthFit.from_analyzedModelFit(
            self.fit_params_model([lin_model.rename_params({'m': 'dDdI', 'b': 'Delta0'})], self.BIAS_DIM,
            "Delta", **kwargs)
            )

    def fit_standard_SA(self, **kwargs):
        """
        Fits the symmetric or antisymmetric resonance amplitudes to the
        "standard" angular dependence for mxmxy or mxy torques.

        returns
        -------
        analyzedFit
        """

        Sfit = self.fit_params_model([ADy_AMR_model], self.ANGLE_DIM, 'S', **kwargs)

        Afit = self.fit_params_model([FLy_AMR_model], self.ANGLE_DIM, 'A', **kwargs)

        return SAAngFit(Sfit, Afit)

    def fit_full_SA(self, **kwargs):
        """
        Fits the symmetric or antisymmetric resonance amplitudes to the
        full angular dependence including all possible torques

        returns
        -------
        tuple of analyzedModelFit
            First is the result of fitting S and the second of A
        """

        Sfit = self.fit_params_model([ADx_AMR_model, ADy_AMR_model, FLz_AMR_model],
                                     self.ANGLE_DIM, 'S')
        
        Afit = self.fit_params_model([FLx_AMR_model, FLy_AMR_model, ADz_AMR_model],
                                     self.ANGLE_DIM, 'A')

        return Sfit, Afit

class SAAngFit:
    """
    Container for the fit results of the angular dependence of symmetric and
    asymmetric amplitudes from longitudinal STFMR measurements.
    """

    def __init__(self, S, A):
        """
        Parameters
        ----------
        S : analysis.baseAnalysis.analyzedFit
            Symmetric amplitude fit object
        A : analysis.baseAnalysis.analyzedFit
            Antisymmetric amplitude fit object
        """

        self.S = S
        self.A = A

        # put together all fit parameters for easy access
        self.fit_ds = xr.merge(
            (
                S.fit_ds.rename({'phi0': 'phi0_S', 'phi0_err': 'phi0_S_err'}),
                A.fit_ds.rename({'phi0': 'phi0_A', 'phi0_err': 'phi0_A_err'})
            )
        )

    def plot_params(self, xname, yname, yerr_name = None, **kwargs):
        """
        Plots the fit parameters and their errors vs some dimension. Thin
        wrapper around :func:`~.plot_dataset`.

        Parameters
        ----------
        xname : str
            name of some ``dim`` of
            :attr:`~.SAAngFit.fit_ds`
        yname : str
            name of some ``data_var`` of
            :attr:`~.SAAngFit.fit_ds`
        yerr_name : str
            name of some ``data_var`` of
            :attr:`~.SAAngFit.fit_ds` representing
            error in yname.
            If none, defaults to ``(yname)_err'``
        **kwargs
            passed along to :func:``~.plot_dataset``

        Returns
        -------
        None
            Just plots the requested parameters.
        """

        # set yerr_name to default if none given
        if yerr_name is None:
            yerr_name = yname + '_err'

        plot_dataset(self.fit_ds, xname, yname, yerr_name=yerr_name, **kwargs)

    def plot_fits(self, res_part, **kwargs):
        """
        Makes plotting the fit results easier

        Parameters
        ----------
        res_part : 'S' or 'A'
            Whether to fit the symmetric or antisymmetric parts of the resonance
        kwargs
            Passed along to the plotting function
        """

        if res_part == 'S':
            self.S.plot_fits(**kwargs)
        elif res_part == 'A':
            self.A.plot_fits(**kwargs)

    def calculate_SHE(self, B0, Ms, Meff, tfm, tnm):
        """
        Calculates the spin Hall efficiency

        Parameters
        ----------
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetizatin in T
        Meff : float
            Effective magnetization in T
        tfm : float
            Ferromagnet thickness in m
        tnm : float
            Normal metal thickness in m
            
        Returns
        -------
            Returns the calculated SHE and it's error, only taking the error in S/A
        """
        
        S = self.fit_ds['ADy']
        A = self.fit_ds['FLy']
        S_err = self.fit_ds['ADy_err']
        A_err = self.fit_ds['FLy_err']
        
        conversion = np.sqrt(1+Meff/B0)*echarge*Ms*tfm*tnm/hbar
        
        SA_err = np.sqrt((S_err/A)**2 + (S*A_err/A**2)**2)

        return S/A*conversion, SA_err*conversion

class biasLinewidthFit(analyzedModelFit):
    """
    Class for analyzing DC bias linewidth changes. Wrapper
    around :class:`~baseAnalysis.analyzedFit`
    """

    LW_CHANGE_VAR = 'dDdI'
    INTERCEPT_VAR = 'Delta0'
    ANGLE_DIM = 'field_azimuth'
    FREQUENCY_DIM = 'rf_freq'
    TEMPERATURE_DIM = 'temperature'

    @staticmethod
    def from_analyzedModelFit(afit):
        """
        Returns an instance of this class starting from an analyzedFit instance

        Parameters
        ----------
        afit : analysis.baseAnalysis.analyzedFit instance
        """
        return biasLinewidthFit(afit.models, afit.fit_ds, afit.main_da, afit.main_xda,
                            afit.fit_func, afit.guess_func, afit.param_names,
                            afit.xname, afit.yname, afit.yerr_da)

    def fit_sin_dep(self, **kwargs):
        """
        Fits the linewidth/current slope to a sinusoid
        """
        def sinfunc(p, A, phi0):
            phi = (p-phi0)*deg2rad
            return A*np.sin(phi)
        def sinfunc_guess(p, dDdI, **fit_kwargs):
            Aguess = np.mean(np.abs(dDdI))
            return [Aguess, 0]
        
        sinfunc_ps = [
            fitParameter('A', (-np.inf, np.inf)),
            fitParameter('phi0', (-90, 90))
        ]
        
        sinfunc_model = fitModel('sin', sinfunc, sinfunc_ps, sinfunc_guess)

        return self.fit_params_model(sinfunc_model,
                               self.ANGLE_DIM, self.LW_CHANGE_VAR,
                               **kwargs)

    def calculate_bias_SHE(self, Meff, B0, Ms, tmag, Anm, x):
        """
        Calculates spin Hall effect from linewidth broadening as a function of
        DC bias current
        From Luqiao's 2011 STFMR paper and adapted a bit
        any parameters can be DataArrays and this should still work.

        Parameters
        ----------
        Meff : float
            Effective magnetization in T
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetization in T
        tmag : float
            thickness of the magnetic layer in m
        Anm : float
            cross-sectional area of active layer in m^2
        x : float
            fraction of current flowing through the active layers

        Returns
        -------
        float
            The efficiency of the in-plane polarized torques
        """

        w = 2*np.pi*self.fit_ds[self.FREQUENCY_DIM]
        
        
        aa = gamma/w
        bb = 2*echarge/hbar
        cc = Ms*(B0/mu0 + Meff/2/mu0)
        dd = tmag*Anm/x

        return self.fit_ds[self.LW_CHANGE_VAR]*aa*bb*cc*dd
