import os
from itertools import product
from inspect import getfullargspec

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.optimize import curve_fit
import xarray as xr
import pandas as pd

from ..baseAnalysis import baseAnalysis, parse_series_file, load_procedure_files
from ..baseAnalysis import combine_new_dim
from ..dataset_manipulation import fit_dataset, plot_dataset
from ..dataset_manipulation import analyzedFit, fit_dataArray_models, fit_dataset_models
from ..converters import STFMRConverter
from ..constants import *
from ..models import const_model, lin_model

from .STFMRModels import sym_lor_model, asym_lor_model
from .STFMRModels import sym_lor2_model, asym_lor2_model
from .STFMRModels import FLx_AMR_model, FLy_AMR_model, FLz_AMR_model
from .STFMRModels import ADx_AMR_model, ADy_AMR_model, ADz_AMR_model
from .STFMRModels import B0_model, Delta_model

from .STFMRAnalysis import STFMRAnalysis, resonanceFit, SAAngFit, biasLinewidthFit

class STFMRAnalysis2Res(STFMRAnalysis):
    """
    Class to contain all STFMR related functions on data with two resonances,
    and acts as a convenient container for importing and storing datasets etc.

    Parameters
    ----------
    swept_temp : bool
        Whether temperature was swept in this scan and hence should be a
        dimension of :attr:`.STFMRAnalysis.sweep_ds`

    Attributes
    ----------
    sweep_ds : xarray.Dataset
        Dataset containing the data
    procedure_swept_cols : list of str
        columns swept in the procedure
    series_swept_params : list of str
        parameters swept in the series
    """

    def fit_resonances(self, Meff2_guess, Meff1_guess, alpha_guess, A_guess, A2_guess=None, additional_models=[], **kwargs):
        """
        Fits resonances after
        :meth:`~.STFMRAnalysis.separate_field_data`
        is ran.

        This uses ``curve_fit`` and is a thin wrapper around
        :func:`~dataset_manipulation.fit_dataset`.

        Parameters
        ----------
        Meff2_guess : float
            Guess of Meff of second resonance (higher Meff)
        Meff1_guess : float
            guess of Meff of first resonance (lower Meff)
        alpha_guess : float
            guess of magnet damping
        A_guess : float
            Guess of lorentzian amplitude
        additional_models : list of fitModel
            Other models to include in the fit
        **kwargs
            can be:
            - names of ``dims`` of ``ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data withconstants coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        resonanceFit
            Object containing the results of the fitting and convenience
            functions for dealing with the fit parameters
        """
        if A2_guess is None:
            A2_guess = A_guess

        # save fit guesses
        guess_help_params = {
            "Meff_guess": Meff1_guess,
            "alpha_guess": alpha_guess,
            "A_guess": A_guess,
            "A2_guess": A2_guess,
            "Meff2_guess": Meff2_guess
        }
        
        afit = fit_dataset_models(
            self.sweep_ds,
            [
                sym_lor_model.rename_params({'B0': 'B01', 'Delta': 'Delta1', 'S': 'S1'}),
                asym_lor_model.rename_params({'B0': 'B01', 'Delta': 'Delta1', 'A': 'A1'}),
                sym_lor2_model,
                asym_lor2_model,
                const_model
            ]+additional_models,
            self.BFIELD_DIM,
            self.X_DATA_VAR,
            guess_func_help_params = guess_help_params,
            **kwargs
            )

        # Calculate actual second resonance field
        afit.fit_ds = afit.fit_ds.assign(B02 = lambda x: x.B01 + x.dB0)
        afit.fit_ds = afit.fit_ds.assign(B02_err = lambda x: np.sqrt(x.B01_err**2 + x.dB0_err**2))

        return resonanceFit2Res.from_analyzedModelFit(afit)

class resonanceFit2Res(resonanceFit):
    """
    Class to contain methods related to STFMR resonance fit parameters for data
    with two resonances. Extends `~.resonanceFit`
    """

    @staticmethod
    def from_analyzedModelFit(afit):
        """
        Returns an instance of this class starting from an analyzedFit instance

        Parameters
        ----------
        afit : analysis.baseAnalysis.analyzedFit instance
        """
        return resonanceFit2Res(afit.models, afit.fit_ds, afit.main_da, afit.main_xda,
                            afit.fit_func, afit.guess_func, afit.param_names,
                            afit.xname, afit.yname, afit.yerr_da)

    def plot_resonance_fits(self, additional_backgrounds=[], **kwargs):
        """
        Plots the symmetric and antisymmetric resonance components with the 
        constant model (along with any additional ones) as a background
        """
        self.plot_model_fits(
            ['symmetric','antisymmetric','symmetric2','antisymmetric2'],
            background_models=['constant']+additional_backgrounds,
            **kwargs
            )

    def find_damping(self, res, **kwargs):
        """
        Fits the linewidth as a function of frequency to find the gilbert
        Damping parameter.

        Parameters
        ----------
        res : 1 or 2
            which resonance to find Meff of
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the effective
            magnetization as a function of any other dimensions.
        """

        return self.fit_params_model([Delta_model], self.FREQUENCY_DIM, 'Delta'+str(res), **kwargs)

    def find_Meff(self, res, **kwargs):
        """
        Fits the resonat field as a function of frequency to find the effective
        magnetization assuming Kittel's formula holds.

        Parameters
        ----------
        res : 1 or 2
            which resonance to find Meff of
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the effective
            magnetization as a function of any other dimensions.
        """

        return self.fit_params_model([B0_model], self.FREQUENCY_DIM, 'B0'+str(res), **kwargs)

    def fit_bias_linewidth_change(self, res, **kwargs):
        """
        Fits the linewidth change as a function of DC bias.

        Parameters
        ----------
        res : 1 or 2
            Resonance linewith change to fit to
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains
            d(Delta)/d(I_DC) as a function of any other dimensions.
        """
        
        return biasLinewidthFit.from_analyzedModelFit(
            self.fit_params_model([lin_model.rename_params({'m': 'dDdI', 'b': 'Delta0'})], self.BIAS_DIM,
            "Delta"+str(res), **kwargs)
            )

    def fit_standard_SA_partial(self, res, **kwargs):
        """
        Parameters
        ----------
        res : str
            which resonances ``(S1, A1, S2, A2)`` to fit
        """
        
        if res.startswith("S"):
            return self.fit_params_model([ADy_AMR_model.rename_params({"ADy": "ADy"+res[1]})], self.ANGLE_DIM, res, **kwargs)
        elif res.startswith("A"):
            return self.fit_params_model([FLy_AMR_model.rename_params({"FLy": "FLy"+res[1]})], self.ANGLE_DIM, res, **kwargs)
        else:
            raise ValueError("Incorrect resonance component chosen")
        
    def fit_standard_SA(self, **kwargs):
        """
        Fits all of the resonance components to the standard SA angular dependence
        """
        
        return SAAngFit2Res(
            self.fit_standard_SA_partial('S1', **kwargs),
            self.fit_standard_SA_partial('A1', **kwargs),
            self.fit_standard_SA_partial('S2', **kwargs),
            self.fit_standard_SA_partial('A2', **kwargs)
        )

    def fit_full_SA(self, **kwargs):
        """
        Fits the symmetric or antisymmetric resonance amplitudes to the
        full angular dependence including all possible torques

        returns
        -------
        tuple of analyzedModelFit
            The result of fitting S1, A1, S2, A2 in that order
        """

        S1fit = self.fit_params_model([ADx_AMR_model, ADy_AMR_model, FLz_AMR_model],
                                     self.ANGLE_DIM, 'S1')
        
        S2fit = self.fit_params_model([ADx_AMR_model, ADy_AMR_model, FLz_AMR_model],
                                     self.ANGLE_DIM, 'S2')
        
        A1fit = self.fit_params_model([FLx_AMR_model, FLy_AMR_model, ADz_AMR_model],
                                     self.ANGLE_DIM, 'A1')
        
        A2fit = self.fit_params_model([FLx_AMR_model, FLy_AMR_model, ADz_AMR_model],
                                     self.ANGLE_DIM, 'A2')

        return S1fit, A1fit, S2fit, A2fit

class SAAngFit2Res(SAAngFit):
    
    def __init__(self, S1, A1, S2, A2):
        """
        Parameters
        ----------
        S1 : analysis.baseAnalysis.analyzedFit
            Symmetric amplitude of resonance 1 fit object
        A1 : analysis.baseAnalysis.analyzedFit
            Antisymmetric amplitude of resonance 1 fit object
        S2 : analysis.baseAnalysis.analyzedFit
            Symmetric amplitude of resonance 2 fit object
        A2 : analysis.baseAnalysis.analyzedFit
            Antisymmetric amplitude of resonance 2 fit object
        """
        
        self.S1 = S1
        self.A1 = A1
        self.S2 = S2
        self.A2 = A2
        
        # ensure all fit parameters have unique names
        conflicting_dv = []
        for dv in S1.fit_ds.data_vars:
            if dv in S2.fit_ds.data_vars:
                conflicting_dv.append(dv)
        
        S1d, S2d = {}, {}
        for dv in conflicting_dv:
            if not dv.endswith("_err"):
                S1d[dv] = dv + "_S1"
                S1d[dv+'_err'] = dv+"_S1_err"
                
                S2d[dv] = dv + "_S2"
                S2d[dv+'_err'] = dv+"_S2_err"
                
        conflicting_dv = []
        for dv in A1.fit_ds.data_vars:
            if dv in A2.fit_ds.data_vars:
                conflicting_dv.append(dv)
        
        A1d, A2d = {}, {}
        for dv in conflicting_dv:
            if not dv.endswith("_err"):
                A1d[dv] = dv + "_A1"
                A1d[dv+'_err'] = dv+"_A1_err"
                
                A2d[dv] = dv + "_A2"
                A2d[dv+'_err'] = dv+"_A2_err"

        # put together all fit parameters for easy access
        self.fit_ds = xr.merge(
            (
                S1.fit_ds.rename(S1d),
                S2.fit_ds.rename(S2d),
                A1.fit_ds.rename(A1d),
                A2.fit_ds.rename(A2d)
            )
        )
    
    def plot_fits(self, res_part, **kwargs):
        """
        Plots the fits
        """
        
        if res_part == 'S1':
            self.S1.plot_fits(**kwargs)
        elif res_part == 'S2':
            self.S2.plot_fits(**kwargs)
        elif res_part == 'A1':
            self.A1.plot_fits(**kwargs)
        elif res_part == 'A2':
            self.A2.plot_fits(**kwargs)
        else:
            raise ValueError("res_part must be A1, A2, S1 or S2")
    
    def calculate_SHE(self, res, B0, Ms, Meff, tfm, tnm):
        """
        Calculates the spin Hall efficiency

        Parameters
        ----------
        res : float
            which resonance (1 or 2) to do
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetizatin in T
        Meff : float
            Effective magnetization in T
        tfm : float
            Ferromagnet thickness in m
        tnm : float
            Normal metal thickness in m
        """

        S = self.fit_ds[f'ADy{res}']
        A = self.fit_ds[f'FLy{res}']
        S_err = self.fit_ds[f'ADy{res}_err']
        A_err = self.fit_ds[f'FLy{res}_err']

        
        conversion = np.sqrt(1+Meff/B0)*echarge*Ms*tfm*tnm/hbar
        
        SA_err = np.sqrt((S_err/A)**2 + (S*A_err/A**2)**2)

        return S/A*conversion, SA_err*conversion

# TODO: add DC bias stfmr class?