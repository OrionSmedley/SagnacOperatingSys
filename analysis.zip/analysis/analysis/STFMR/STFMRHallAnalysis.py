import os
from itertools import product
from inspect import getfullargspec

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from scipy.optimize import curve_fit
import xarray as xr
import pandas as pd

from ..baseAnalysis import baseAnalysis, parse_series_file, load_procedure_files
from ..baseAnalysis import combine_new_dim
from ..dataset_manipulation import fit_dataset, plot_dataset
from ..dataset_manipulation import analyzedFit, fit_dataArray_models, fit_dataset_models
from ..converters import STFMRConverter
from ..constants import *
from ..models import const_model

from .STFMRModels import sym_lor_model, asym_lor_model, ADy_AMR_model, FLy_AMR_model
from .STFMRModels import S_PHE_model, A_PHE_model, S_AMR_model, A_AMR_model, S_AHE_model, A_AHE_model

from .STFMRAnalysis import STFMRAnalysis, resonanceFit

class HallSTFMRAnalysis(STFMRAnalysis):

    Xt_DATA_VAR = 'Xt'

    # NOTE: can play games with fitting to fit longitudinal and transverse
    # parts simultaneously if we use leastsq instead of curve_fit. This would
    # guarantee that B0, Delta are the same between the two, but idk if it is
    # worth the trouble...
    def fit_resonances(self, Meff_guess, alpha_guess, S45_guess,
                                A45_guess, additional_models=[], **kwargs):
        """
        Fits resonances after
        :meth:`~.STFMRAnalysis.separate_field_data`
        is ran.

        This uses ``curve_fit`` and is a thin wrapper around
        :func:`~dataset_manipulation.fit_dataset`.

        Parameters
        ----------
        Meff_guess : float
            guess of Meff
        alpha_guess : float
            guess of magnet damping
        S45_guess : float
            Guess of symmetric amplitude of the lorentzian with ang(B, I)=45
        A45_guess : float
            Guess of antisymmetric amplitude of the lorentzian with ang(B, I)=45
        **kwargs
            can be:
            - names of ``dims`` of ``ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data withconstants coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        resonanceFit
            Object containing the results of the fitting and convenience
            functions for dealing with the fit parameters
        """

        guess_help_params = {
            "Meff_guess": Meff_guess,
            "alpha_guess": alpha_guess,
            "S_guess": S45_guess,
            "A_guess": A45_guess
        }

        lfit = fit_dataset_models(
            self.sweep_ds,
            [
                sym_lor_model.rename_params({'B0': 'B0l', 'Delta': 'Deltal', 'S': 'Sl'}),
                asym_lor_model.rename_params({'B0': 'B0l', 'Delta': 'Deltal', 'A': 'Al'}),
                const_model.rename_params({'c': 'cl'})
            ]+additional_models,
            self.BFIELD_DIM,
            self.X_DATA_VAR,
            guess_func_help_params=guess_help_params,
            **kwargs
            )

        tfit = fit_dataset_models(
            self.sweep_ds,
            [
                sym_lor_model.rename_params({'B0': 'B0t', 'Delta': 'Deltat', 'S': 'St'}),
                asym_lor_model.rename_params({'B0': 'B0t', 'Delta': 'Deltat', 'A': 'At'}),
                const_model.rename_params({'c': 'ct'})
            ]+additional_models,
            self.BFIELD_DIM,
            self.Xt_DATA_VAR,
            guess_func_help_params=guess_help_params,
            **kwargs
            )

        return HallResonanceFit(resonanceFit.from_analyzedModelFit(lfit),
                                resonanceFit.from_analyzedModelFit(tfit))

    def plot_resonances(self, lt, **kwargs):
        """
        Plots just the longitudinal resonances.

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        **kwargs
            Passed along directly to :func:`~dataset_manipulation.plot_dataset`
        """

        if lt.lower() == 'l':
            plot_dataset(self.sweep_ds, self.BFIELD_DIM, self.X_DATA_VAR, **kwargs)
        elif lt.lower() == 't':
            plot_dataset(self.sweep_ds, self.BFIELD_DIM, self.Xt_DATA_VAR, **kwargs)
        else:
            raise ValueError("Need to specify l or t")

class HallResonanceFit:
    """
    Container for the results of fitting the longitudinal and transverse STFMR
    resonances, and associated useful functions.
    """
    
    ANGLE_DIM = 'field_azimuth'

    def __init__(self, lfit, tfit):
        """
        Initialization method

        Parameters
        ----------
        lfit : .resonanceFit
            Longitudinal resonance fit object
        tfit : .resonanceFit
            Transverse resonance fit object
        """

        self.lfit = lfit
        self.tfit = tfit

        self.fit_ds = xr.merge((self.lfit.fit_ds, self.tfit.fit_ds), compat = 'override')

    def find_Meff(self, lt, **kwargs):
        """
        Fits the resonat field as a function of frequency to find the effective
        magnetization assuming Kittel's formula holds.

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the effective
            magnetization as a function of any other dimensions.
        """

        if lt.lower() == 'l':
            return self.lfit.find_Meff(**kwargs)
        elif lt.lower() == 't':
            return self.tfit.find_Meff(**kwargs)
        else:
            raise ValueError("Need to specify l or t")

    def find_damping(self, lt, **kwargs):
        """
        Fits the linewidth as a function of frequency to find the gilbert
        Damping parameter.

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        **kwargs
            can be:
            - names of ``dims`` of ``fit_ds``
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            An object showing the result of the fitting. Contains the damping
            as a function of any other dimensions.
        """

        if lt.lower() == 'l':
            return self.lfit.find_damping(**kwargs)
        elif lt.lower() == 't':
            return self.tfit.find_damping(**kwargs)
        else:
            raise ValueError("Need to specify l or t")

    def plot_params(self, xname, yname, yerr_name = None, **kwargs):
        """
        Plots the fit parameters and their errors vs some dimension. Thin
        wrapper around :func:`~.plot_dataset`.

        Parameters
        ----------
        xname : str
            name of some ``dim`` of
            :attr:`~.HallSAAngFit.fit_ds`
        yname : str
            name of some ``data_var`` of
            :attr:`~.HallSAAngFit.fit_ds`
        yerr_name : str
            name of some ``data_var`` of
            :attr:`~.HallSAAngFit.fit_ds` representing
            error in yname.
            If none, defaults to ``(yname)_err'``
        **kwargs
            passed along to :func:``~.plot_dataset``

        Returns
        -------
        None
            Just plots the requested parameters.
        """

        # set yerr_name to default if none given
        if yerr_name is None:
            yerr_name = yname + '_err'

        plot_dataset(self.fit_ds, xname, yname, yerr_name=yerr_name, **kwargs)

    def plot_fits(self, lt, **kwargs):
        """
        Makes plotting the fit results easier

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        kwargs
            Passed along to the plotting function
        """

        if lt.lower() == 'l':
            self.lfit.plot_fits(**kwargs)
        elif lt.lower() == 't':
            self.tfit.plot_fits(**kwargs)
    
    def plot_resonance_fits(self, lt, additional_backgrounds=[], **kwargs):
        """
        Plots the symmetric and antisymmetric resonance components with the 
        constant model (along with any additional ones) as a background
        """
        
        if lt.lower() == 'l':
            self.lfit.plot_model_fits(['symmetric','antisymmetric'],
                                background_models=['constant']+additional_backgrounds,
                                **kwargs)
        elif lt.lower() == 't':
            self.tfit.plot_model_fits(['symmetric','antisymmetric'],
                                background_models=['constant']+additional_backgrounds,
                                **kwargs)

    def fit_standard_SA_partial(self, lt, res_part, additional_models=[], **kwargs):
        """
        Fits the symmetric or antisymmetric resonance amplitudes to the
        "standard" angular dependence for mxmxy or mxy torques.

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        res_part : 'S' or 'A'
            Whether to fit the symmetric or antisymmetric parts of the resonance
        kwargs
            Keyword arguments passed along to the fitting function

        returns
        -------
        analyzedFit
        """

        if lt.lower() == 'l':
            if res_part == 'S':
                return self.lfit.fit_params_model(
                    [S_AMR_model]+additional_models,
                    self.ANGLE_DIM,
                    'Sl',
                    **kwargs
                    )
            elif res_part == 'A':
                return self.lfit.fit_params_model(
                    [A_AMR_model]+additional_models,
                    self.ANGLE_DIM,
                    'Al',
                    **kwargs
                    )
            else:
                raise ValueError("Must choose S or A resonance")
        elif lt.lower() == 't':
            if res_part == 'S':
                return self.tfit.fit_params_model(
                    [S_PHE_model, S_AHE_model]+additional_models,
                    self.ANGLE_DIM,
                    'St',
                    **kwargs
                    )
            elif res_part == 'A':
                return self.tfit.fit_params_model(
                    [A_PHE_model, A_AHE_model]+additional_models,
                    self.ANGLE_DIM,
                    'At',
                    **kwargs
                    )
            else:
                raise ValueError("Must choose S or A resonance")
        else:
            raise ValueError("Need to specify l or t")

    def fit_standard_SA(self, **kwargs):
        """
        Fits the symmetric and antisymmetric parts of longitudinal and
        transverse resonances and packages them in a useful object

        Parameters
        ----------
        kwargs
            Keyword arguments passed to the fitting function
        """

        Al = self.fit_standard_SA_partial('l', 'A', **kwargs)
        Sl = self.fit_standard_SA_partial('l', 'S', **kwargs)

        At = self.fit_standard_SA_partial('t', 'A', **kwargs)
        St = self.fit_standard_SA_partial('t', 'S', **kwargs)

        return HallSAAngFit(Sl, Al, St, At)

    # TODO: anisotropy fitting function for the different resonant fields

class HallSAAngFit:
    """
    Container for the fit results of the angular dependence of symmetric and
    asymmetric amplitudes from longitudinal and transverse STFMR measurements.
    """

    Sahe = 'Sahe'
    Sahe_err = Sahe+'_err'
    Aahe = 'Aahe'
    Aahe_err = Aahe+'_err'

    Sphe = 'Sphe'
    Sphe_err = Sphe+'_err'
    Aphe = 'Aphe'
    Aphe_err = Aphe+'_err'

    Samr = 'Samr'
    Samr_err = Samr+'_err'
    Aamr = 'Aamr'
    Aamr_err = Aamr+'_err'

    def __init__(self, Sl, Al, St, At):
        """
        Parameters
        ----------
        Sl : analysis.baseAnalysis.analyzedFit
            Longitudinal symmetric amplitude fit object
        Al : analysis.baseAnalysis.analyzedFit
            Longitudinal asymmetric amplitude fit object
        St : analysis.baseAnalysis.analyzedFit
            Transverse symmetric amplitude fit object
        At : analysis.baseAnalysis.analyzedFit
            Transverse asymmetric amplitude fit object
        """

        self.Sl = Sl
        self.Al = Al
        self.St = St
        self.At = At
        
        # ensure all fit parameters have unique names
        conflicting_dv = []
        for dv in Sl.fit_ds.data_vars:
            if dv in At.fit_ds.data_vars:
                conflicting_dv.append(dv)
        
        Sld, Std, Ald, Atd = {}, {}, {}, {}
        for dv in conflicting_dv:
            if not dv.endswith("_err"):
                Sld[dv] = dv + "_Sl"
                Sld[dv+'_err'] = dv+"_Sl_err"
                
                Std[dv] = dv + "_St"
                Std[dv+'_err'] = dv+"_St_err"
                
                Ald[dv] = dv + "_Al"
                Ald[dv+'_err'] = dv+"_Al_err"
                
                Atd[dv] = dv + "_At"
                Atd[dv+'_err'] = dv+"_At_err"
        
        self.fit_ds = xr.merge(
            (
                Sl.fit_ds.rename(Sld),
                St.fit_ds.rename(Std),
                Al.fit_ds.rename(Ald),
                At.fit_ds.rename(Atd)
            )
        )

    def correct_signs(self):
        """
        Modifies the signs (in place) of the PHE/AHE such that the PHE has the exact same
        sign as the AMR, which makes sense because they are from the same source.

        """

        sgn = np.sign(self.fit_ds[self.Aamr]*self.fit_ds[self.Aphe])
        self.fit_ds[self.Sphe] = self.fit_ds[self.Sphe]*sgn
        self.fit_ds[self.Aphe] = self.fit_ds[self.Aphe]*sgn
        self.fit_ds[self.Sahe] = self.fit_ds[self.Sahe]*sgn
        self.fit_ds[self.Aahe] = self.fit_ds[self.Aahe]*sgn

    def plot_params(self, xname, yname, yerr_name = None, **kwargs):
        """
        Plots the fit parameters and their errors vs some dimension. Thin
        wrapper around :func:`~.plot_dataset`.

        Parameters
        ----------
        xname : str
            name of some ``dim`` of
            :attr:`~.HallSAAngFit.fit_ds`
        yname : str
            name of some ``data_var`` of
            :attr:`~.HallSAAngFit.fit_ds`
        yerr_name : str
            name of some ``data_var`` of
            :attr:`~.HallSAAngFit.fit_ds` representing
            error in yname.
            If none, defaults to ``(yname)_err'``
        **kwargs
            passed along to :func:``~.plot_dataset``

        Returns
        -------
        None
            Just plots the requested parameters.
        """

        # set yerr_name to default if none given
        if yerr_name is None:
            yerr_name = yname + '_err'

        plot_dataset(self.fit_ds, xname, yname, yerr_name=yerr_name, **kwargs)

    def plot_fits(self, lt, res_part, **kwargs):
        """
        Makes plotting the fit results easier

        Parameters
        ----------
        lt : 'l' or 't'
            string representing whether to find Meff using
            longitudinal or transverse resonances
        res_part : 'S' or 'A'
            Whether to fit the symmetric or antisymmetric parts of the resonance
        kwargs
            Passed along to the plotting function
        """

        if lt.lower() == 'l':
            if res_part == 'S':
                self.Sl.plot_fits(**kwargs)
            elif res_part == 'A':
                self.Al.plot_fits(**kwargs)
        elif lt.lower() == 't':
            if res_part == 'S':
                self.St.plot_fits(**kwargs)
            if res_part == 'A':
                self.At.plot_fits(**kwargs)

    # QUESTION: change sp -> ishe?

    def find_sp_correction(self, SA1, SA2, l, w, root=-1):
        """
        Finds the spin pumping correction factor, assuming it only enters on the
        symmetric component and is the same between all the symmetric components
        (up to the aspect ratio).

        Parameters
        ----------
        SA1 : 'smr' or 'phe' or 'ahe
            String indicating one S/A combination to use to find the spin-pumping
            correction. Must be different from SA2
        SA2 : 'smr' or 'phe' or 'ahe
            String indicating one S/A combination to use to find the spin-pumping
            correction. Must be different from SA1
        l : float
            Length of the bar in m
        w : float
            Width of the bar in m
        root : int
            Should be +1 or -1, choosing the positive or negative root when
            calculating the correction

        Returns
        -------
        xr.Dataset
            Spin-pumping correction factor, calculated using the requested
            S/A combination. Does not include the factor of length needed for
            the correction.
        """

        SA_types = SA1+' '+SA2
        Sphe = self.fit_ds[self.Sphe]
        dSphe = self.fit_ds[self.Sphe_err]
        Aphe = self.fit_ds[self.Aphe]
        dAphe = self.fit_ds[self.Aphe_err]
        Sahe = self.fit_ds[self.Sahe]
        dSahe = self.fit_ds[self.Sahe_err]
        Aahe = self.fit_ds[self.Aahe]
        dAahe = self.fit_ds[self.Aahe_err]
        Samr = self.fit_ds[self.Samr]
        dSamr = self.fit_ds[self.Samr_err]
        Aamr = self.fit_ds[self.Aamr]
        dAamr = self.fit_ds[self.Aamr_err]


        if 'phe' in SA_types and 'ahe' in SA_types:
            Spa = Sphe + Sahe
            SApa = Sphe*Sahe-Aphe*Aahe
            discrim = Spa**2-4*SApa
            discrimrt = np.sqrt(discrim)
            # TODO: which root do we use? Could have a + or - here
            Vsp = (Spa + root*discrimrt)/2/w
            Vsp_err = 1/2/w*np.sqrt(
                dSphe**2*(1+root*(Sphe-Sahe)/discrimrt)**2 \
                + dSahe**2*(1+root*(Sahe-Sphe)/discrimrt)**2 \
                + 1/discrim*((dAphe*Aahe)**2 + (dAahe*Aphe)**2)
            )
            return xr.Dataset({'Vsp': Vsp, 'Vsp_err': Vsp_err})
        # NOTE: doing PHE and AMR together actually doesn't make sense. Since they come from
        # the same thing, after rescaling by geometric factors you do actually
        # expect to get 0 for num and denom (in a perfect world)
        elif 'phe' in SA_types and 'amr' in SA_types:
            num = Aphe*Samr - Aamr*Sphe
            den = Aphe*l - Aamr*w
            return num/den
        elif 'amr' in SA_types and 'ahe' in SA_types:
            Spa = w*Samr + l*Sahe
            SApa = Samr*Sahe-Aamr*Aahe
            discrim = Spa**2-4*l*w*SApa
            discrimrt = np.sqrt(Spa**2-4*l*w*SApa)
            # TODO: which root do we use? Could have a + or - here
            Vsp = (Spa + root*np.sqrt(discrim))/(2*l*w)
            Vsp_err = 1/(2*l*w)*np.sqrt(
                (w*dSamr)**2*(1+root*(w*Samr-l*Sahe)/discrimrt)**2 \
                + (l*dSahe)**2*(1+root*(l*Sahe-w*Samr)/discrimrt)**2 \
                + (l*w)**2/discrim*((dAamr*Aahe)**2+(dAahe*Aamr)**2)
            )

            return xr.Dataset({'Vsp': Vsp, 'Vsp_err': Vsp_err})

        else:
            raise ValueError("Did not specify SA1 or 2 correctly")

    def find_all_sp_correction(self, l, w, root=1):
        """
        Finds the spin pumping correction factors, assuming it only enters on the
        symmetric component and is the same between all the symmetric components
        (up to the aspect ratio).

        Parameters
        ----------
        l : float
            Length of the bar in m
        w : float
            Width of the bar in m
        root : int
            Should be +1 or -1, choosing the positive or negative root when
            calculating the correction

        Returns
        -------
        xr.Dataset
            Spin-pumping correction factos. Does not include the factor of 
            length needed for the correction.
        """
        
        AHE_PHE = self.find_sp_correction('ahe','phe',l,w,root)
        AHE_AMR = self.find_sp_correction('ahe','amr',l,w,root)
        none = AHE_PHE.copy(deep=True)
        none.Vsp.values = np.zeros(none.Vsp.values.shape)
        none.Vsp_err.values = np.zeros(none.Vsp_err.values.shape)
        
        return combine_new_dim({'AHE_PHE': AHE_PHE, 'AHE_AMR': AHE_AMR, 'none': none}, 'SP_source')

    def calculate_corrected_SHE(self, SA_type, Vsp_ds, l, w, B0, Ms, Meff, tfm, tnm):
        """
        Calculates the spin Hall efficiency using the requested S/A type,
        including the spin-pumping correction

        Parameters
        ----------
        SA_type : 'ahe' or 'phe' or 'amr'
            which type of S/A to use
        Vsp_ds : xr.Dataset
            Spin-pumping corrections, chosen argument will decide which correction
            pair (AHE/PHE or AHE/AMR) is chosen
        l : float
            Length of the bar in m
        w : float
            Width of the bar in m
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetizatin in T
        Meff : float
            Effective magnetization in T
        tfm : float
            Ferromagnet thickness in m
        tnm : float
            Normal metal thickness in m

        Returns
        -------
        xr.Dataset
            A Dataset containing the calculated value of xiDL and the associated
            errors.
        """
        Vsp = Vsp_ds['Vsp']
        dVsp = Vsp_ds['Vsp_err']

        if SA_type == 'amr':
            S = self.fit_ds[self.Samr]
            dS = self.fit_ds[self.Samr_err]
            A = self.fit_ds[self.Aamr]
            dA = self.fit_ds[self.Aamr_err]
            num = (S-l*Vsp)
            den = A
            SA = (num/den).to_dataset(name='xiDL')
            SA_err = np.sqrt((dS/A)**2+(l*dVsp/A)**2+((S-l*Vsp)*dA/A**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        elif SA_type == 'phe':
            S = self.fit_ds[self.Sphe]
            dS = self.fit_ds[self.Sphe_err]
            A = self.fit_ds[self.Aphe]
            dA = self.fit_ds[self.Aphe_err]
            num = (S-w*Vsp)
            den = A
            SA = (num/den).to_dataset(name='xiDL')
            SA_err = np.sqrt((dS/A)**2+(w*dVsp/A)**2+((S-w*Vsp)*dA/A**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        elif SA_type == 'ahe':
            S = self.fit_ds[self.Sahe]
            dS = self.fit_ds[self.Sahe_err]
            A = self.fit_ds[self.Aahe]
            dA = self.fit_ds[self.Aahe_err]
            num = A
            den = (S-w*Vsp)
            SA = (num/den).to_dataset(name='xiDL')
            SA_err = np.sqrt((dA/(S-w*Vsp))**2+(A*dS/(S-w*Vsp)**2)**2+(A*w*dVsp/(S-w*Vsp)**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        else:
            raise ValueError("Did not specify SA type correctly")

        return SA*np.sqrt(1+Meff/B0)*echarge*Ms*tfm*tnm/hbar

    def calculate_all_corrected_SHE(self, Vsp_ds, l, w, B0, Ms, Meff, tfm, tnm):
        """ 
        Calculates and collects corrected SHE for all SA types. 
        for convenience. 
        
        Parameters
        ----------
        Vsp_ds : xr.Dataset
            Spin-pumping corrections, chosen argument will decide which correction
            pair (AHE/PHE or AHE/AMR) is chosen
        l : float
            Length of the bar in m
        w : float
            Width of the bar in m
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetizatin in T
        Meff : float
            Effective magnetization in T
        tfm : float
            Ferromagnet thickness in m
        tnm : float
            Normal metal thickness in m

        Returns
        -------
        xr.Dataset
            A Dataset containing the calculated value of xiDL and the associated
            errors.
        """
        
        AMR = self.calculate_corrected_SHE('amr', Vsp_ds, l, w, B0, Ms, Meff, tfm, tnm)
        AHE = self.calculate_corrected_SHE('ahe', Vsp_ds, l, w, B0, Ms, Meff, tfm, tnm)
        PHE = self.calculate_corrected_SHE('phe', Vsp_ds, l, w, B0, Ms, Meff, tfm, tnm)
        
        return combine_new_dim({'AMR': AMR, 'AHE': AHE, 'PHE': PHE}, 'SA_source')

    def calculate_uncorrected_SHE(self, SA_type, B0, Ms, Meff, tfm, tnm):
        """
        Calculates the spin Hall efficiency using the requested S/A type,
        including the spin-pumping correction

        Parameters
        ----------
        SA_type : 'ahe' or 'phe' or 'amr'
            which type of S/A to use
        B0 : float
            Resonant field in T
        Ms : float
            Saturation magnetizatin in T
        Meff : float
            Effective magnetization in T
        tfm : float
            Ferromagnet thickness in m
        tnm : float
            Normal metal thickness in m
        """

        if SA_type == 'amr':
            S = self.fit_ds[self.Samr]
            dS = self.fit_ds[self.Samr_err]
            A = self.fit_ds[self.Aamr]
            dA = self.fit_ds[self.Aamr_err]
            SA = (S/A).to_dataset(name='xiDL')
            SA_err = np.sqrt((dS/A)**2+(S*dA/A**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        elif SA_type == 'phe':
            S = self.fit_ds[self.Sphe]
            dS = self.fit_ds[self.Sphe_err]
            A = self.fit_ds[self.Aphe]
            dA = self.fit_ds[self.Aphe_err]
            SA = (S/A).to_dataset(name='xiDL')
            SA_err = np.sqrt((dS/A)**2+(S*dA/A**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        elif SA_type == 'ahe':
            S = self.fit_ds[self.Sahe]
            dS = self.fit_ds[self.Sahe_err]
            A = self.fit_ds[self.Aahe]
            dA = self.fit_ds[self.Aahe_err]
            SA = (A/S).to_dataset(name='xiDL')
            SA_err = np.sqrt((dA/S)**2+(A*dS/S**2)**2).to_dataset(name='xiDL_err')
            SA = SA.merge(SA_err)
        else:
            raise ValueError("Did not specify SA type correctly")

        return SA*np.sqrt(1+Meff/B0)*echarge*Ms*tfm*tnm/hbar
