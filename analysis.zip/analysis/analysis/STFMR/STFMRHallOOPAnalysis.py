from .STFMRHallAnalysis import HallSTFMRAnalysis
import xarray as xr

class HallOOPSTFMRAnalysis(HallSTFMRAnalysis):
    """
    Class to contain OOP STFMR related functions for theta sweeps.
    """
	
    THETA_DIM = 'field_polar'

    def separate_field_data(self, phi_offset=0., phi_reverse=False, phi_sort=False, theta_offset = 0., 
        theta_reverse=False, theta_sort=False):
        """
        Separates the positive and negative field data and assigns the negative
        field data to positive fields with Angles 180 deg from the original.
        Shifts the angle coordinates as well if requested.

        Parameters
        ----------
        phi_offset : float
            Angle to offset the angles by. If ``reverse`` is ``True``, we do
            ``phi_offset - phi``, otherwise ``phi - phi_offset``
        phi_reverse : bool
            Whether to reverse the angular coordinates as well, i.e. go from
            increasing phi meaning clockwise to counter-clockwise

        phi_sort : bool
            Whether to sort the values by increasing order.

        theta_offset : float
            Angle to offset the angles by. If ``reverse`` is ``True``, we do
            ``phi_offset - phi``, otherwise ``phi - phi_offset``
        theta_reverse : bool
            Whether to reverse the angular coordinates as well, i.e. go from
            increasing phi meaning clockwise to counter-clockwise

        theta_sort : bool
            Whether to sort the values by increasing order.

        Returns
        -------
        None
            Modifies :attr:`~.STFMRAnalysis.sweep_ds` in-place

        Raises
        ------
        ValueError
            If there is no negative field data. This could either mean none was
            taken or that this method has already been used.
        """
        pfield = self.sweep_ds.where(self.sweep_ds[self.BFIELD_DIM]>0, drop=True)
        nfield = self.sweep_ds.where(self.sweep_ds[self.BFIELD_DIM]<0, drop=True)

        if nfield[self.X_DATA_VAR].size == 0:
            raise ValueError('''No negative field data! This method was probably
                             already ran''')

        # Ensuring that the positive and negative fields have the same length,
        # dropping low-field data if they do not.
        plen = pfield.coords[self.BFIELD_DIM].values.size
        nlen = nfield.coords[self.BFIELD_DIM].values.size
        final_len = min(plen, nlen)
        # slicing is different since pfield is 0...max_field and nfield is
        # -max_field...0
        pfield = pfield.where(pfield[self.BFIELD_DIM] == pfield[self.BFIELD_DIM][-final_len:])
        nfield = nfield.where(nfield[self.BFIELD_DIM] == nfield[self.BFIELD_DIM][:final_len])
        # Assume positive and negative field points are (nominally) the same.
        # This is not actually true since e.g. +-.05 mA current to magnet does
        # *not* give the same magnitude of field, but it is pretty close.

        nfield.coords[self.BFIELD_DIM] = pfield.coords[self.BFIELD_DIM].values[::-1]
        nfield.coords[self.ANGLE_DIM] = 180 + nfield.coords[self.ANGLE_DIM].values


        # QUESTION: is this how we want to handle offsets?
        nfield.coords[self.ANGLE_DIM] -= phi_offset
        pfield.coords[self.ANGLE_DIM] -= phi_offset
        if phi_reverse:
            nfield.coords[self.ANGLE_DIM] *= -1
            pfield.coords[self.ANGLE_DIM] *= -1

        # ensure all angles are in [0,360]
        nfield.coords[self.ANGLE_DIM].values = [x+360 if x<0 else x for x in nfield.coords[self.ANGLE_DIM].values]
        pfield.coords[self.ANGLE_DIM].values = [x+360 if x<0 else x for x in pfield.coords[self.ANGLE_DIM].values]

        if phi_sort:
            self.sweep_ds = xr.concat([pfield,nfield], dim='field_azimuth').sortby('field_azimuth')
        else:
            self.sweep_ds = xr.concat([pfield,nfield], dim='field_azimuth')

        #Theta addition only do for theta != 0 assumes conventional coordinate system where OOP is theta = 0
        if nfield.coords[self.THETA_DIM].values != 90. :
            if theta_reverse:
                nfield.coords[self.THETA_DIM] *= -1
                pfield.coords[self.THETA_DIM] *= -1

            # QUESTION: is this how we want to handle offsets?
            nfield.coords[self.THETA_DIM] = nfield.coords[self.THETA_DIM].values - theta_offset
            pfield.coords[self.THETA_DIM] = pfield.coords[self.THETA_DIM].values - theta_offset

            nfield.coords[self.THETA_DIM] = 180 - pfield.coords[self.THETA_DIM].values
            # pfield.coords[self.THETA_DIM] = 90 - pfield.coords[self.THETA_DIM].values            

            if theta_sort:
                self.sweep_ds = xr.concat([pfield,nfield], dim='field_polar').sortby('field_polar')
            else:
                self.sweep_ds = xr.concat([pfield,nfield], dim='field_polar')

        self.coords = self.sweep_ds.coords
        self.dims = self.sweep_ds.dims
        self.data_vars = self.sweep_ds.data_vars