import numpy as np

from ..constants import *
from ..models import fitParameter, fitModel
from ..models import constfunc, constfunc_guess

# Resonance related

def omega0(B, Meff):
    """Resonant frequency"""
    return gamma*np.sqrt(abs(B)*(abs(B) + Meff))

def B0(f, Meff):
    """Resonant field"""
    w = 2*np.pi*f
    return 0.5*(-Meff + np.sqrt(Meff**2 + 4*w**2/(gamma)**2))

def B0_guess(f, B, **kwargs):
    """
    Guess function for use with fitting to find Meff. kwargs is used
    to catch any possible unexpected fit_ds dims, since these should not
    play a role in the fitting
    """
    return [1]

B0_params = [fitParameter('Meff', (0,np.inf))]

B0_model = fitModel('inverse_kittel', B0, B0_params, B0_guess)

def inverted_kittel_uniax_general(f, phiu, Meff, Ha, phi=45.): # TODO: handle phi correctly
    """ Kittel equation incorporating

    Parameters
    ----------
    f : float
        Frequency (GHz)
    phi : float
        angle of applied magnetic field (deg)
    phiu : float
        Angle of anisotropy axis (deg)
    Meff : float
        Effective magnetization (T)
    Ha : float
        Anisotropy field (T)
    """
    K = Ha/2*Meff
    phi = np.pi/180*(phi-phiu)
    M = Meff/2
    w = 2*np.pi*f
    return 1/2/M * (-K + 3*K*np.cos(2*phi) - 2*M**2 +\
                    M*np.sqrt((K+2*M**2)**2/M**2 + 4*w**2/gamma**2 +\
                        K*np.cos(2*phi)*(2*K+4*M**2+K*np.cos(2*phi))/M**2))

def inverted_kittel_uniax_general_guess(f, B0, Meff_guess, **kwargs):
    """
    Generates a guess for the parameters of the inverted Kittel function
    with a general uniaxial anisotropy.

    Parameters
    ----------
    phi : float
        Angle of applied field
    B0 : float
        Resonant field strength (T)
    Meff_guess : float
        Guess of effective magnetization 

    Returns
    -------
    Guess of phiu, Meff, Ha
    """

    return np.array([1, Meff_guess, 0.001])

inverted_kittel_uniax_general_params = [
    fitParameter('phiu', (-90,90)),
    fitParameter('Meff', (0,np.inf)),
    fitParameter('Ha', (-np.inf,np.inf)),
]

inverted_kittel_uniax_general_model = fitModel(
    'inv_kittel_uniax_gen',
    inverted_kittel_uniax_general, 
    inverted_kittel_uniax_general_params,
    inverted_kittel_uniax_general_guess
)

def Delta_formula(f, alpha, offset):
    """Expected formula for the Delta parameter in lorentzians"""
    return alpha*2*np.pi*f/gamma+offset

def Delta_formula_guess(f, Delta, **kwargs):
    """ Guess function for use with fitting linewidth to find damping.
    kwargs is used to catch any possible unexpected fit_ds dims. """

    m_guess = (Delta.max() - Delta.min())/(f.max() - f.min())
    Delta0_guess = Delta[0] - m_guess*f[0]

    alpha_guess = m_guess*gamma/(2*np.pi)

    return [alpha_guess, Delta0_guess]

Delta_params = [
    fitParameter('alpha', (0,np.inf)),
    fitParameter('Delta0', (-np.inf, np.inf))
]

Delta_model = fitModel('linewidth_damping', Delta_formula, Delta_params, Delta_formula_guess)

def sym_lor(B, B0, Delta, S):
    """Symmetric lorentzian"""
    return S*Delta**2/((np.abs(B) - B0)**2 + Delta**2)

def asym_lor(B, B0, Delta, A):
    """Asymmetric lorentzian"""
    return A*Delta*(np.abs(B) - B0)/((np.abs(B) - B0)**2 + Delta**2)

def lor_guess(field, X, rf_freq, Meff_guess, alpha_guess, A_guess, field_azimuth=45, **kwargs):
    """
    Guesses resonance parameters. For use in
    :meth:`~.STFMRAnalysis.fit_resonances`.

    Parameters
    ----------
    X : np.ndarray
        Mixing voltage data to guess parameters of
    field : np.ndarray
        Field strengths of data points to fit
    field_azimuth : float
        Azimuthal angle of field with respect to device angle
    rf_freq : float
        RF frequency of applied current
    Meff_guess : float
        Guess of effective magnetization in Tesla
    alpha_guess : float
        Guess of Gilbert damping parameter
    A_guess : float
        Guess of symmetric component maximum amplitude

    Returns
    -------
    np.array
        List of guesses of the resonance parameters. Format:
        [B0, Delta, A]
    """

    SAsign = np.sign(np.sin(2*(field_azimuth - 90)*deg2rad)
                        * np.cos((field_azimuth - 90)*deg2rad)) + 0.01

    return B0(rf_freq, Meff_guess), Delta_formula(rf_freq, alpha_guess, 0), A_guess*SAsign

def total_lor_jac(B, B0, Delta, S, A, offset):
    """
    Computes the jacobian of the total lorenzian function to make fitting
    more robust

    Some words about what function this is the jacobian of:
    inside curve_fit, both the function you're fittng and this jacobian
    will be recast into functions which accept the fit parameters and
    output a vector in the space of residuals between your function
    evaluated at the input `x` values and the `y` values you supplied to fit
    to. So, `f`: params -> residuals, and this is the function we're
    evaluating the jacobian of. Therefore, we need to output a matrix
    of shape (# values in fit domain) x (# fit parameters) where row `i` is
    the derivatives of f wrt the fit parameters evaluated at `x[i]` and col
    `j` is the derivative of `f` wrt fit parameter `j` evaluated at each `x`
    """

    # Define some often-used expressions
    dB = B-B0
    lorentz_denom = (dB**2 + Delta**2)

    # calculate factors which appear in several derivatives
    BD_deriv_factor = (2*S*Delta*dB + A*(dB**2-Delta**2))/lorentz_denom**2
    SA_deriv_factor = Delta/lorentz_denom

    # calculate the derivatives wrt the different fit parameters
    B0_deriv = Delta*BD_deriv_factor
    Delta_deriv = dB*BD_deriv_factor
    S_deriv = Delta*SA_deriv_factor
    A_deriv = dB*SA_deriv_factor
    offset_deriv = np.ones((B.size, 1))

    # Reshape and put together the derivatives into the jacobian
    return np.hstack((B0_deriv[:,np.newaxis],
                        Delta_deriv[:,np.newaxis],
                        S_deriv[:,np.newaxis],
                        A_deriv[:,np.newaxis],
                        offset_deriv))

sym_lor_params = [
    fitParameter('B0', (0, np.inf)),
    fitParameter('Delta', (0,np.inf)),
    fitParameter('S', (-np.inf, np.inf))
]

asym_lor_params = [
    fitParameter('B0', (0, np.inf)),
    fitParameter('Delta', (0,np.inf)),
    fitParameter('A', (-np.inf, np.inf))
]

sym_lor_model = fitModel('symmetric', sym_lor, sym_lor_params, lor_guess)

asym_lor_model = fitModel('antisymmetric', asym_lor, asym_lor_params, lor_guess)

## two resonances

def sym_lor2(B, B0, dB0, Delta, S):
    """Symmetric lorentzian"""
    return S*Delta**2/((np.abs(B) - (B0+dB0))**2 + Delta**2)

def asym_lor2(B, B0, dB0, Delta, A):
    """Asymmetric lorentzian"""
    return A*Delta*(np.abs(B) - (B0+dB0))/((np.abs(B) - (B0+dB0))**2 + Delta**2)

def lor2_guess(field, X, rf_freq, Meff_guess, Meff2_guess, alpha_guess, A2_guess, field_azimuth=45, **kwargs):
    """
    Guesses resonance parameters. For use in
    :meth:`~.STFMRAnalysis.fit_resonances`.

    Parameters
    ----------
    X : np.ndarray
        Mixing voltage data to guess parameters of
    field : np.ndarray
        Field strengths of data points to fit
    field_azimuth : float
        Azimuthal angle of field with respect to device angle
    rf_freq : float
        RF frequency of applied current
    Meff_guess : float
        Guess of effective magnetization in Tesla for first resonance
    Meff2_guess : float
        Guess of effective magnetization in Tesla for second resonance
    alpha_guess : float
        Guess of Gilbert damping parameter
    A_guess : float
        Guess of symmetric component maximum amplitude

    Returns
    -------
    np.array
        List of guesses of the resonance parameters. Format:
        [B0, Delta, A]
    """

    SAsign = np.sign(np.sin(2*(field_azimuth - 90)*deg2rad)
                        * np.cos((field_azimuth - 90)*deg2rad)) + 0.01
    
    B01 = B0(rf_freq, Meff_guess)
    B02 = B0(rf_freq, Meff2_guess)

    return B01, B02-B01, Delta_formula(rf_freq, alpha_guess, 0), A2_guess*SAsign

def total_2lor_jac(B, B0, Delta1, S1, A1, dB0, Delta2, S2, A2, offset):
    """
    Computes the jacobian of the sum of two lorenzian functions to make
    fitting more robust

    Some words about what function this is the jacobian of:
    inside curve_fit, both the function you're fittng and this jacobian
    will be recast into functions which accept the fit parameters and
    output a vector in the space of residuals between your function
    evaluated at the input `x` values and the `y` values you supplied to fit
    to. So, `f`: params -> residuals, and this is the function we're
    evaluating the jacobian of. Therefore, we need to output a matrix
    of shape (# values in fit domain) x (# fit parameters) where row `i` is
    the derivatives of f wrt the fit parameters evaluated at `x[i]` and col
    `j` is the derivative of `f` wrt fit parameter `j` evaluated at each `x`
    """

    # Define some often-used expressions
    dB1 = B-B0
    lorentz1_denom = (dB1**2 + Delta1**2)

    dB2 = B-B0-dB0
    lorentz2_denom = (dB2**2 + Delta2**2)

    # calculate factors which appear in several derivatives
    BD_deriv1_factor = (2*S1*Delta1*dB1 + A1*(dB1**2-Delta1**2))/lorentz1_denom**2
    SA_deriv1_factor = Delta1/lorentz1_denom

    BD_deriv2_factor = (2*S2*Delta2*dB2 + A2*(dB2**2-Delta2**2))/lorentz2_denom**2
    SA_deriv2_factor = Delta2/lorentz2_denom


    # calculate the derivatives wrt the different fit parameters
    B0_deriv = Delta1*BD_deriv1_factor + Delta2*BD_deriv2_factor
    Delta1_deriv = dB1*BD_deriv1_factor
    S1_deriv = Delta1*SA_deriv1_factor
    A1_deriv = dB1*SA_deriv1_factor

    dB0_deriv = Delta2*BD_deriv2_factor
    Delta2_deriv = dB2*BD_deriv2_factor
    S2_deriv =  Delta2*SA_deriv2_factor
    A2_deriv = dB2*SA_deriv2_factor

    offset_deriv = np.ones((B.size, 1))

    # Reshape and put together the derivatives into the jacobian
    return np.hstack((B0_deriv[:,np.newaxis],
                        Delta1_deriv[:,np.newaxis],
                        S1_deriv[:,np.newaxis],
                        A1_deriv[:,np.newaxis],
                        dB0_deriv[:,np.newaxis],
                        Delta2_deriv[:,np.newaxis],
                        S2_deriv[:,np.newaxis],
                        A2_deriv[:,np.newaxis],
                        offset_deriv))

sym_lor2_params = [
    fitParameter('B01', (0, np.inf)),
    fitParameter('dB0', (-np.inf, -1e-2)), # unlikely we will be able to resolve smaller than this anyway
    fitParameter('Delta2', (0,np.inf)),
    fitParameter('S2', (-np.inf, np.inf))
]

asym_lor2_params = [
    fitParameter('B01', (0, np.inf)),
    fitParameter('dB0', (-np.inf,  -1e-2)), # unlikely we will be able to resolve smaller than this anyway
    fitParameter('Delta2', (0,np.inf)),
    fitParameter('A2', (-np.inf, np.inf))
]

sym_lor2_model = fitModel('symmetric2', sym_lor2, sym_lor2_params, lor2_guess)

asym_lor2_model = fitModel('antisymmetric2', asym_lor2, asym_lor2_params, lor2_guess)

# angular dependence of S and A

def SA_Tx_AMR_func(p, Tx, phi0):
    """
    angular dependence of S (A) due to mxmxx (mxx) torques and AMR
    """
    phi = (p-phi0)*deg2rad
    return Tx*np.sin(2*phi)*np.sin(phi)

def SA_Ty_AMR_func(p, Ty, phi0):
    """
    angular dependence of S (A) due to mxmxy (mxy) torques and AMR
    """
    phi = (p-phi0)*deg2rad
    return Ty*np.sin(2*phi)*np.cos(phi)

def SA_Tz_AMR_func(p, Tz, phi0):
    """
    angular dependence of S (A) due to mxz (mxmxz) torques and AMR
    """
    phi = (p-phi0)*deg2rad
    return Tz*np.sin(2*phi)

def SA_Ty_PHE_func(p, Ty, phi0):
    """
    Angular dependence of symmetric/antisymmetric components of the Hall resonance
    due to PHE with mxy and mxmxy torques
    """
    phi = (p-phi0)*deg2rad
    return Ty*np.cos(2*phi)*np.cos(phi)

def SA_Ty_AHE_func(p, Ty, phi0):
    """
    Angular dependence of symmetric/antisymmetric components of the Hall resonance
    due to AHE with mxy and mxmxy torques
    """
    phi = (p-phi0)*deg2rad
    return -1*Ty*np.cos(phi) # NOTE: Saba included the -1 for better fitting

def SA_func_guess(p, SA, **kwargs):
    """ guess function for sinusoid with offset """
    amp_guess = np.mean(np.abs(SA))
    return [amp_guess, 0]

FLx_AMR_model = fitModel(
    'FLx',
    SA_Tx_AMR_func,
    [
        fitParameter('FLx', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

FLy_AMR_model = fitModel(
    'FLy',
    SA_Ty_AMR_func,
    [
        fitParameter('FLy', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

FLz_AMR_model = fitModel(
    'FLz',
    SA_Tz_AMR_func,
    [
        fitParameter('FLz', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    constfunc_guess
)

ADx_AMR_model = fitModel(
    'ADx',
    SA_Tx_AMR_func,
    [
        fitParameter('ADx', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

ADy_AMR_model = fitModel(
    'ADy',
    SA_Ty_AMR_func,
    [
        fitParameter('ADy', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

ADz_AMR_model = fitModel(
    'ADz',
    SA_Tz_AMR_func,
    [
        fitParameter('ADz', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    constfunc_guess
)

S_AMR_model = fitModel(
    'Samr',
    SA_Ty_AMR_func,
    [
        fitParameter('Samr', (-np.inf, np.inf)),
        fitParameter('phi0', (-90, 90))
    ],
    SA_func_guess
)

A_AMR_model = fitModel(
    'Aamr',
    SA_Ty_AMR_func,
    [
        fitParameter('Aamr', (-np.inf, np.inf)),
        fitParameter('phi0', (-90, 90))
    ],
    SA_func_guess
)

S_PHE_model = fitModel(
    'Sphe',
    SA_Ty_PHE_func,
    [
        fitParameter('Sphe', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

A_PHE_model = fitModel(
    'Aphe',
    SA_Ty_PHE_func,
    [
        fitParameter('Aphe', (-np.inf, np.inf)),
        fitParameter('phi0', (-45, 45))
    ],
    SA_func_guess
)

S_AHE_model = fitModel(
    'Sahe',
    SA_Ty_AHE_func,
    [
        fitParameter('Sahe', (-np.inf, np.inf)),
        fitParameter('phi0', (-90, 90))
    ],
    SA_func_guess
)

A_AHE_model = fitModel(
    'Aahe',
    SA_Ty_AHE_func,
    [
        fitParameter('Aahe', (-np.inf, np.inf)),
        fitParameter('phi0', (-90, 90))
    ],
    SA_func_guess
)