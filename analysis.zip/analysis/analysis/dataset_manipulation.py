from itertools import product
from inspect import getfullargspec

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import xarray as xr
from scipy.optimize import leastsq, curve_fit


def gen_coord_combo(ds, drop_dims=[], selections={}, omissions={}, ranges={}): 
    """
    Generates a cartesian product of combinations of all coordinates of the
    given dataset, subject to coordinate constraints and excluded dimensions.
    First selects, then omits, then finds ranges.
    
    Parameters
    ----------
    ds : xarray.DataArray or xarray.Dataset
        xarray object whose coordinates to consider
    drop_dims : list of str
        Dimensions to exclude from the combination
    selections : dict
        Coordinate selections to draw from. Key should be dimension name,
        values a list of coordinate values to select along that dimension
    omissions : dict
        Coordinate omissions. Key should be dimension name,
        values a list of coordinate values to omit along that dimension
    ranges : dict
        Coordinate ranges to select. Key should be a dimension name, values
        should be a 2-tuple of lower and upper coordinate limits to use for
        that dimension
        
    Returns
    -------
    itertools.product
        A cartesian product of the remaining dimensions of `ds`
    """

    remaining_coords = {k: v.values for k, v in ds.sel(selections).coords.items()}
    for dim, omits in omissions.items():
        remaining_coords[dim] = np.asarray([x for x in remaining_coords[dim] if x not in np.atleast_1d(omits)])
    for dim, lims in ranges.items():
        remaining_coords[dim] = np.asarray([x for x in remaining_coords[dim] if x >= lims[0] and x <= lims[1]])
        
    remaining_dims = [dim for dim in ds.dims if dim not in drop_dims]

    # Making a cartesian product of all of the coord vals to loop over
    coord_vals = [np.atleast_1d(remaining_coords[dim])
                  for dim in remaining_dims]
    return product(*coord_vals)

def gen_copy_ds(ds, new_dvar_names, drop_dims = [], **selections):
    """
    Generates a copy of `ds` with identical coordinates but given
    data variable names
    
    Parameters
    ----------
    ds : xarray.Dataset
        Dataset to base new one on
    new_dvar_names : list of str
        Data variable names of the new dataset
    drop_dims : lsit of str
        Dimensions to leave off of the new dataset
    **selections
        Coordinate selections to narrow coordinates copied to new dataset
    
    Returns
    -------
    xarray.Dataset
        New dataset with desired data varialbes and subset of coordinates.
        Entries are meaningless and cannot be relied upon.
    """
    
    selections = {k : np.atleast_1d(v) for k, v in selections.items()}
    
    remaining_ds = ds.sel(selections)
    
    remaining_dims = tuple(dim for dim in ds.dims if dim not in drop_dims)
    
    # generate data vars with random data
    ndims_sizes = tuple(remaining_ds.coords[dim].size for dim in remaining_dims)
    new_dvars = {}
    for dv in new_dvar_names:
        new_dvars[dv] = (remaining_dims, np.empty(ndims_sizes))
        
    new_coords = {dim: v.values for dim, v in remaining_ds.coords.items() if dim in remaining_dims}
    
    return xr.Dataset(data_vars=new_dvars, coords=new_coords)

def combine_new_ds_dim(ds_dict, new_dim_name):
    """
    Combines a dictionary of datasets along a new dimension using dictionary keys
    as the new coordinates.

    Parameters
    ----------
    ds_dict : dict
        Dictionary of xarray Datasets or dataArrays
    new_dim_name : str
        The name of the newly created dimension

    Returns
    -------
    xarray.Dataset
        Merged Dataset or DataArray

    Raises
    ------
    ValueError
        If the values of the input dictionary were of an unrecognized type
    """

    expanded_dss = []

    for k, v in ds_dict.items():
        expanded_dss.append(v.expand_dims(new_dim_name))
        expanded_dss[-1][new_dim_name] = [k]
    new_ds = xr.concat(expanded_dss, new_dim_name)

    return new_ds

def coordinate_slice(ds, coord, llim=-np.inf, ulim=np.inf):
    """
    Returns a slice of coordinate values of a dataset
    
    Parameters
    ----------
    ds : xr.Dataset or xr.DataArray
        xarray objet to take slice from
    coord : str
        Name of coordinate to slice
    llim : float
        lower limit of slice
    ulim : float
        upper limit of slice
    
    Returns
    -------
    np.array
    """
    
    mask = np.logical_and(ds[coord]>=llim, ds[coord]<=ulim)
    
    return ds[coord].where(mask,drop=True).values

# TODO: Add omissions and ranges to arguments for fitting and plotting

def make_fit_dataArray_guesses(yda, guess_func, param_names, xname, xda=None, guess_func_help_params={}, **selections):
    """
    creates a dataset of guesses of param_names given ``guess_func``. To be used
    in :func:`~.fit_dataArray`.

    Parameters
    ----------
    yda : xarray.DataArray
        data array containing data to fit to
    guess_func : function
        function to generate guesses of parameters. Arguments must be:
        - numpy array of x data
        - 1D numpy array of y data
        - keyword arguments, with the keywords being all dims of ds besides
        xname. Values passed will be individual floats of coordinate values
        corresponding to those dims.
        All arguments must be accepted, not all must be used.
        As a hint, if designing for unexpected dims you can include **kwargs at
        the end. This will accept any keword arguments not explicitly defined
        by you and just do nothing with them.
        Must return a list of guesses to the parameters, in the order given in
        param_names
    param_names : list of str
        list of fit parameter names, in the order they are returned
        by ``guess_func``
    xname : str
        the name of the  ``dim`` of ``da`` to be fit along
    guess_func_help_params : dict
        Dictionary of any "constant" parameters to help in generating fit
        guesses. Passed as keyword arguments to ``guess_func``.
    **selections
        keywords should be names of ``dims`` of ``da``
        values should eitherbe single coordinate values or lists of coordinate
        values of those ``dims``. Only data with coordinates given by selections
        have parameter guesses generated. If no selections given, guesses are
        generated for everything

    Returns
    -------
    xarray.Dataset
        A Dataset with param_names as data_vars containing all guesses, and all
        ``dims`` of ``ds`` besides xname with the same coordinates, unless
        otherwise specified in ``**selections``.
    """
    
    xsel = {} if xname not in selections else {xname : selections[xname]}
    
    if xda is None:
        xda = yda.coords[xname]
    xdims = xda.dims
    
    remaining_dims = [dim for dim in yda.dims if dim != xname]

    coord_combos = gen_coord_combo(yda, [xname], selections=selections)
    
    # Generate empty dataset to contain parameter guesses
    guess_ds = gen_copy_ds(yda, param_names, [xname], **selections)
    
    # do x selections
    yda = yda.sel(xsel)
    xda = xda.sel(xsel)

    # apply guess_func for each coord combo and record param guesses
    for combo in coord_combos:
        selection_dict = dict(zip(remaining_dims, combo))
        xselection_dict = {k: v for k, v in selection_dict.items() if k in xdims}

        # load x/y data for this coordinate combination
        ydata = yda.sel(selection_dict).values
        xdata = xda.sel(xselection_dict).values

        # Deal with any possible spurious data
        if np.all(np.isnan(ydata)):
            # there is no meaningful data. Fill guesses with nan's
            for i, pname in enumerate(param_names):
                guess_ds[pname].loc[selection_dict] = np.nan
            continue
        else:
            # remove bad datapoints
            good_pts = np.logical_and(np.isfinite(ydata), np.isfinite(xdata))
            xdata = xdata[good_pts]
            ydata = ydata[good_pts]

        # generate guesses
        guesses = guess_func(xdata, ydata, **guess_func_help_params, **selection_dict)

        # record fit parameters and their errors
        for i, pname in enumerate(param_names):
            guess_ds[pname].loc[selection_dict] = guesses[i]

    return guess_ds

def fit_dataArray(yda, fit_func, guess_func, param_names, xname, xda=None, yname=None,
                  yerr_da=None,bootstrap_samples=0, guess_func_help_params={}, ignore_faliure=False, **kwargs):
    """
    Fits values in a data array to a function. Returns an
    :class:`~.analyzedFit` object

    Parameters
    ----------
    yda : xarray.DataArray
        Dataset containing data to be fit.
    fit_func : function
        function to fit data to
    guess_func : function
        function to generate guesses of parameters. Arguments must be:
        - numpy array of x data
        - 1D numpy array of y data
        - keyword arguments, with the keywords being all dims of ds besides
        xname. Values passed will be individual floats of coordinate values
        corresponding to those dims.
        As a hint, if designing for unexpected dims you can include ``**kwargs``
        at the end. This will accept any keword arguments not explicitly defined
        by you and just do nothing with them.
        All arguments must be accepted, not all must be used. fit results
        Must return a list of guesses to the parameters, in the order given in
        ``param_names``
    param_names : list of str
        list of fit parameter names, in the order they are returned
        by guess_func
    xname : str
        the name of the ``dim`` of ``da`` to be fit along
    xda : xarray.DataArray or None
        If given, dataArray containing data to use as the dependent variable
        in the fits. Must include ``xname`` among its dims and have a 
        subset of the coords of ``yda``
    yname : str or None
        Optional. The name of the y data being fit over.
    yerr_da : xarray.DataArray or None
        Optional. If provided, must be a data array containing errors in the
        data contained in ``da``. Must have the same coordinates as ``da``
    bootstrap_samples : int
        Number of boostrap samples to draw to get beter statistics on the
        parameters and their errors. If zero no boostrap resampling is done
    guess_func_help_params : dict
        Dictionary of any "constant" parameters to help in generating fit
        guesses. Passed as keyword arguments to ``guess_func``.
    ignore_faliure : bool
        if True, will ignore a ``RuntimeError`` from curve_fit that the
        optimal parameters were not found, and will fill with nan and print
        a message
    **kwargs
        can be:
        - names of ``dims`` of ``da``
        values should eitherbe single coordinate values or lists of coordinate
        values of those ``dims``. Only data with coordinates given by selections
        are fit to . If no selections given, everything is fit to.
        - kwargs of ``curve_fit``

    Returns
    -------
    analyzedFit
        Object containing all results of fitting and some convenience methods.
    """

    selections = {dimname: coords for dimname, coords in kwargs.items() if dimname in yda.dims}
    xsel = {} if xname not in selections else {xname : selections[xname]}
    guesses = make_fit_dataArray_guesses(
        yda,
        guess_func,
        param_names,
        xname,
        xda,
        guess_func_help_params,
        **selections
    )

    # Determine which kwargs can be passed to curve_fit
    cf_argspec = getfullargspec(curve_fit)
    lsq_argspec = getfullargspec(leastsq)
    good_args = cf_argspec.args + lsq_argspec.args
    cf_kwargs = {k: v for k, v in kwargs.items() if k in good_args}

    full_param_names = param_names + [pname+'_err' for pname in param_names]

    # Get the selection and empty fit dataset
    fit_ds = gen_copy_ds(yda, full_param_names, [xname], **selections)
    coord_combos = gen_coord_combo(yda, [xname], selections=selections)
    remaining_dims = [dim for dim in yda.dims if dim != xname]
    
    if xda is None:
        xda = yda.coords[xname]
    
    # Do selections along the x dimension
    xda = xda.sel(xsel)
    yda = yda.sel(xsel)
    if yerr_da is not None:
        yerr_da = yerr_da.sel(xsel)

    # Do the fitting
    for combo in coord_combos:
        selection_dict = dict(zip(remaining_dims, combo))
        xselection_dict = {k: v for k,v in selection_dict.items() if k in xda.dims}

        # load x/y data for this coordinate combination
        ydata = yda.sel(selection_dict).values
        xdata = xda.sel(xselection_dict).values
        if yerr_da is not None:
            yerr = yerr_da.sel(selection_dict).values
        else:
            yerr = None

        # load fit parameter guesses for this coordinate combination
        guess = [float(guesses[pname].sel(selection_dict).values) for pname in param_names]
        guess = np.array(guess)

        # Deal with any possible spurious data
        if np.all(np.isnan(ydata)):
            # there is no meaningful data. Fill fit results with nan's
            for i, pname in enumerate(param_names):
                fit_ds[pname].loc[selection_dict] = np.nan
                fit_ds[pname+'_err'].loc[selection_dict] = np.nan
            continue
        else:
            # remove bad datapoints
            good_pts = np.logical_and(np.isfinite(ydata), np.isfinite(xdata))
            if yerr_da is not None:
                good_pts = np.logical_and(good_pts, np.isfinite(yerr))
                yerr = yerr[good_pts]
            xdata = xdata[good_pts]
            ydata = ydata[good_pts]

        if ydata.size < len(param_names):
            print("Less finite datapoints than parameters at : ", selection_dict)
            for i, pname in enumerate(param_names):
                fit_ds[pname].loc[selection_dict] = np.nan
                fit_ds[pname+'_err'].loc[selection_dict] = np.nan
            continue

        # fit
        try:
            asig = True if yerr_da is not None else False
            popt, pcov = curve_fit(fit_func, xdata, ydata, guess, yerr, absolute_sigma=asig, **cf_kwargs)
            perr = np.sqrt(np.diag(pcov)) # from curve_fit documentation
        except RuntimeError:
            if ignore_faliure:
                popt = np.ones(len(param_names))*np.nan
                perr = np.ones(len(param_names))*np.nan
            else:
                raise

        if bootstrap_samples > 0 and not np.all(np.isnan(popt)): # TODO: figure out a better way of handling points with large errors
            fit_ys = fit_func(xdata, *popt)
            residuals = ydata - fit_ys

            if yerr_da is not None:
                ys_weights = 1/yerr**2
                ys_weights = ys_weights / ys_weights.sum()
            else:
                ys_weights = None
            popts = []
            for _ in range(bootstrap_samples):
                # draw with replacement, weighting each residual by 1/error**2 so points
                # with large errors are suppressed
                residual_sample = np.random.choice(residuals, size=ydata.size, replace=True, p=ys_weights)
                y_sample = fit_ys + residual_sample
                popt_samp, _ = curve_fit(fit_func, xdata, y_sample, popt, **cf_kwargs)
                popts.append(popt_samp)
            popts = np.array(popts)
            popt = popts.mean(0)
            perr = popts.std(0)

        # record fit parameters and their errors
        for i, pname in enumerate(param_names):
            fit_ds[pname].loc[selection_dict] = popt[i]
            fit_ds[pname+'_err'].loc[selection_dict] = perr[i]

    return analyzedFit(
        fit_ds,
        yda,
        xda,
        fit_func,
        guess_func,
        param_names,
        xname,
        yname,
        yerr_da
    )

# TODO: Guessing breaks when there is only one model with one parameter,
#       has to do with a zip() in combining the guesses.

def fit_dataArray_models(da, models, xname, **kwargs):
    """
    fits a dataArray to a collection of models
    """
    
    # make list of all unique parameters, with intersection of bounds if same 
    # parameter in multiple models
    all_params = []
    for m in models:
        for param in m.params:
            for p in all_params:
                if p == param:
                    p.intersect(param)
                    break
            else: # if not found in all_params
                all_params.append(param)

    def full_func(x, *args):
        cumsum = 0
        for m in models:
            mparams = [args[all_params.index(p)] for p in m.params]
            cumsum += m(x, *mparams)
        return cumsum

    # mean of estimate from each model TODO: should we do median instead?
    def full_guess(x, y, **kwargs):
        guesses = []
        
        # generate parameter guesses from each model
        for m in models:
            model_guesses = np.atleast_1d(m.guess(x, y, **kwargs))
            guesses.append(dict(zip([p.name for p in m.params], model_guesses)))
        
        # take the mean of all guesses for each parameter
        final_guesses = []
        for param in all_params:
            count = 0
            cumsum = 0
            for guess in guesses:
                if param.name in guess:
                    count += 1
                    cumsum += guess[param.name]
                else:
                    pass
            final_guesses.append(cumsum/count)
            
        return final_guesses
    
    bounds = [[], []]
    for p in all_params:
        bounds[0].append(p.bounds[0])
        bounds[1].append(p.bounds[1])
    
    a = fit_dataArray(da, full_func, full_guess, [p.name for p in all_params], xname, bounds=tuple(bounds), **kwargs)
    
    return analyzedModelFit.from_analyzedFit(a, models)

def fit_dataset(ds, fit_func, guess_func, param_names, xname, yname, xda_name=None, yerr_name=None, bootstrap_samples=0, guess_func_help_params={}, **kwargs):
    """
    Fits values in a dataset to a function. Returns an
    :class:`~.analyzedFit` object.

    Convenience function which calls :func:`~.fit_dataArray`.

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset containing data to be fit.
    fit_func : function
        function to fit data to
    guess_func : function
        function to generate guesses of parameters. Arguments must be:
        - numpy array of x data
        - 1D numpy array of y data
        - keyword arguments, with the keywords being all dims of ds besides
        xname. Values passed will be individual floats of coordinate values
        corresponding to those dims.
        As a hint, if designing for unexpected dims you can include **kwargs at
        the end. This will accept any keword arguments not explicitly defined
        by you and just do nothing with them.
        All arguments must be accepted, not all must be used.fit results
        Must return a list of guesses to the parameters, in the order given in
        ``param_names``
    param_names : list of str
        list of fit parameter names, in the order they are returned
        by guess_func
    xname : str
        the name of the ``dim`` of ``ds`` to be fit along
    yname : str
        the name of the  containing data to be fit to
    xda_name : str
        Name of the data variable which contains the x data
    yerr_name : str
        Optional. the name of the ``data_var`` of ``ds`` containing errors in data
        to be fit.
    bootstrap_samples : int
        Number of boostrap samples to draw to get beter statistics on the
        parameters and their errors. If zero no boostrap resampling is done
    guess_func_help_params : dict
        Dictionary of any "constant" parameters to help in generating fit
        guesses. Passed as keyword arguments to ``guess_func``.
    **kwargs
        can be:
        - names of ``dims`` of ``ds``
        values should eitherbe single coordinate values or lists of coordinate
        values of those ``dims``. Only data with coordinates given by selections
        are fit to . If no selections given, everything is fit to.
        - kwargs of ``curve_fit``

    Returns
    -------
    analyzedFit
        Object containing all results of fitting and some convenience methods.
    """
    
    yerr_da = None if yerr_name is None else ds[yerr_name]
    
    xda = None if xda_name is None else ds[xda_name]

    fit_da = ds[yname]

    return fit_dataArray(fit_da, fit_func, guess_func, param_names, xname, xda,
                         yname, yerr_da, bootstrap_samples,
                         guess_func_help_params, **kwargs)

def fit_dataset_models(ds, models, xname, yname, yerr_name=None, **kwargs):
    """
    Fits a dataset to a collection of models, combined additively
    
    Parameters
    ----------
    ds : xr.Dataset
        Dataset containing data to fit
    models : list of fitModel
        Models to fit to
    xname : str
        Name of coordinate to use as the independent variable
    yname : str
        name of dataArray to use as the dependent variable
    yerr_name : str
        name of dataArray to use as the errors in the dependent variable
    """
    
    if yerr_name is not None:
        if yerr_name not in ds.data_vars:
            raise AttributeError('%s is not a data_var!'%yerr_name)
        else:
            yerr_da = ds[yerr_name]
    else:
        yerr_da=None

    fit_da = ds[yname]

    return fit_dataArray_models(fit_da, models, xname,
                         yname=yname, yerr_da=yerr_da, **kwargs)

# TODO: allow for many y's, to compare params
# TODO: allow for scaling y axis by some constant factor, call it y_scale or something

def plot_dataArray(yda, xdim, xda=None, xname=None, yname=None, overlay=False, yerr_da=None, hide_large_errors=False, show_legend=True, **kwargs):
    """
    Plots some data in ``da``.

    Parameters
    ----------
    yda : xarray.DataArray
        Data array containing data to plot
    xdim : str
        name of the ``dim`` of ``da`` to plot along
    xda : xarray.DataArray
        Data array containing data to use as x in the plots. If none, use
        the data from the ``xdim`` coordinate
    xname : str
        Name of the x data being plotted. Will be x label of plots.
    yname : str
        Optional. Name of y data being plotted. Will be y label of plots.
    overlay : bool
        Whether all plots should be overlayed on top of one another on a
        single plot, or if each thing should have its own plot.
    yerr_da : xarray.DataArray
        optional. Data array with same coordinates as ``da`` which has data
        to be used for plotting errorbars
    hide_large_errors : bool
        If ``True``, errorbars which are large compared to the mean
        of the data will be rendered smaller with arrows to denote these errors
        are only "bounds" on the actual error. Will also move outliers to the
        mean of the data and give them the same error bars as above.
    show_legend : bool
        Whether the legend should be rendered if the plots are overlaid
    **kwargs
        Can either be:
        - names of ``dims`` of ``da``
        values should eitherbe single coordinate values or lists of coordinate
        values of those ``dims``. Only data with coordinates given by selections
        are plotted. If no selections given, everything is plotted.
        - kwargs passed to ``plot`` or ``errorbar``, as appropriate

    Returns
    -------
    None
        Just plots the requested plots.
    """
    
    # Determine labels to use
    if xname is not None:
        xlabel = xname
    elif xda is not None and xda.name is not None:
        xlabel = xda.name
    else:
        xlabel = xdim
        
    if yname is not None:
        ylabel = yname
    elif yda.name is not None:
        ylabel = yda.name
    else:
        ylabel = ''

    # Get the selections and coordinate combinations
    selections = {dimname: coords for dimname, coords in kwargs.items() if dimname in yda.dims}
    xsel = {} if xdim not in kwargs else {xdim : kwargs[xdim]}

    coord_combos = gen_coord_combo(yda, [xdim], selections=selections)

    if xda is None:
        xda = yda[xdim]

    remaining_dims = [dim for dim in yda.dims if dim != xdim]

    # Determine which kwargs can be passed to plot
    if yerr_da is None:
        plot_argspec = getfullargspec(Line2D)
        plot_kwargs = {k: v for k, v in kwargs.items() if k in plot_argspec.args}
    else:
        ebar_argspec = getfullargspec(plt.errorbar)
        plot_kwargs = {k: v for k, v in kwargs.items() if k in ebar_argspec.args}

    # Do x selections
    yda = yda.sel(xsel)
    xda = xda.sel(xsel)
    if yerr_da is not None:
        yerr_da = yerr_da.sel(xsel)

    # Plot for all coordinate combinations
    for combo in coord_combos:
        selection_dict = dict(zip(remaining_dims, combo))
        xselection_dict = {k: v for k, v in selection_dict.items() if k in xda.dims}
        ydata = yda.sel(selection_dict).values
        xdata = xda.sel(xselection_dict).values
        
        # don't plot if there are only nan's
        if np.all(np.isnan(ydata)) == True:
            continue

        label = (len(selection_dict.values())*'{},').format(*tuple(selection_dict.values()))
        label = label[:-1] # remove trailing comma

        if yerr_da is None:
            plt.plot(xdata, ydata, label=label, **plot_kwargs)
        else:
            yerr = yerr_da.sel(selection_dict).values
            num_pts = yerr.size
            errlims = np.zeros(num_pts).astype(bool)
            if hide_large_errors: # hide outliers if requested
                data_avg = np.nanmean(np.abs(ydata))
                data_std = np.nanstd(ydata)
                for i, err in enumerate(yerr):
                    if err > 5*data_std:
                        yerr[i] = data_std*.5 # TODO: Find some better way of marking this
                        errlims[i] = True
                for i, val in enumerate(ydata):
                    if np.abs(val - data_avg) > 5*data_std:
                        ydata[i] = data_avg
                        yerr[i] = data_std*0.5
                        errlims[i] = True
            plt.errorbar(xdata, ydata, yerr, lolims=errlims, uplims=errlims,
                         label=label, **plot_kwargs)
        plt.xlabel(xlabel)
        plt.ylabel(ylabel)
        title_str = ''
        for item in selection_dict.items():
            title_str += '{}: {}, '.format(*item)
        plt.title(title_str[:-2]) # get rid of trailing comma and space
        if not overlay:
            plt.show()
    if overlay: # TODO: find way to put legend on the side of the plot so nothing is covered up?
        plt.title('%s vs %s'%(ylabel, xlabel))
        if show_legend:
            legend_title = len(selection_dict.keys())*'%s,'%tuple(selection_dict.keys())
            legend_title = legend_title[:-1] # remove trailing comma
            plt.legend(title=legend_title)
        plt.show()

def plot_dataset(ds, xdim, yname, xda_name=None, xname=None, overlay=False, yerr_name=None, hide_large_errors=False, show_legend=True, **kwargs):
    """
    Plots some data in ``ds``.

    Convenience function which calls :func:`~.plot_dataArray`

    Parameters
    ----------
    ds : xarray.Dataset
        Dataset containing data to plot
    xdim : str
        name of the ``dim`` of ``ds`` to plot along
    yname : str
        name of the ``data_var`` of ``ds`` containing data to plot
    xda : str
        name of ``dim`` of ``ds`` containing x data to use. If ``None`` we
        just use coordinate information from ``xdim``
    overlay : bool
        Whether all plots should be overlayed on top of one another on a
        single plot, or if each thing should have its own plot.
    yerr_name : str
        optional. If specified, should be the name of some ``data_var`` of ``ds``
        containing errors in y data.
    hide_large_errors : bool
        If ``True``, errorbars which are large compared to the mean
        of the data will be rendered smaller with arrows to denote these errors
        are only "bounds" on the actual error. Will also move outliers to the
        mean of the data and give them the same error bars as above.
    show_legend : bool
        Whether the legend should be rendered if the plots are overlaid
    **kwargs
        Can either be:
        - names of ``dims`` of ``ds``
        values should eitherbe single coordinate values or lists of coordinate
        values of those ``dims``. Only data with coordinates given by selections
        are plotted. If no selections given, everything is plotted.
        - kwargs passed to ``plot`` or ``errorbar``, as appropriate

    Returns
    -------
    None
        Just plots the requested plots.
    """

    yerr_da = None if yerr_name is None else ds[yerr_name]
    
    xda = None if xda_name is None else ds[xda_name]

    plot_dataArray(ds[yname], xdim, xda, xname, yname, overlay, yerr_da, hide_large_errors,
                  show_legend, **kwargs)

class analyzedFit():
    """
    Class containing the results of :func:`~.fit_dataset`.
    Given for convenience to give to plotting functions.

    Parameters
    ----------
    fit_ds : xarray.Dataset
        the dataset which resulted from fitting
    main_da : xarray.DataArray
        the data array which was fit over
    main_xda : xarray.DataArray or None
        the data array of x values which were fit over
    fit_func : function
        the function which was used to fit the data
    guess_func : function
        the function which was used to generate initial parameter
        guesses
    param_names : list of str
        names of the parameters of ``fit_func``, in the order it
        accepts them
    xname : str
        the name of the``dim`` of ``main_da`` which was fit over
    yname : str or None
        Name of the y data which was fit over
    yerr_da : xarray.dataArray or None
        The data array containing y error information for the data in ``main_da``

    Attributes
    ----------
    fit_ds : xarray.Dataset
        the dataset containing all of the found fit parameters and errors
    main_da : xarray.DataArray
        the data array which was fit over
    coords : xarray.coords
        ``coords`` of :attr:`~.analyzedFit.fit_ds`
    dims : xarray.dims
        ``dims`` of :attr:`~.analyzedFit.fit_ds`
    data_vars : xarray.data_vars
        ``data_vars`` of :attr:`~.analyzedFit.fit_ds`
    fit_func : function
        function which was fit
    guess_func : function
        function used for generating guesses
    param_names : list of str
        Names of parametrs fit to
    xname : str
        name of :attr:`~.analyzedFit.main_ds` ``dim``
        which was fit over
    yname : str or None
        the name of the y data which was fit over
    yerr_da : xarray.dataArray or None
        The data array containing y error information for the data in ``main_da``
    """

    def __init__(self, fit_ds, main_da, main_xda, fit_func, guess_func, param_names,
                 xname, yname=None, yerr_da=None):
        """
        Saves variables and extracts ``coords`` and ``dims`` for more convenient
        access.

        Parameters
        ----------
        fit_ds : xarray.Dataset
            the dataset which resulted from fitting
        main_da : xarray.DataArray
            the data array which was fit over
        main_xda : xarray.DataArray or None
            the data array of x values which were fit over
        fit_func : function
            the function which was used to fit the data
        guess_func : function
            the function which was used to generate initial parameter
            guesses
        param_names : list of str
            names of the parameters of ``fit_func``, in the order it
            accepts them
        xname : str
            the name of the``dim`` of ``main_da`` which was fit over
        yname : str or None
            the name of the y data which was fit over
        yerr_da : xarray.dataArray or None
            The data array containing y error information for the data in ``main_da``
        """

        self.fit_ds = fit_ds
        self.coords = self.fit_ds.coords
        self.dims = self.fit_ds.dims
        self.data_vars = self.fit_ds.data_vars
        # QUESTION: should we store parameter guesses?
        self.main_da = main_da
        self.main_xda = main_xda
        self.fit_func = fit_func
        self.guess_func = guess_func
        self.param_names = param_names
        self.xname = xname
        self.yname = yname
        self.yerr_da = yerr_da

    def __repr__(self):
        return super().__repr__()+'\n'+self.fit_ds.__repr__()

    def __getattr__(self, name):
        """
        Assume unknown attribute accesses are meant for fit dataset
        """
        return getattr(self.fit_ds, name)

    def plot_fits(self, overlay_data = True, overlay = False, hide_large_errors = True,
                  pts_per_plot = 200, show_legend=True, plot_colors = ['r', 'b', 'g', 'k'], **kwargs):
        """
        Plots the results from fitting of
        :attr:`~baseAnalysis.analyzedFit.fit_ds`.

        Parameters
        ----------
        overlay_data : bool
            whether to overlay the actual data on top of the
            corresponding fit. Error bars applied if available.
        hide_large_errors : bool
            Whether to hide very large error bars
        pts_per_plot : int
            How many points to use for the ``fit_func`` domain.
        **kwargs
            Can either be:
            - names of ``dims`` of ``fit_ds``. values should eitherbe single coordinate
            values or lists of coordinate values of those ``dims``. Only data with
            coordinates given by selections are plotted. If no selections given,
            everything is plotted.
            - kwargs passed to ``plot`` or ``errorbar``, as appropriate

        Returns
        -------
        None
            Just plots the requested fits.
        """
        
        xlabel = self.main_xda.name if self.main_xda.name is not None else self.xname

        selections = {dim: coords for dim, coords in kwargs.items() if dim in self.fit_ds.dims}
        
        coord_combos = gen_coord_combo(self.fit_ds, selections=selections)

        # Determine which kwargs can be passed to plot
        if self.yerr_da is None:
            plot_argspec = getfullargspec(Line2D)
            plot_kwargs = {k: v for k, v in kwargs.items() if k in plot_argspec.args}
        else:
            ebar_argspec = getfullargspec(plt.errorbar)
            plot_kwargs = {k: v for k, v in kwargs.items() if k in ebar_argspec.args}

        for index, combo in enumerate(coord_combos):
            selection_dict = dict(zip(self.fit_ds.dims, combo))
            xselection_dict = {k: v for k, v in selection_dict.items() if k in self.main_xda.dims}
            selected_ds = self.fit_ds.sel(selection_dict)
            
            # Find the domain to fit over
            data_dom = self.main_xda.sel(xselection_dict).values.copy()
            fit_dom = np.linspace(data_dom.min(), data_dom.max(), pts_per_plot)

            # extract the fit parameters
            fit_params = [float(selected_ds[param].values) for param
                          in self.param_names]

            # don't plot if there is no meaningful data

            if np.all(np.isnan(fit_params)):
                continue

            label = (len(selection_dict.values())*'{},').format(*tuple(selection_dict.values()))
            label = label[:-1] # remove trailing comma

            # fit the function and plot
            fit_range = self.fit_func(fit_dom, *fit_params)
            # overlay data if requested
            if overlay_data:
                data_range = self.main_da.sel(selection_dict).values.copy()
                # plot errorbars if available
                if self.yerr_da is not None:
                    yerr = self.yerr_da.sel(selection_dict).values.copy()
                    num_pts = yerr.size
                    errlims = np.zeros(num_pts).astype(bool)
                    if hide_large_errors: # hide outliers if requested
                        data_avg = np.mean(data_range)
                        data_std = np.std(data_range)
                        for i, err in enumerate(yerr):
                            if err > 5*data_std:
                                yerr[i] = data_std*.5 # TODO: Find some better way of marking this
                                errlims[i] = True
                        for i, val in enumerate(data_range):
                            if np.abs(val - data_avg) > 5*data_std:
                                data_range[i] = data_avg
                                yerr[i] = data_std*0.5
                                errlims[i] = True
                                
                    plt.errorbar(data_dom, data_range, yerr, lolims=errlims,
                                 uplims=errlims, label=label, color = plot_colors[index%len(plot_colors)], **plot_kwargs)
                else:
                    plt.plot(data_dom, data_range, label=label, color = plot_colors[index%len(plot_colors)],  **plot_kwargs)

            plt.plot(fit_dom, fit_range, label=label+' fit', color = plot_colors[index%len(plot_colors)])
            # add labels and make the title reflect the current selection
            plt.xlabel(xlabel)
            if self.yname is not None:
                plt.ylabel(self.yname)
            
            if not overlay:
            	title_str = ''
            	for item in selection_dict.items():
                	title_str += '{}: {}, '.format(*item)
            	plt.title(title_str[:-2]) # get rid of trailing comma and space
            	plt.show()
        
        if overlay:
            if show_legend:
	            legend_title = len(selection_dict.keys())*'%s,'%tuple(selection_dict.keys())
	            legend_title = legend_title[:-1] # remove trailing comma
	            plt.legend(title=legend_title)
            plt.title(self.yname + ' vs ' + xlabel)
            plt.show()

    def plot_params(self, xname, yname, yerr_name = None, **kwargs):
        """
        Plots the fit parameters and their errors vs some dimension. Thin
        wrapper around :func:`~.plot_dataset`.

        Parameters
        ----------
        xname : str
            name of some ``dim`` of
            :attr:`~.analyzedFit.fit_ds`
        yname : str
            name of some ``data_var`` of
            :attr:`~.analyzedFit.fit_ds`
        yerr_name : str
            name of some ``data_var`` of
            :attr:`~.analyzedFit.fit_ds` representing
            error in yname.
            If none, defaults to ``(yname)_err'``
        **kwargs
            passed along to :func:``~.plot_dataset``

        Returns
        -------
        None
            Just plots the requested parameters.
        """

        # set yerr_name to default if none given
        if yerr_name is None:
            yerr_name = yname + '_err'

        plot_dataset(self.fit_ds, xname, yname, yerr_name=yerr_name, **kwargs)

    def fit_params(self, fit_func, guess_func, param_names, xname,
                    yname, ignore_yerr=False, **kwargs):
        """
        Fits the fit parameters in :attr:`~.analyzedFit.fit_ds` to some
        function.

        the y errors are assumed to be stored in the form yname + '_err', as
        this should be the default output of :func:`~.fit_dataset` which is what
        should have made this :class:`~.analyzedFit` object.

        Parameters
        ----------
        fit_func : function
            function to fit data to
        guess_func : function
            function to generate guesses of parameters. Arguments must be:
            - numpy array of x data
            - 1D numpy array of y data
            - keyword arguments, with the keywords being all dims of
            :attr:`~.analyzedFit.fit_ds` besides ``xname``. Values passed will be
            individual floats of coordinate values corresponding to those dims.
            All arguments must be accepted, not all must be used.
            As a hint, if designing for unexpected dims you can include **kwargs at
            the end. This will accept any keword arguments not explicitly defined
            by you and just do nothing with them.
            Must return a list of guesses to the parameters, in the order given
            in ``param_names``

        param_names : list of str
            list of fit parameter names, in the order they are returned
            by ``guess_func``
        xname : str
            the name of the ``dim`` of :attr:`~.analyzedFit.fit_ds` to be fit
            along
        yname : str
            the name of the ``dim`` containing data to be fit to
        ignore_yerr : bool
            whether to ignore yerrs when fitting
        **kwargs
            can be:
            - names of ``dims`` of :attr:`~.analyzedFit.fit_ds`
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            Object containing all results of fitting and some convenience methods.
        """

        yerr_name = None if ignore_yerr else yname+'_err'
        return fit_dataset(self.fit_ds, fit_func, guess_func, param_names, xname,
                           yname, yerr_name=yerr_name, **kwargs)

    def fit_params_model(self, models, xname, yname, ignore_yerr=False, **kwargs):
        """
        Fits the fit parameters in :attr:`~.analyzedFit.fit_ds` to some
        function.

        the y errors are assumed to be stored in the form yname + '_err', as
        this should be the default output of :func:`~.fit_dataset` which is what
        should have made this :class:`~.analyzedFit` object.

        Parameters
        ----------
        models : list of fitModel
            Models to use to fit the data
        xname : str
            the name of the ``dim`` of :attr:`~.analyzedFit.fit_ds` to be fit
            along
        yname : str
            the name of the ``dim`` containing data to be fit to
        ignore_yerr : bool
            whether to ignore yerrs when fitting
        **kwargs
            can be:
            - names of ``dims`` of :attr:`~.analyzedFit.fit_ds`
            values should eitherbe single coordinate values or lists of coordinate
            values of those ``dims``. Only data with coordinates given by selections
            are fit to . If no selections given, everything is fit to.
            - kwargs of ``curve_fit``

        Returns
        -------
        analyzedFit
            Object containing all results of fitting and some convenience methods.
        """

        yerr_name = None if ignore_yerr else yname+'_err'
        return fit_dataset_models(self.fit_ds, models, xname,
                           yname, yerr_name, **kwargs)

class analyzedModelFit(analyzedFit):
    """
    represents fitting to a set of models
    """
    
    @staticmethod
    def from_analyzedFit(a, models):
        return analyzedModelFit(models, a.fit_ds, a.main_da, a.main_xda, a.fit_func,
                                a.guess_func, a.param_names, a.xname, a.yname,
                                a.yerr_da)
    
    def __init__(self, models, fit_ds, main_da, main_xda, fit_func, guess_func, param_names,
                 xname, yname=None, yerr_da=None):
        super().__init__(fit_ds, main_da, main_xda, fit_func, guess_func, param_names,
                 xname, yname, yerr_da)
        
        self.models = models
        self.modelsd = {m.name : m for m in models}

    # TODO: add option to also plot background models, but never add them to themselves
    
    def plot_model_fits(self, plot_models, plot_total=True, background_models=[],
                         overlay_data=True, hide_large_errors=True,
                         pts_per_plot=200, show_legend=True, **kwargs):
        """
        Plots individual models
        
        Parameters
        ----------
        plot_models : list of str
            names of models to plot
        plot_total : bool
            wheter to also plot the sum of all of the models
        background_models : list of str
            models to use as a background, being added to each of the individual
            models to be plotted
        overlay_data : bool
            whether to overlay the raw data
        hide_large_errors : bool
            wheter to try to hide large errorbars
        pts_per_plot : int
            Number of points to use in the fit curves
        show_legend : bool
            whether to show the legend on the plot        
        """
        
        xlabel = self.main_xda.name if self.main_xda.name is not None else self.xname
        
        # check that all models are valid
        for m in (plot_models+background_models):
            if m not in self.modelsd:
                raise ValueError(f"{m} is not a model of this system! Included models are: {self.modelsd.keys()}")
        
        bg_models = [self.modelsd[mod] for mod in background_models]
        fg_models = [self.modelsd[mod] for mod in plot_models]

        
        selections = {dim: coords for dim, coords in kwargs.items() if dim in self.fit_ds.dims}
        
        coord_combos = gen_coord_combo(self.fit_ds, selections=selections)

        # Determine which kwargs can be passed to plot
        if self.yerr_da is None:
            plot_argspec = getfullargspec(Line2D)
            plot_kwargs = {k: v for k, v in kwargs.items() if k in plot_argspec.args}
        else:
            ebar_argspec = getfullargspec(plt.errorbar)
            plot_kwargs = {k: v for k, v in kwargs.items() if k in ebar_argspec.args}

        for combo in coord_combos:
            selection_dict = dict(zip(self.fit_ds.dims, combo))
            xselection_dict = {k: v for k, v in selection_dict.items() if k in self.main_xda.dims}
            selected_ds = self.fit_ds.sel(selection_dict)
            
            # extract selected parameters
            all_params = {pn : float(selected_ds[pn].values) for pn in self.param_names}
            
            data_dom = self.main_xda.sel(xselection_dict).values.copy()
            fit_dom = np.linspace(data_dom.min(), data_dom.max(), pts_per_plot)
            
            # don't plot if there is no meaningful data
            if np.all(np.isnan(list(all_params.values()))):
                continue
            
            # generate the background offset
            background = np.zeros(fit_dom.size)
            for m in bg_models:
                bgparams = [all_params[p.name] for p in m.params]
                background += m(fit_dom, *bgparams)
            
            # overlay data if requested
            if overlay_data:
                data_range = self.main_da.sel(selection_dict).values.copy()
                # plot errorbars if available
                if self.yerr_da is not None:
                    yerr = self.yerr_da.sel(selection_dict).values.copy()
                    num_pts = yerr.size
                    errlims = np.zeros(num_pts).astype(bool)
                    if hide_large_errors: # hide outliers if requested
                        data_avg = np.mean(data_range)
                        data_std = np.std(data_range)
                        for i, err in enumerate(yerr):
                            if err > 5*data_std:
                                yerr[i] = data_std*.5 # TODO: Find some better way of marking this
                                errlims[i] = True
                        for i, val in enumerate(data_range):
                            if np.abs(val - data_avg) > 5*data_std:
                                data_range[i] = data_avg
                                yerr[i] = data_std*0.5
                                errlims[i] = True
                    plt.errorbar(data_dom, data_range, yerr, lolims=errlims,
                                 uplims=errlims, **plot_kwargs)
                else:
                    plt.plot(data_dom, data_range, **plot_kwargs)
            
            # plot the full model, if requested
            if plot_total:
                modparams = [all_params[pn] for pn in self.param_names]
                plt.plot(fit_dom, self.fit_func(fit_dom, *modparams), label='total')
            
            # plot the models
            for m in fg_models:
                modparams = [all_params[p.name] for p in m.params]
                plt.plot(fit_dom, m(fit_dom, *modparams) + background, label=m.name)
            
            # add labels and make the title reflect the current selection
            plt.xlabel(xlabel)
            if self.yname is not None:
                plt.ylabel(self.yname)
            title_str = ''
            for item in selection_dict.items():
                title_str += '{}: {}, '.format(*item)
            plt.title(title_str[:-2]) # get rid of trailing comma and space
            
            # add legend if requested
            if show_legend:
                plt.legend()
            
            plt.show()
   
