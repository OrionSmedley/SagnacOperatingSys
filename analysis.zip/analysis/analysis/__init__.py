from .AMRAnalysis import AMRAnalysis
from .STFMR import STFMRAnalysis, STFMRAnalysis2Res, HallSTFMRAnalysis
from .HallAnalysis import HallAnalysis
from .FMRAnalysis import FMRAnalysis, FMRAnalysis2Res, FMRCryoAnalysis
from .mumaxAnalysis import mumaxSTFMRAnalysis, mumax6regionSTFMRAnalysis, mumax2layerSTFMRAnalysis
from .dataset_manipulation import plot_dataset, plot_dataArray, combine_new_ds_dim, coordinate_slice
from .dataset_manipulation import fit_dataset, fit_dataset_models, fit_dataArray, fit_dataArray_models
from .baseAnalysis import combine_new_dim
from .models import fitParameter, fitModel, lin_model, const_model, slope_model, cos_model
