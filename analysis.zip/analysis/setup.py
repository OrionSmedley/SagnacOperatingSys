from distutils.core import setup

setup(
    name='analysis',
    version='0.1',
    packages=['analysis','analysis.STFMR'],
    description='Analysis package for the Ralph group procedures.',
    long_description=open('README.rst').read(),
    # install_requires = [
    #     "xarray >= 0.10.8",
    #     "pandas >= 0.20.3",
    #     "scipy >= 0.19.1"
    # ]
)
