import pytest
from analysis.dataset_manipulation import gen_coord_combo, gen_copy_ds
from analysis.dataset_manipulation import coordinate_slice, combine_new_ds_dim

from itertools import product

import xarray as xr
import numpy as np


ex_da = xr.DataArray(
    np.random.rand(2, 3, 4),
    coords={'a': np.arange(1, 3), 'b': np.arange(
            1, 4)*11, 'c': 111*np.arange(1, 5)},
    dims=['a', 'b', 'c']
)

def test_gen_coord_combo():
    
    query1 = list(gen_coord_combo(ex_da))

    truth1 = list(product(np.arange(1, 3), 11*np.arange(1, 4),  111*np.arange(1, 5)))

    assert query1 == truth1
    
    query2 = list(gen_coord_combo(ex_da, ['a']))
    
    truth2 = list(product(11 * np.arange(1, 4),  111*np.arange(1, 5)))
    
    assert query2 == truth2
    
    query3 = list(gen_coord_combo(ex_da, ['a'], b=[22]))
    query4 = list(gen_coord_combo(ex_da, ['a'], b=22))
    
    truth3 = list(product([22],[111,222,333,444]))
    
    assert query3 == truth3
    assert query4 == truth3
    
def test_copy_ds():
    truth1 = xr.Dataset({'one': ex_da, 'two': ex_da.copy()})
    
    query1 = gen_copy_ds(ex_da, ['one','two'])
    
    assert list(truth1.data_vars) == list(query1.data_vars)
    for coord in truth1.coords:
        assert np.all(query1[coord].values == truth1[coord].values)
        
    query2 = gen_copy_ds(ex_da, ['one', 'two'], drop_dims='a')
    
    ex_da2 = xr.DataArray(
        np.random.rand(3, 4),
        coords={'b': np.arange(
            1, 4)*11, 'c': 111*np.arange(1, 5)},
        dims=['b', 'c']
    )
    
    truth2 = xr.Dataset({'one': ex_da2, 'two': ex_da2.copy()})
    
    assert list(truth2.data_vars) == list(query2.data_vars)
    for coord in truth2.coords:
        assert np.all(query2[coord].values == truth2[coord].values)
        
    query3 = gen_copy_ds(ex_da, ['one','two'], drop_dims='a', b=11)

    ex_da3 = xr.DataArray(
        np.random.rand(1, 4),
        coords={'b': [11], 'c': 111*np.arange(1, 5)},
        dims=['b', 'c']
    )
    
    truth3 = xr.Dataset({'one': ex_da3, 'two': ex_da3.copy()})
    
    assert list(truth3.data_vars) == list(query3.data_vars)
    for coord in truth3.coords:
        assert np.all(query3[coord].values == truth3[coord].values)
    
def test_coordinate_slice():
    query1 = coordinate_slice(ex_da, 'c')
    truth1 = 111*np.arange(1,5)
    assert np.all(truth1 == query1)
    
    query2 = coordinate_slice(ex_da, 'c', 222)
    truth2 = 111*np.arange(2,5)
    assert np.all(truth2 == query2)
    
    query3 = coordinate_slice(ex_da, 'c', 222, 333)
    truth3 = 111*np.arange(2,4)
    assert np.all(truth3 == query3)
    
def test_combine_new_ds_dim():
    ds1 = xr.DataArray(
        np.arange(3*4).reshape(3,4),
        coords = {'b': 11*np.arange(1,4), 'c': 111*np.arange(1,5)},
        dims = ['b', 'c']
    )
    ds2 = xr.DataArray(
        np.arange(3*4,3*4*2).reshape(3,4),
        coords = {'b': 11*np.arange(1,4), 'c': 111*np.arange(1,5)},
        dims = ['b', 'c']
    )
    query1 = combine_new_ds_dim({1: ds1, 2: ds2}, 'a')
    truth1 = xr.DataArray(
        np.arange(3*4*2).reshape(2,3,4),
        coords={'a': np.arange(1, 3), 'b': np.arange(1, 4)*11, 'c': 111*np.arange(1, 5)},
        dims=['a', 'b', 'c']
    )
    assert np.all(query1 == truth1)
    
    query2 = combine_new_ds_dim({'one': ds1, 'two': ds2}, 'a')
    truth2 = xr.DataArray(
        np.arange(3*4*2).reshape(2,3,4),
        coords={'a': ['one','two'], 'b': np.arange(1, 4)*11, 'c': 111*np.arange(1, 5)},
        dims=['a', 'b', 'c']
    )
    assert np.all(query2 == truth2)
    