import pytest
from analysis.dataset_manipulation import make_fit_dataArray_guesses, fit_dataArray, fit_dataset
from analysis.dataset_manipulation import fit_dataArray_models, fit_dataset_models
from analysis.dataset_manipulation import analyzedFit, analyzedModelFit

from itertools import product

import xarray as xr
import numpy as np

